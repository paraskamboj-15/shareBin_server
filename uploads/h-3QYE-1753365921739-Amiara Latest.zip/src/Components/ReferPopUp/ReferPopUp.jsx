// import React from 'react';
// import Lottie from 'react-lottie';
// import {  FacebookShareButton, TelegramIcon, TelegramShareButton, TwitterShareButton, WhatsappShareButton } from 'react-share'; // for social media sharing
// import { FacebookIcon, TwitterIcon, WhatsappIcon } from 'react-share'; // social media icons
// import CopyFromtag from "../../Common/CopyFromtag";
// import { FiCopy } from "react-icons/fi";
// import animationData from './../animation/refer.json'; // Your Lottie JSON file

// import './ReferPopUp.css';
// import { FaInstagram } from 'react-icons/fa';

// const ReferPopUp = ({ link, isOpen, onClose }) => {
//     if (!isOpen) return null;

//     const defaultOptions = {
//         loop: true,
//         autoplay: true,
//         animationData: animationData,
//         rendererSettings: {
//             preserveAspectRatio: 'xMidYMid slice',
//         },
//     };
//     return (
//         <div className="popup-overlay">
//             <div className="popup-content">
//                 <h2>Refer a Friend</h2>

//                 <div>
//                     <Lottie
//                         options={defaultOptions}
//                         height={100}  // Responsive Lottie size
//                         width={300}   // Responsive Lottie size
//                     />
//                 </div>

//                 {/* Referral link and copy button */}
//                 <div className="refer-link-section">
//                     <p>Your Referral Link:</p>
//                     <div className="headerLinkDiv">
//                         <div className="linktext">
//                             <h2 id="headerLink1">{link}</h2>
//                         </div>
//                         <i onClick={() => CopyFromtag("headerLink1")}>
//                             <FiCopy />
//                         </i>
//                     </div>
//                 </div>

//                 {/* Social media sharing buttons */}
//                 <div className="social-share">
//                     <p className='text-center'>Share</p>
//                     <div className="social-buttons">
//                         <FacebookShareButton url={link}>
//                             <FacebookIcon size={32} round />
//                         </FacebookShareButton>
//                         <TwitterShareButton url={link}>
//                             <TwitterIcon size={32} round />
//                         </TwitterShareButton>
//                         <WhatsappShareButton url={link}>
//                             <WhatsappIcon size={32} round />
//                         </WhatsappShareButton>
//                         <TelegramShareButton url={link}>
//                             <TelegramIcon size={32} round />
//                         </TelegramShareButton>
//                         <a href={"https://www.instagram.com/create/story/?media=${link}"} target="_blank" rel="noopener noreferrer">
//                             <FaInstagram size={32} round />
//                         </a>
//                     </div>
//                 </div>
//                 <button className="close-btn" onClick={onClose}>Close</button>
//             </div>
//         </div>
//     );
// };

// export default ReferPopUp;

import React from 'react';
import Lottie from 'react-lottie';
import {
    FacebookShareButton, TelegramIcon, TelegramShareButton,
    TwitterShareButton, WhatsappShareButton
} from 'react-share';
import { FacebookIcon, TwitterIcon, WhatsappIcon } from 'react-share';
import CopyFromtag from "../../Common/CopyFromtag";
import { FiCopy } from "react-icons/fi";
import animationData from './../animation/refer.json';
import './ReferPopUp.css';
import { FaInstagram } from 'react-icons/fa';

const ReferPopUp = ({ link, isOpen, onClose }) => {
    if (!isOpen) return null;

    const defaultOptions = {
        loop: true,
        autoplay: true,
        animationData: animationData,
        rendererSettings: {
            preserveAspectRatio: 'xMidYMid slice',
        },
    };

    return (
        <div className="refer-popup-overlay">
            <div className="refer-popup-content">
                <h2>Refer a Friend</h2>

                <div>
                    <Lottie
                        options={defaultOptions}
                        height={100}
                        width={300}
                    />
                </div>

                {/* Referral link and copy button */}
                {/* <div className="refer-popup-refer-link-section">
                    <p>Your Referral Link:</p>
                    <div className="refer-popup-refer-link-container">
                        <div className="refer-popup-refer-link-text">
                            <h2 id="referLink">{link}</h2>
                        </div>
                        <i onClick={() => CopyFromtag("referLink")}>
                            <FiCopy />
                        </i>
                    </div>
                </div> */}

                <div className="refer-link-section">
                    <p>Your Referral Link:</p>
                    <div className="headerLinkDiv">
                        <div className="linktext">
                            <h2 id="headerLink1">{link}</h2>
                        </div>
                        <i onClick={() => CopyFromtag("headerLink1")}>
                            <FiCopy />
                        </i>
                    </div>
                </div>



                {/* Social media sharing buttons */}
                <div className="refer-popup-social-share">
                    <p className="text-center">Share</p>
                    <div className="refer-popup-social-buttons">
                        <FacebookShareButton url={link}>
                            <FacebookIcon size={32} round />
                        </FacebookShareButton>
                        <TwitterShareButton url={link}>
                            <TwitterIcon size={32} round />
                        </TwitterShareButton>
                        <WhatsappShareButton url={link}>
                            <WhatsappIcon size={32} round />
                        </WhatsappShareButton>
                        <TelegramShareButton url={link}>
                            <TelegramIcon size={32} round />
                        </TelegramShareButton>
                        {/* <a href={`https://www.instagram.com/create/story/?media=${link}`} target="_blank" rel="noopener noreferrer">
                            <FaInstagram size={32} round />
                        </a> */}
                    </div>
                </div>

                <button className="refer-popup-close-btn" onClick={onClose}>Close</button>
            </div>
        </div>
    );
};

export default ReferPopUp;
