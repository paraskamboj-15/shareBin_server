// import React, { useEffect, useState } from "react";
// import "./Plans.css";
// import Loader from "../../Components/Loader/Loader";
// import { useDispatch, useSelector } from "react-redux";
// import { ApiPaths } from "../../Config/ApiPath";
// import { AiOutlineUser } from "react-icons/ai";
// import useAxiosHelper from "../../Common/AxiosHelper";
// import { setUserPersonalInfo } from "../../Redux/ProfileDataSlice";
// import { setIncomeWallet } from "../../Redux/IncomeWallet";
// import { BasicInfo, toastFailed, toastSuccess } from "../../Config/BasicInfo";
// import ArrayToObject from "../../Common/ArrayToObject";
// import OrderHistory from "./HybridPlanOrder";
// import { useNavigate } from "react-router-dom";
// import TermAndConditions from "../../Components/PaymentT&C/TermAndConditions";
// import animationData from './../../Components/animation/celebration.json';
// import Lottie from 'react-lottie';

// const Plans = () => {
//   const dispatch = useDispatch();
//   const [typingTimeout, setTypingTimeout] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [load, setLoad] = useState(false);
//   const [existUserName, setExistUserName] = useState();
//   const [amount, setAmount] = useState();
//   const [amountError, setAmountError] = useState("");
//   const [username, setUsername] = useState("");
//   const [fundBalance, setFundBalance] = useState();
//   const [selectIncome, setSelectIncome] = useState();
//   const [selectPackage, setSelectPackage] = useState([]);
//   const [sponsorLoading, setSponsorLoading] = useState(false);
//   const { AxiosPost, AxiosGet } = useAxiosHelper();
//   const incomeData = useSelector((state) => state.incomeData.incomeWallet);
//   const profileData = useSelector(
//     (state) => state.profileData.userPersonalInfo
//   );
//   const [showPopUp, setShowPopUp] = useState(false);
//   const [planId, setPlanId] = useState();
//   const navigate = useNavigate();
//   const [topUpSuccess, setTopUpSuccess] = useState(false);
//   const [companyData, setCompanyData] = useState([]);
//   const [monthlyIntrest, setMonthlyIntrest] = useState('');

//   useEffect(() => {
//     CompanyInfo();
//   }, []);
//   async function CompanyInfo() {
//     try {
//       const data = localStorage.getItem("companyData");
//       setCompanyData(JSON.parse(data));
//     } catch (error) {
//       BasicInfo.isDebug && console.log(error);
//     }
//   }

//   const isUserExist = async () => {
//     setLoad(true);

//     if (!username) {
//       setExistUserName(". . .");
//       setLoad(false);
//       return;
//     }
//     try {
//       setLoad(true);
//       const body = {
//         username: username,
//       };
//       BasicInfo.isDebug && console.log("body", body);
//       const res = await AxiosPost(ApiPaths.checkSponsor, body);
//       if (res) {
//         toastSuccess(res?.message);
//         setExistUserName(res.name);
//       } else {
//         setExistUserName("User not exists");
//       }
//     } catch (e) {
//       toastFailed(e?.response?.data?.message);
//       setExistUserName("User not exists");
//     } finally {
//       setLoad(false);
//     }
//   };

//   useEffect(() => {
//     // Clear the timeout when the user is typing
//     if (typingTimeout) {
//       clearTimeout(typingTimeout);
//     }
//     // Set a new timeout to call the API after the user stops typing
//     setTypingTimeout(
//       setTimeout(() => {
//         isUserExist();
//       }, 500) // 500ms debounce delay
//     );

//     // Cleanup the timeout when the component is unmounted or when typing continues
//     return () => clearTimeout(typingTimeout);
//   }, [username]);

//   useEffect(() => {
//     if (profileData?.username) {
//       setUsername(profileData.username);
//     }
//   }, [profileData]);

//   useEffect(() => {
//     FetchData();
//     fetchIncome();
//   }, []);

//   async function fetchIncome() {
//     try {
//       const res = await AxiosGet(ApiPaths.getPackages);
//       if (res) {
//         // Filter packages with sip_status = "0"
//         const filteredPackages = res?.packages?.filter(
//           (packageData) =>
//             packageData?.hybride_status != "0"
//         );
//         // Set the filtered packages in state
//         setSelectPackage(filteredPackages);
//         // Set select income with the value of "Time Deposit"
//         if (filteredPackages) {
//           setSelectIncome(filteredPackages?.package?.name);
//           setPlanId(filteredPackages?.planId);
//           setMonthlyIntrest(filteredPackages[0]?.roi_income?.income)
//         } else {
//           BasicInfo.isDebug && console.log("Package not found");
//         }
//       }
//     } catch (e) {
//       toastFailed(e?.response?.data?.message);
//     }
//   }

//   const handleChange = (e) => {
//     const selectedPackage = selectPackage.find(
//       (pkg) => pkg?.package?.name === e.target.value
//     );
//     console.log("selectedPackage", selectedPackage)
//     setSelectIncome(e.target.value);
//     setPlanId(selectedPackage?.planId);
//     setMonthlyIntrest(selectPackage[0]?.roi_income?.income)
//   };

//   async function FetchData() {
//     try {
//       const [res1, res2] = await Promise.all([
//         AxiosGet(ApiPaths.getProfile),
//         AxiosGet(ApiPaths.getWallets),
//       ]);
//       if (res1) {
//         dispatch(setUserPersonalInfo(res1));
//       }
//       if (res2?.wallets) {
//         dispatch(setIncomeWallet(res2?.wallets));
//         const objectWalletData = ArrayToObject(res2?.wallets);
//         setFundBalance(objectWalletData?.fund_wallet?.value);
//       }
//     } catch (error) {
//       toastFailed("Error loading data");
//     }
//   }
//   const [isAccepted, setIsAccepted] = useState(false);
//   const [showTermAndConditions, setShowTermAndConditions] = useState(false);
//   const handleTerms = () => {
//     setIsAccepted(!isAccepted);
//   };
//   const handleTermAndConditionPopUp = () => {
//     setShowTermAndConditions(!showTermAndConditions);
//   };
//   function checkValidation() {
//     // Check if income is selected
//     if (!selectIncome) {
//       toastFailed("Please select Package");
//       return false;
//     }
//     // Check if amount is greater than 0
//     if (amount <= 0) {
//       toastFailed("Please enter amount");
//       return false;
//     }
//     // Check if terms and conditions are accepted
//     if (!isAccepted) {
//       toastFailed("Please accept the terms & conditions");
//       return false;
//     }
//     // Check if the amount is greater than available funds
//     if (amount > fundBalance) {
//       toastFailed("Insufficient funds");
//       return false;
//     }
//     return true;
//   }
//   const handleProceedClick = () => {
//     const valid = checkValidation();
//     // setMonthlyIntrest(selectPackage[0]?.roi_income?.income)
//     if (valid) {
//       setShowPopUp(true);
//     }
//   };

//   const handleTopUpSuccess = () => {
//     setTopUpSuccess(true);
//     setShowPopUp(false);
//   };
//   const defaultOptions = {
//     loop: true,
//     autoplay: true,
//     animationData: animationData,
//     rendererSettings: {
//       preserveAspectRatio: 'xMidYMid slice',
//     },
//   };

//   return (
//     <>
//       {loading ? <Loader /> : null}
//       {topUpSuccess ? (
//         <section className="registerSuccessDetails">
//           <div style={{ position: "absolute", transform: "scale(8)" }}>
//             <Lottie
//               options={defaultOptions}
//               height={100}
//               width={300}
//             />
//           </div>
//           <div style={{ zIndex: "999" }}>
//             <div id="successIcon">
//               <h1>Success</h1>
//             </div>
//             <div id="successDetails">
//               <p className="mb-4">
//                 Congratulations your Investment has been successfully saved
//               </p>
//               <div style={{ display: "block" }}>
//                 <div
//                   style={{
//                     display: "flex",
//                     alignItems: "center",
//                     justifyContent: "space-between",
//                   }}
//                 >
//                   <p className="successData">Name:</p>
//                   <p className="successData">{username}</p>
//                 </div>
//                 <div
//                   style={{
//                     display: "flex",
//                     alignItems: "center",
//                     justifyContent: "space-between",
//                   }}
//                 >
//                   <p className="successData">Investment Plan:</p>
//                   <p className="successData">Amiara Hybrid Plan</p>
//                 </div>
//                 <div
//                   style={{
//                     display: "flex",
//                     alignItems: "center",
//                     justifyContent: "space-between",
//                   }}
//                 >
//                   <p className="successData">Plan Type:</p>
//                   <p className="successData">{selectIncome}</p>
//                 </div>
//                 <div
//                   style={{
//                     display: "flex",
//                     alignItems: "center",
//                     justifyContent: "space-between",
//                   }}
//                 >
//                   <p className="successData">Monthly Interest:</p>
//                   <p className="successData">{monthlyIntrest} %</p>
//                 </div>
//                 <div
//                   style={{
//                     display: "flex",
//                     alignItems: "center",
//                     justifyContent: "space-between",
//                   }}
//                 >
//                   <p className="successData">Package Amount:</p>
//                   <p className="successData">{amount}</p>
//                 </div>
//               </div>

//               <button
//                 onClick={() => {
//                   setTopUpSuccess(false);
//                   navigate("/dashboard");
//                 }}
//               >
//                 Continue
//               </button>
//             </div>
//           </div>
//         </section>
//       ) : null}
//       <section className="dashboard">
//         <h1 className="textHeadingWithMargin mt-0 mt-4">
//           Amiara Hybrid Plan {selectIncome && `(${selectIncome})`}
//         </h1>
//         <div
//           style={{
//             display: "flex",
//             alignItems: "center",
//             justifyContent: "center",
//           }}
//         >
//           <div className="planDiv">
//             <div className="addfundDiv inputPrimary ">
//               <h1>Activation</h1>
//               <div className="subscriptionWallets">
//                 {incomeData?.map(
//                   (x) =>
//                     x?.name === "Fund Wallet" && (
//                       <div className="fundWallet" key={x?.name}>
//                         <p>Fund Wallet</p>
//                         <h5>
//                           {" "}
//                           {companyData?.currency} {x?.value}
//                         </h5>
//                       </div>
//                     )
//                 )}
//               </div>
//               <div className="d-flex">
//                 <label htmlFor="Amount">User ID</label>
//                 <label htmlFor="Amount" style={{ textAlign: "end" }}>
//                   <span>{load && username ? "Loading..." : existUserName}</span>
//                 </label>
//               </div>
//               <div style={{ position: "relative" }}>
//                 <div>
//                   <i
//                     style={{
//                       position: "absolute",
//                       top: 5,
//                       left: 2,
//                       color: "var(--colorPrimary)",
//                     }}
//                   >
//                     <AiOutlineUser />
//                   </i>
//                 </div>
//                 <input
//                   type="text"
//                   style={{ padding: "8px 20px" }}
//                   placeholder="Enter User ID"
//                   value={username}
//                   onChange={(e) => setUsername(e.target.value.toUpperCase())}
//                 />
//                 {sponsorLoading ? <i id="sponsorLoading"></i> : null}
//               </div>
//               <label>Select Packages</label>
//               <div>
//                 <select
//                   style={{
//                     padding: "8px",
//                     color: "var(--textColor)",
//                     width: "100%",
//                     borderRadius: "5px",
//                   }}
//                   name=""
//                   id=""
//                   value={selectIncome}
//                   onChange={(e) => handleChange(e)}
//                 >
//                   <option value="">Select Package</option>
//                   {selectPackage?.map((pkg) => (
//                     <option key={pkg?.planId} value={pkg?.package?.name}>
//                       {pkg?.package?.name}
//                     </option>
//                   ))}
//                 </select>
//               </div>
//               <label htmlFor="Amount">Amount ({companyData?.currency} )</label>
//               <input
//                 type="number"
//                 className="inputPrimary"
//                 placeholder="Enter Amount"
//                 value={amount}
//                 onChange={(e) => setAmount(e.target.value)}
//               />
//               <p className="errorMsg">{amountError}</p>
//               <div className="mt-1">
//                 <label className="d-flex">
//                   <input
//                     className="w-auto mx-1"
//                     style={{ marginBottom: "-1px" }}
//                     type="checkbox"
//                     checked={isAccepted}
//                     onChange={handleTerms}
//                   />
//                   I agree to <span className="termAndConditions" onClick={handleTermAndConditionPopUp}
//                     style={{ cursor: 'pointer', color: 'var(--colorPrimary)' }}>Terms & Conditions</span>
//                 </label>
//                 {showTermAndConditions && (
//                   <TermAndConditions onClose={handleTermAndConditionPopUp} />
//                 )}
//               </div>
//               <button className="btnPrimary mt-3" onClick={handleProceedClick}>
//                 Proceed
//               </button>
//               {showPopUp && (
//                 <PopUp
//                   amount={amount}
//                   planId={planId}
//                   username={username}
//                   fundBalance={fundBalance}
//                   interest={monthlyIntrest}
//                   selectIncome={selectIncome}
//                   onClose={() => setShowPopUp(false)} // Pass a prop to close the pop-up
//                   onTopUpSuccess={handleTopUpSuccess} // Pass a callback for top-up success
//                   setShowPopUp={() => setShowPopUp(false)}

//                 />
//               )}
//             </div>
//           </div>
//         </div>
//         <OrderHistory />
//       </section>
//     </>
//   );
// };

// export default Plans;

// function PopUp({
//   username,
//   planId,
//   amount,
//   selectIncome,
//   interest,
//   onClose,
//   onTopUpSuccess
// }) {
//   const [loading, setLoading] = useState(false);
//   const { AxiosPost } = useAxiosHelper();

//   async function TopUp() {
//     try {
//       setLoading(true);
//       const body = {
//         username,
//         planId,
//         amount,
//       };
//       const res = await AxiosPost(ApiPaths.topUp, body);
//       const packageTime = res?.date;
//       onTopUpSuccess(packageTime); // Pass packageTime to the parent
//     } catch (e) {
//       toastFailed(e?.response?.data?.message);
//     } finally {
//       setLoading(false);
//     }
//   }

//   return (
//     <>
//       <div className="otpSection" style={{ zIndex: "999" }}>
//         <div className="otpContainer" style={{ width: "400px" }}>
//           <p>
//             Are you sure you want to proceed with the top-up for the following
//             details?
//           </p>
//           <div style={{ marginBottom: "20px", flexDirection: "column" }}>
//             <div
//               style={{
//                 display: "flex",
//                 justifyContent: "space-between",
//                 marginTop: "0px",
//                 gap: "0",
//               }}
//             >
//               <p>
//                 <strong>User ID:</strong>
//               </p>
//               <p>{username}</p>
//             </div>
//             <div
//               style={{
//                 display: "flex",
//                 justifyContent: "space-between",
//                 marginTop: "0px",
//                 gap: "0",
//               }}
//             >
//               <p>
//                 <strong>Installment Plan:</strong>
//               </p>
//               <p>Amiara HYBRID Plan</p>
//             </div>
//             <div
//               style={{
//                 display: "flex",
//                 justifyContent: "space-between",
//                 marginTop: "0px",
//                 gap: "0",
//               }}
//             >
//               <p>
//                 <strong>Plan Type:</strong>
//               </p>
//               <p>{selectIncome}</p>
//             </div>
//             <div
//               style={{
//                 display: "flex",
//                 justifyContent: "space-between",
//                 marginTop: "0px",
//                 gap: "0",
//               }}
//             >
//               <p>
//                 <strong style={{ whiteSpace: "nowrap" }}>Monthly Interest:</strong>
//               </p>
//               <p>{interest} %</p>
//             </div>
//             <div
//               style={{
//                 display: "flex",
//                 justifyContent: "space-between",
//                 marginTop: "0px",
//                 gap: "0",
//               }}
//             >
//               <p>
//                 <strong>Amount:</strong>
//               </p>
//               <p>{amount}</p>
//             </div>
//           </div>
//           <div>
//             <button className="btnSecondary" onClick={onClose}>
//               No
//             </button>
//             <button className="btnPrimary" onClick={TopUp} disabled={loading}>
//               {loading ? "Processing..." : "Yes"}
//             </button>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

import React, { useEffect, useState } from "react";
import "./Plans.css";
import Loader from "../../Components/Loader/Loader";
import { useDispatch, useSelector } from "react-redux";
import { ApiPaths } from "../../Config/ApiPath";
import { AiOutlineUser } from "react-icons/ai";
import useAxiosHelper from "../../Common/AxiosHelper";
import { setUserPersonalInfo } from "../../Redux/ProfileDataSlice";
import { setIncomeWallet } from "../../Redux/IncomeWallet";
import { BasicInfo, toastFailed, toastSuccess } from "../../Config/BasicInfo";
import ArrayToObject from "../../Common/ArrayToObject";
import OrderHistory from "./HybridPlanOrder";
import { useNavigate } from "react-router-dom";
import moment from "moment";
// import TermAndConditions from "../../Components/PaymentT&C/TermAndConditions";
import animationData from "./../../Components/animation/celebration.json";
import Lottie from "react-lottie";

const HybridPlan = () => {
  const dispatch = useDispatch();
  const [typingTimeout, setTypingTimeout] = useState(null);
  const [loading, setLoading] = useState(false);
  const [load, setLoad] = useState(false);
  const [existUserName, setExistUserName] = useState();
  const [amount, setAmount] = useState();
  const [amountError, setAmountError] = useState("");
  const [username, setUsername] = useState("");
  const [fundBalance, setFundBalance] = useState();
  const [selectIncome, setSelectIncome] = useState();
  const [selectPackage, setSelectPackage] = useState([]);
  const [sponsorLoading, setSponsorLoading] = useState(false);
  const { AxiosPost, AxiosGet } = useAxiosHelper();
  const incomeData = useSelector((state) => state.incomeData.incomeWallet);
  const profileData = useSelector(
    (state) => state.profileData.userPersonalInfo
  );
  const [showPopUp, setShowPopUp] = useState(false);
  const [planId, setPlanId] = useState();
  const navigate = useNavigate();
  const [topUpSuccess, setTopUpSuccess] = useState(false);
  const [sponsorName, setSponsorName] = useState("");
  const [companyData, setCompanyData] = useState([]);
  const [monthlyIntrest, setMonthlyIntrest] = useState("");

  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }

  const isUserExist = async () => {
    setLoad(true);

    if (!username) {
      setExistUserName(". . .");
      setLoad(false);
      return;
    }
    try {
      setLoad(true);
      const body = {
        username: username,
      };
      BasicInfo.isDebug && console.log("body", body);
      const res = await AxiosPost(ApiPaths.checkSponsor, body);
      if (res) {
        toastSuccess(res?.message);
        setExistUserName(res.name);
      } else {
        setExistUserName("User not exists");
      }
    } catch (e) {
      toastFailed(e?.response?.data?.message);
      setExistUserName("User not exists");
    } finally {
      setLoad(false);
    }
  };

  useEffect(() => {
    // Clear the timeout when the user is typing
    if (typingTimeout) {
      clearTimeout(typingTimeout);
    }
    // Set a new timeout to call the API after the user stops typing
    setTypingTimeout(
      setTimeout(() => {
        isUserExist();
      }, 500) // 500ms debounce delay
    );

    // Cleanup the timeout when the component is unmounted or when typing continues
    return () => clearTimeout(typingTimeout);
  }, [username]);

  useEffect(() => {
    if (profileData?.username) {
      setUsername(profileData.username);
    }
  }, [profileData]);
  var x = 0;
  useEffect(() => {
    if (x == 0) {
      FetchData();
      fetchIncome();
      CompanyInfo();
      x++;
    }
  }, []);
  async function fetchIncome() {
    try {
      const res = await AxiosGet(ApiPaths.getPackages);
      if (res) {
        setSelectPackage(res?.packages);
        const fixedDepositPackage = res?.packages.find(
          (plan) => plan?.hybride_status != "0"
        );
        // Set select income with the value of "Meta F Time Deposit"
        if (fixedDepositPackage) {
          setSelectIncome(fixedDepositPackage.package.name);
          setPlanId(fixedDepositPackage?.planId);
          setMonthlyIntrest(fixedDepositPackage?.roi_income?.income);
        } else {
          BasicInfo.isDebug && console.log(" Time Deposit package not found");
        }
      }
    } catch (e) {
      toastFailed(e?.response?.data?.message);
    }
  }
  async function FetchData() {
    try {
      const [res1, res2] = await Promise.all([
        AxiosGet(ApiPaths.getProfile),
        AxiosGet(ApiPaths.getWallets),
      ]);
      if (res1) {
        dispatch(setUserPersonalInfo(res1));
      }
      if (res2?.wallets) {
        dispatch(setIncomeWallet(res2?.wallets));
        const objectWalletData = ArrayToObject(res2?.wallets);
        setFundBalance(objectWalletData?.fund_wallet?.value);
      }
    } catch (error) {
      toastFailed("Error loading data");
    }
  }
  const [isAccepted, setIsAccepted] = useState(false);
  const [showTermAndConditions, setShowTermAndConditions] = useState(false);
  const handleTerms = () => {
    setIsAccepted(!isAccepted);
  };
  const handleTermAndConditionPopUp = () => {
    setShowTermAndConditions(!showTermAndConditions);
  };
  function checkValidation() {
    // Check if income is selected
    if (!selectIncome) {
      toastFailed("Please select Package");
      return false;
    }
    // Check if amount is greater than 0
    if (amount <= 0) {
      toastFailed("Please enter amount");
      return false;
    }
    // Check if terms and conditions are accepted
    if (!isAccepted) {
      toastFailed("Please accept the terms & conditions");
      return false;
    }
    // Check if the amount is greater than available funds
    if (amount > fundBalance) {
      toastFailed("Insufficient funds");
      return false;
    }

    // If all checks pass, return true
    return true;
  }
  const handleProceedClick = () => {
    const valid = checkValidation();
    if (valid) {
      setShowPopUp(true);
    }
  };
  const handleTopUpSuccess = () => {
    setTopUpSuccess(true);
    setShowPopUp(false);
  };
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  return (
    <>
      {loading ? <Loader /> : null}
      {topUpSuccess ? (
        <section className="registerSuccessDetails">
          <div style={{ position: "absolute", transform: "scale(8)" }}>
            <Lottie options={defaultOptions} height={100} width={300} />
          </div>
          <div style={{ zIndex: "999" }}>
            <div id="successIcon">
              <h1>Success</h1>
            </div>
            <div id="successDetails">
              <p className="mb-4">
                Congratulations your Investment has been successfully saved
              </p>
              <div style={{ display: "block" }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Name:</p>
                  <p className="successData">{username}</p>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Investment Plan:</p>
                  <p className="successData">Amiara Hybrid Plan</p>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Plan Type:</p>
                  <p className="successData">{selectIncome}</p>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Monthly Interest:</p>
                  <p className="successData">{monthlyIntrest} %</p>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Package Amount:</p>
                  <p className="successData">
                    {companyData?.currency} {amount}
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  setTopUpSuccess(false);
                  navigate("/dashboard");
                }}
              >
                Continue
              </button>
            </div>
          </div>
        </section>
      ) : null}
      <section className="dashboard">
        <h1 className="textHeadingWithMargin mt-0 mt-4">
          Amiara Hybrid Plan ({selectIncome})
        </h1>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div className="planDiv">
            <div className="addfundDiv inputPrimary ">
              <h1>Activation</h1>
              <div className="subscriptionWallets">
                {incomeData?.map(
                  (x) =>
                    x?.name === "Fund Wallet" && (
                      <div className="fundWallet" key={x?.name}>
                        <p>Fund Wallet</p>
                        <h5>
                          {" "}
                          {companyData?.currency} {x?.value}
                        </h5>
                      </div>
                    )
                )}
              </div>
              <div className="d-flex">
                <label htmlFor="Amount">User ID</label>
                <label htmlFor="Amount" style={{ textAlign: "end" }}>
                  <span>{load && username ? "Loading..." : existUserName}</span>
                </label>
              </div>
              <div style={{ position: "relative" }}>
                <div>
                  <i
                    style={{
                      position: "absolute",
                      top: 5,
                      left: 2,
                      color: "var(--colorPrimary)",
                    }}
                  >
                    <AiOutlineUser />
                  </i>
                </div>
                <input
                  type="text"
                  style={{ padding: "8px 20px" }}
                  placeholder="Enter User ID"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toUpperCase())}
                />
                {sponsorLoading ? <i id="sponsorLoading"></i> : null}
              </div>

              <label htmlFor="Amount">Amount ({companyData?.currency} )</label>
              <input
                type="number"
                className="inputPrimary"
                placeholder="Enter Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <p className="errorMsg">{amountError}</p>
              <div className="mt-1">
                <label className="d-flex">
                  <input
                    className="w-auto mx-1"
                    style={{ marginBottom: "-1px" }}
                    type="checkbox"
                    checked={isAccepted}
                    onChange={handleTerms}
                  />
                  I agree to{" "}
                  <span
                    className="termAndConditions"
                    onClick={handleTermAndConditionPopUp}
                    style={{ cursor: "pointer", color: "var(--colorPrimary)" }}
                  >
                    Terms & Conditions
                  </span>
                </label>
                {showTermAndConditions && (
                  <TermAndConditions onClose={handleTermAndConditionPopUp} />
                )}
              </div>

              <button className="btnPrimary mt-3" onClick={handleProceedClick}>
                Proceed
              </button>
              {showPopUp && (
                <PopUp
                  amount={amount}
                  planId={planId}
                  username={username}
                  fundBalance={fundBalance}
                  interest={monthlyIntrest}
                  selectIncome={selectIncome}
                  onClose={() => setShowPopUp(false)} // Pass a prop to close the pop-up
                  onTopUpSuccess={handleTopUpSuccess} // Pass a callback for top-up success
                  setShowPopUp={() => setShowPopUp(false)}
                />
              )}
            </div>
          </div>
        </div>
        <OrderHistory />
      </section>
    </>
  );
};

export default HybridPlan;

function PopUp({
  username,
  planId,
  amount,
  fundBalance,
  selectIncome, // Package name
  interest,
  onClose,
  onTopUpSuccess,
  packageTime,
  setShowPopUp,
}) {
  const [loading, setLoading] = useState(false);
  const { AxiosPost } = useAxiosHelper();
  const [companyData, setCompanyData] = useState([]);

  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    CompanyInfo();
  }, []);

  async function TopUp() {
    try {
      setLoading(true);
      const body = {
        username,
        planId,
        amount,
      };
      console.log(body, "bodyyy");
      const res = await AxiosPost(ApiPaths.topUp, body);
      const packageTime = res?.date;
      onTopUpSuccess(packageTime); // Pass packageTime to the parent
    } catch (e) {
      toastFailed(e?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  }
  return (
    <>
      <div className="otpSection" style={{ zIndex: "999" }}>
        <div className="otpContainer" style={{ width: "400px" }}>
          <p>
            Are you sure you want to proceed with the top-up for the following
            details?
          </p>
          <div style={{ marginBottom: "20px", flexDirection: "column" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong>User ID:</strong>
              </p>
              <p>{username}</p>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong style={{ whiteSpace: "nowrap" }}>
                  Investment Plan:
                </strong>
              </p>
              <p>{selectIncome}</p>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong style={{ whiteSpace: "nowrap" }}>
                  Monthly Interest:
                </strong>
              </p>
              <p>{interest} %</p>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong>Amount:</strong>
              </p>
              <p>
                {companyData?.currency} {amount}
              </p>
            </div>
          </div>
          <div>
            <button className="btnSecondary" onClick={onClose}>
              No
            </button>
            <button className="btnPrimary" onClick={TopUp} disabled={loading}>
              {loading ? "Processing..." : "Yes"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function TermAndConditions({ onClose }) {
  return (
    <div className="term-and-conditions__overlay">
      <div className="term-and-conditions__content">
        <div>
          <h1 className="textHeading">Terms & Conditions</h1>
        </div>

        <p>
          1. Introduction These Terms and Conditions govern the Amiara Hybrid
          Plan (hereinafter referred to as "the Plan"), offered by Amiara
          (hereinafter referred to as "the Company"). By enrolling in the Plan,
          the Applicant (hereinafter referred to as "the Investor") agrees to be
          bound by these Terms and Conditions.
          <br />
          2. Investment Details Minimum Investment: The minimum investment
          amount for the Plan is ₹10,000. Tenure: The standard tenure for the
          Plan is 48 months. Other tenures may be available as specified in the
          Plan Application Form. The Investor shall select the desired tenure at
          the time of investment. Interest Rate/Returns: The applicable interest
          rate or projected returns will be clearly stated in the Plan
          Application Form and will be determined based on market conditions and
          the chosen tenure. The Company reserves the right to adjust the
          rate/returns for new investments based on prevailing market
          conditions. However, the agreed-upon rate/return for existing
          investments will remain fixed for the chosen tenure. Interest/Return
          Payment Frequency: The frequency of interest/return payments (e.g.,
          monthly, quarterly, annually) will be specified in the Plan
          Application Form. Maturity: The Plan will mature on the specified
          maturity date as per the chosen tenure.
          <br />
          3. Deposits and Withdrawals Deposits: Investments can be made through
          approved methods as specified by the Company. Premature Withdrawal:
          Withdrawals before maturity are subject to a penalty. The penalty will
          be a percentage of the principal amount and/or accrued
          interest/returns, as clearly outlined in the Plan Application Form.
          Withdrawals may not be permitted within a specified initial period
          (e.g., the first 9 months). The Company reserves the right to refuse
          premature withdrawal requests in exceptional circumstances, as
          permitted by applicable law. Emergency Withdrawals: In cases of
          documented genuine emergencies (e.g., medical emergencies, death of an
          immediate family member), the Company may consider waiving or reducing
          the premature withdrawal penalty at its discretion. Supporting
          documentation will be required.
          <br />
          4. Auto-Renewal The Plan will be automatically renewed for the same
          tenure at the prevailing interest rate/return at the time of renewal
          unless the Investor provides written notice to the Company at least
          [Number] days prior to the maturity date to cancel auto-renewal.
          <br />
          5. Tax Implications The Investor is solely responsible for any tax
          liabilities arising from the Plan. The Company will deduct taxes at
          source (TDS) as per applicable tax laws.
          <br />
          6. Nomination The Investor may nominate a beneficiary to receive the
          Plan proceeds in the event of their death. The nomination can be
          changed by the Investor during the Plan's tenure by providing written
          notice to the Company.
          <br />. Amendments The Company reserves the right to amend these Terms
          and Conditions at any time. The Investor will be notified of any
          material changes in writing or through other appropriate communication
          channels.
          <br />
          8. Dispute Resolution Any disputes arising out of or in connection
          with this Plan shall be resolved through arbitration in Delhi, India,
          in accordance with the rules of the Indian Council of Arbitration. The
          language of the arbitration shall be English. The arbitral award shall
          be final and binding on both parties. For the purposes of this clause,
          "Delhi" refers to the National Capital Territory of Delhi, India.
          <br />
          9. Limitation of Liability The Company shall not be liable for any
          losses arising from events beyond its reasonable control, including
          but not limited to acts of God, war, terrorism, government
          regulations, or market fluctuations. The Company is responsible for
          exercising reasonable care and diligence in managing the Plan.
          <br />
          10. Governing Law These Terms and Conditions shall be governed by and
          construed in accordance with the laws of India. Any legal action or
          proceeding arising under these Terms and Conditions shall be subject
          to the exclusive jurisdiction of the courts in Delhi, India. For the
          purposes of this clause, "Delhi" refers to the National Capital
          Territory of Delhi, India.
          <br />
          11. Acceptance By signing the Amiara Hybrid Plan Application Form or
          making an investment, the Investor acknowledges that they have read,
          understood, and agreed to these Terms and Conditions.
          <br />
          <br />
          <h1> Key Definitions for Amiara Hybrid Plan Terms and Conditions</h1>
          <br />
          {/* <li> */}
          <ul>
            Amiara/the Company: Refers to the legal entity offering the Amiara
            Hybrid Plan, i.e., the provider of the investment plan. Its full
            legal name and registration details should be included in the actual
            legal document.
          </ul>
          <ul>
            Hybrid Plan/the Plan: Refers to the specific investment product
            offered by Amiara, governed by these Terms and Conditions. It should
            be clearly defined what makes it a "hybrid" plan.
          </ul>
          <ul>
            Investor/Applicant: Refers to the individual or entity investing in
            the Amiara Hybrid Plan and agreeing to these Terms and Conditions.
          </ul>
          <ul>
            Investment: Refers to the monetary contribution made by the Investor
            to the Plan.
          </ul>
          <ul>
            Principal Amount: Refers to the original sum of money invested by
            the Investor, excluding any accrued interest or returns.
          </ul>
          <ul>
            Tenure: Refers to the fixed period for which the investment is made,
            as chosen by the Investor at the time of investment.
          </ul>
          <ul>
            Interest Rate/Returns: Refers to the rate at which the investment is
            expected to generate profit. "Interest Rate" typically applies to
            fixed-income investments, while "Returns" is a broader term that can
            include both fixed and variable returns (e.g., from market-linked
            investments). The specific method of calculating returns should be
            clearly defined.
          </ul>
          <ul>
            Maturity Date: Refers to the date on which the investment tenure
            ends, and the principal amount along with any accrued interest or
            returns becomes payable to the Investor.
          </ul>
          <ul>
            Premature Withdrawal: Refers to the withdrawal of the investment
            before the maturity date.
          </ul>
          <ul>
            Penalty: Refers to the financial charge imposed on the Investor for
            making a premature withdrawal. The method of calculating the penalty
            should be clearly defined (e.g., a percentage of the principal, a
            portion of accrued interest).
          </ul>
          <ul>
            Auto-Renewal: Refers to the automatic extension of the investment
            tenure for the same period at the prevailing interest rate/return at
            the time of renewal, unless the Investor provides written notice to
            cancel the renewal.
          </ul>
          <ul>
            Nominee/Beneficiary: Refers to the person or entity designated by
            the Investor to receive the investment proceeds in the event of the
            Investor's death.
          </ul>
          <ul>
            Applicable Law: Refers to the relevant laws and regulations
            governing the Plan and these Terms and Conditions, which in this
            case is the law of India.
          </ul>
          <ul>
            Jurisdiction: Refers to the legal authority of a court or other
            legal body to hear and decide legal cases. In this case, it is the
            courts in Delhi, India.
          </ul>
          <ul>
            Arbitration: Refers to a form of alternative dispute resolution
            where a neutral third party (an arbitrator) hears both sides of a
            dispute and makes a binding decision.
          </ul>
          <ul>
            Force Majeure: (Often included in Limitation of Liability) Refers to
            unforeseeable circumstances that prevent someone from fulfilling a
            contract, such as acts of God, war, or natural disasters.
          </ul>
          {/* </li> */}
        </p>
        <button className="term-and-conditions__button" onClick={onClose}>
          Close
        </button>
      </div>
    </div>
  );
}
