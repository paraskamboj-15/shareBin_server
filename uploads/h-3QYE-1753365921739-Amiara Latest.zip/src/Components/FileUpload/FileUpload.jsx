// import React, { useEffect, useState } from "react";
// import { useDropzone } from "react-dropzone";
// import axios from "axios";
// import "./FileUpload.css";
// import { FiUploadCloud } from "react-icons/fi";
// import { IoIosAdd } from "react-icons/io";
// import { Col, Row } from "react-bootstrap";
// import { MdOutlineModeEdit } from "react-icons/md";
// import useAxiosHelper from "./../../Common/AxiosHelper";
// import { ApiPaths } from "./../../Config/ApiPath";
// import { BasicInfo, toastFailed, toastSuccess } from "./../../Config/BasicInfo";
// import { useLocation, useNavigate } from "react-router-dom";
// import imageCompression from "browser-image-compression";

// const FileUpload = () => {
//   const { AxiosPost } = useAxiosHelper();
//   const navigate = useNavigate();
//   const [files, setFiles] = useState([]);
//   const [amount, setAmount] = useState();
//   const [formTransationId, setFormTransationId] = useState("");
//   const [uploading, setUploading] = useState(false);
//   const [error, setError] = useState(null);
//   const [previews, setPreviews] = useState([]);

//   const onDrop = async (acceptedFiles) => {
//     const compressedFiles = await Promise.all(
//       acceptedFiles.map(async (file) => {
//         const options = {
//           maxSizeMB: 1, // Maximum file size in MB
//           maxWidthOrHeight: 1024, // Maximum width or height in pixels
//           useWebWorker: true,
//         };
//         try {
//           return await imageCompression(file, options);
//         } catch (err) {
//           console.error("Error compressing image:", err);
//           return file;
//         }
//       })
//     );

//     setFiles(compressedFiles);
//     setPreviews(compressedFiles.map((file) => URL.createObjectURL(file)));
//   };
//   const handleClearPreview = (index) => {
//     // Remove the preview at the specified index
//     setPreviews(prevPreviews => prevPreviews.filter((_, i) => i !== index));
//   };
//   let location = useLocation();
//   useEffect(() => {
//     let props = location?.state?.myData && JSON?.parse(location?.state?.myData);
//     setAmount(props);
//   }, []);

//   const uploadFiles = async () => {
//     if (formTransationId?.length > 0) {
//       setUploading(true);
//       setError(null);

//       const formData = new FormData();
//       files.forEach((file) => {
//         formData.append("proof", file);
//       });

//       // Append additional data
//       formData.append("amount", amount);
//       formData.append("transaction_id", formTransationId);

//       try {
//         BasicInfo.isDebug && console.log("formData", formData);
//         const response = await AxiosPost(ApiPaths.paymentRequest, formData);
//         BasicInfo.isDebug && console.log("Upload success:", response);
//         setFiles([]);
//         setPreviews([]);
//         setAmount("");
//         setFormTransationId("");
//         toastSuccess(response?.message);
//         navigate("/dashboard");
//       } catch (err) {
//         console.error("Upload error:", err);
//         setError("Failed to upload files. Please try again.");
//       } finally {
//         setUploading(false);
//       }
//     } else {
//       toastFailed("Invalid Data");
//     }
//   };

//   const { getRootProps, getInputProps } = useDropzone({ onDrop });

//   return (
//     <>
//       <Row className="mt-5">
//         <Col md="4" className="mb-4 mb-md-0">
//           <div className="myProfileInputField">
//             <span id="myProfileInputFieldTitle">Amount</span>
//             <input
//               id="myProfileInputFieldInput"
//               type="number"
//               placeholder="Enter Amount"
//               value={amount}
//               onChange={(e) => setAmount(e.target.value)}
//             />
//             <i id="myProfileInputFieldIcon">
//               <MdOutlineModeEdit />
//             </i>
//           </div>
//         </Col>
//         <Col md="8">
//           <div className="myProfileInputField">
//             <span id="myProfileInputFieldTitle">Transaction Id/Hash</span>
//             <input
//               id="myProfileInputFieldInput"
//               type="text"
//               placeholder="Enter Transaction Id/Hash"
//               value={formTransationId}
//               onChange={(e) => setFormTransationId(e.target.value)}
//             />
//             <i id="myProfileInputFieldIcon">
//               <MdOutlineModeEdit />
//             </i>
//           </div>
//         </Col>
//       </Row>
//       <div className="file-upload-container">
//         <div {...getRootProps({ className: "dropzone" })}>
//           <input {...getInputProps()} />
//           {previews.length > 0 ? (
//             <div className="previews">
//               {previews.map((preview, index) => (
//                 <div key={index} className="preview">
//                   <img src={preview} alt={`Preview ${index}`} />
//                   <button
//                     className="clear-preview"
//                     onClick={() => handleClearPreview(index)}
//                     aria-label={`Remove preview ${index}`}
//                   >
//                     &times;
//                   </button>
//                 </div>
//               ))}
//             </div>
//           ) : (
//             <div className="d-flex">
//               <i>
//                 <IoIosAdd />
//               </i>
//               <p>Drop files here (.jpg, .jpeg & .png)</p>
//             </div>
//           )}
//         </div>
//         <button
//           className="upload-button"
//           onClick={uploadFiles}
//           disabled={uploading || files.length === 0}
//           title={uploading || files.length === 0 ? "Upload Image" : ""}
//         >
//           <i>
//             <FiUploadCloud />
//           </i>
//           {uploading ? "Submiting..." : "Submit"}
//         </button>
//         {error && <p className="error-message">{error}</p>}
//       </div>
//     </>
//   );
// };

// export default FileUpload;



import React, { useEffect, useState } from "react";
import { useDropzone } from "react-dropzone";
import axios from "axios";
import "./FileUpload.css";
import { FiUploadCloud } from "react-icons/fi";
import { IoIosAdd } from "react-icons/io";
import { Col, Row } from "react-bootstrap";
import { MdOutlineModeEdit } from "react-icons/md";
import useAxiosHelper from "./../../Common/AxiosHelper";
import { ApiPaths } from "./../../Config/ApiPath";
import { BasicInfo, toastFailed, toastSuccess } from "./../../Config/BasicInfo";
import { useLocation, useNavigate } from "react-router-dom";
import imageCompression from "browser-image-compression";

const FileUpload = () => {
  const { AxiosPost } = useAxiosHelper();
  const navigate = useNavigate();
  const [files, setFiles] = useState([]);
  const [amount, setAmount] = useState();
  const [formTransationId, setFormTransationId] = useState("");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [previews, setPreviews] = useState([]);

  const onDrop = async (acceptedFiles) => {
    // Filter files by allowed formats
    const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
    const filteredFiles = acceptedFiles.filter((file) =>
      allowedTypes.includes(file.type)
    );

    if (filteredFiles.length !== acceptedFiles.length) {
      toastFailed("Only .jpg, .jpeg, and .png files are allowed.");
    }

    const compressedFiles = await Promise.all(
      filteredFiles.map(async (file) => {
        const options = {
          maxSizeMB: 1, // Maximum file size in MB
          maxWidthOrHeight: 1024, // Maximum width or height in pixels
          useWebWorker: true,
        };
        try {
          return await imageCompression(file, options);
        } catch (err) {
          console.error("Error compressing image:", err);
          return file;
        }
      })
    );

    setFiles(compressedFiles);
    setPreviews(compressedFiles.map((file) => URL.createObjectURL(file)));
  };

  const handleClearPreview = (index) => {
    setPreviews((prevPreviews) => prevPreviews.filter((_, i) => i !== index));
    setFiles((prevFiles) => prevFiles.filter((_, i) => i !== index));
  };

  const uploadFiles = async () => {
    if (formTransationId?.length > 0) {
      setUploading(true);
      setError(null);

      const formData = new FormData();
      files.forEach((file) => {
        formData.append("proof", file);
      });

      formData.append("amount", amount);
      formData.append("transaction_id", formTransationId);

      try {
        BasicInfo.isDebug && console.log("formData", formData);
        const response = await AxiosPost(ApiPaths.paymentRequest, formData);
        BasicInfo.isDebug && console.log("Upload success:", response);
        setFiles([]);
        setPreviews([]);
        setAmount("");
        setFormTransationId("");
        toastSuccess(response?.message);
        navigate("/dashboard");
      } catch (err) {
        console.error("Upload error:", err);
        setError("Failed to upload files. Please try again.");
      } finally {
        setUploading(false);
      }
    } else {
      toastFailed("Invalid Data");
    }
  };

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: ".jpg,.jpeg,.png", // Restrict file types
  });
  let location = useLocation();
  useEffect(() => {
    let props = location?.state?.myData && JSON?.parse(location?.state?.myData);
    setAmount(props);
  }, []);

  return (
    <>
      <Row className="mt-5">
        <Col md="4" className="mb-4 mb-md-0">
          <div className="myProfileInputField">
            <span id="myProfileInputFieldTitle">Amount</span>
            <input
              id="myProfileInputFieldInput"
              type="number"
              placeholder="Enter Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <i id="myProfileInputFieldIcon">
              <MdOutlineModeEdit />
            </i>
          </div>
        </Col>
        <Col md="8">
          <div className="myProfileInputField">
            <span id="myProfileInputFieldTitle">Transaction Id/Hash</span>
            <input
              id="myProfileInputFieldInput"
              type="text"
              placeholder="Enter Transaction Id/Hash"
              value={formTransationId}
              onChange={(e) => setFormTransationId(e.target.value.toUpperCase())}
            />
            <i id="myProfileInputFieldIcon">
              <MdOutlineModeEdit />
            </i>
          </div>
        </Col>
      </Row>
      <div className="file-upload-container">
        <div {...getRootProps({ className: "dropzone" })}>
          <input {...getInputProps()} />
          {previews.length > 0 ? (
            <div className="previews">
              {previews.map((preview, index) => (
                <div key={index} className="preview">
                  <img src={preview} alt={`Preview ${index}`} />
                  <button
                    className="clear-preview"
                    onClick={() => handleClearPreview(index)}
                    aria-label={`Remove preview ${index}`}
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="d-flex">
              <i>
                <IoIosAdd />
              </i>
              <p>Drop files here (.jpg, .jpeg & .png)</p>
            </div>
          )}
        </div>
        <button
          className="upload-button"
          onClick={uploadFiles}
          disabled={uploading || files.length === 0}
          title={uploading || files.length === 0 ? "Upload Image" : ""}
        >
          <i>
            <FiUploadCloud />
          </i>
          {uploading ? "Submitting..." : "Submit"}
        </button>
        {error && <p className="error-message">{error}</p>}
      </div>
    </>
  );
};

export default FileUpload;
