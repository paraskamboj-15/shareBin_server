import React, { useEffect, useState } from "react";
import "./Login.css";
import Logo from "./../../Images/logo.png";
import { Col, Container, Row } from "react-bootstrap";
import { AiOutlineUser } from "react-icons/ai";
import { HiLockClosed } from "react-icons/hi";
import Loader from "../../Components/Loader/Loader";
import { Link, useNavigate } from "react-router-dom";
import { FaRegEyeSlash } from "react-icons/fa";
import { FaRegEye } from "react-icons/fa";
import useAxiosHelper from "./../../Common/AxiosHelper";
import { setAuthToken } from "./../../Redux/StatusState";
import { toast } from "react-toastify";
import { BasicInfo } from "./../../Config/BasicInfo";
import { ApiPaths } from "./../../Config/ApiPath";
import { setLoginDisplay } from "../../Redux/LoginSlice";
import { useDispatch } from "react-redux";

import axios from "axios";
const Login = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [passwordVisility, setPasswordVisiblity] = useState(false);
  const [selection, setSelection] = useState(''); // Manage selection (username/password)
  const [popupOpen, setPopupOpen] = useState(false); // Manage popup visibility
  const openPopup = () => {
    setPopupOpen(true); // Open the popup when "forgot?" is clicked
  };
  const closePopup = () => {
    setPopupOpen(false); // Close the popup
  };
  const handleSelection = (selection) => {
    setSelection(selection); // Set selection
    closePopup(); // Close the popup
    if (selection === 'username') {
      navigate('/forget_username'); // Navigate to forget username page
    } else if (selection === 'password') {
      navigate('/forget_password'); // Navigate to forget password page
    }
  };

  const dispatch = useDispatch();
  const { AxiosPost, AxiosGet } = useAxiosHelper();
  const toastSuccess = (msg) => toast.success(msg);
  const toastFailed = (msg) => toast.error(msg);
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get("token");
  const basepath = process.env.REACT_APP_API_URL;
  const [companyData, setCompanyData] = useState();
  async function CompanyInfo() {
    try {
      let data = localStorage.getItem("companyData");
      BasicInfo.isDebug && console.log("LocalStorage Data:", JSON.parse(data));

      if (data) {
        // If data exists in localStorage, parse and set it
        setCompanyData(JSON.parse(data));
      } else {
        // If no data, make an API call to fetch the company info
        const response = await AxiosGet(ApiPaths.getCompanyDetails);

        // Assuming response?.company_info holds the data you need
        const companyData = response?.company_info;

        // Store the fetched data in localStorage
        localStorage.setItem("companyData", JSON.stringify(companyData));

        // Set the fetched data in the state
        setCompanyData(companyData);
        BasicInfo.isDebug &&
          console.log("Fetched and stored company data:", companyData);
      }
    } catch (error) {
      BasicInfo.isDebug && console.log("Error fetching company data:", error);
    }
  }
  let x = 0;
  useEffect(() => {
    if (x == 0) {
      CompanyInfo();
      x++;
    }
  }, []);
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        if (token && token.length > 10) {
          const response = await axios.get(`${basepath}/get_profile`, {
            headers: { Authorization: token },
          });
          if (response) {
            BasicInfo.isDebug && console.log(response);
            localStorage.setItem("token", token);
            localStorage.setItem("userId", response?.data?.uid);
            navigate("/dashboard");
          }
        }
      } catch (err) {
        console.log(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [token]);

  useEffect(() => {
    const handleKeyPress = (event) => {
      if (event.key === "Enter") {
        Login();
      }
    };

    document.addEventListener("keypress", handleKeyPress);
    return () => {
      document.removeEventListener("keypress", handleKeyPress);
    };
  }, [username, password]);

  async function Login() {
    if (username?.length > 0 && password?.length > 0) {
      setLoading(true);
      try {
        setLoading(true);
        const body = {
          password: password,
          username: username,
        };
        console.log(body,"Bodyyyyy")
        const res = await AxiosPost(ApiPaths.login, body);
        if (res.status == 200) {
          toastSuccess(res?.message);
          dispatch(setAuthToken(res?.token));
          localStorage.setItem("token", res?.token);
          localStorage.setItem("userId", JSON.stringify(res?.user?.uid));

          dispatch(setLoginDisplay(false));
          navigate("/dashboard");
          setLoading(false);
        }
        setLoading(false);
      } catch (error) {
        toastFailed(error?.response?.data?.message);
        setLoading(false);
      }
    } else {
      toastFailed("Invalid Data");
    }
  }

  return (
    <>
      {loading ? <Loader /> : null}
      <Container id="logincontainer">
        <div className="loginContainerContent">
          <Row md="12">
            <Col md="12">
              {" "}
              <div className="loginContent">
                <a
                  className="loginLogo"
                  href={companyData?.contactInfo?.website}
                >
                  <img src={Logo} alt="logo.png" width="100px" height="100px" />
                </a>
                <p>sign in into your account</p>

                <div className="loginContent_inner">
                  <div className="loginInput_inner">
                    <span>Username</span>
                    <i>
                      <AiOutlineUser />
                    </i>
                    <input
                      autocomplete="off"
                      type="text"
                      placeholder="Enter your Username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value.toUpperCase())}
                    />
                  </div>
                  <div className="loginInput_inner">
                    <span>Password</span>
                    <i>
                      <HiLockClosed />
                    </i>
                    <input
                      autocomplete="off"
                      id="viewInput"
                      type={passwordVisility ? "text" : "password"}
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                    <i
                      id="eyeIcon"
                      onClick={() => setPasswordVisiblity(!passwordVisility)}
                    >
                      {passwordVisility ? <FaRegEye /> : <FaRegEyeSlash />}
                    </i>
                  </div>
                  <div className="loginForgot_link">
                    <Link onClick={openPopup}>forgot?</Link>
                    {/* <Link to="/forget_username">forgot username</Link>
                    <Link to="/forget_password">forgot password</Link> */}
                    {popupOpen && (
                      <div className="loginForgotPopup__overlay">
                        <div className="loginForgotPopup__content">
                          <h3>What did you forget?</h3>
                          <button className="btnPrimary" onClick={() => handleSelection('username')}>Forgot Username</button>
                          <button className="btnPrimary" onClick={() => handleSelection('password')}>Forgot Password</button>
                          <button className="btnSecondary" onClick={closePopup}>Cancel</button>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="loginFooter_btn">
                    <button
                      className="btnPrimary mb-2"
                      onClick={Login}
                      id="viewBtn"
                    >
                      Login
                    </button>
                    <p className="sign_log">Don't have an account?</p>
                    <Link to="/register" className="btnPrimary">
                      Register
                    </Link>
                  </div>{" "}
                </div>
              </div>
            </Col>
          </Row>
        </div>
      </Container>
    </>
  );
};

export default Login;
