import React, { useEffect, useState } from "react";
import { MdOutlineFilterList } from "react-icons/md";
import { ApiPaths } from "../../Config/ApiPath";
import Loader from "../../Components/Loader/Loader";
import PaginationComponent from "../../Components/PaginationControls/PaginationControls";
import { BasicInfo, toastFailed } from "../../Config/BasicInfo";
import useAxiosHelper from "../../Common/AxiosHelper";
import { useSelector, useDispatch } from "react-redux";
import { Col, Row } from "react-bootstrap";
import moment from "moment";
import { useNavigate } from "react-router-dom";
import { FaCrown } from "react-icons/fa";
import "./Progress.css";
const OrderHistory = () => {
  const [selectIncome, setSelectIncome] = useState(1);
  const [tabsName, setTabsName] = useState("deposit");

  const [filterVisiblity, setFilterVisiblity] = useState(false);
  const [loading, setLoading] = useState(false);
  const [runOnce, setRunOnce] = useState(true);
  const [paymentTransaction, setPaymentTransaction] = useState();

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [initValue, setInitValue] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [pageNum, setPageNum] = useState();
  const [currentPage, setCurrentPage] = useState(1);
  const [companyData, setCompanyData] = useState([]);
  const [showPopUp, setShowPopUp] = useState(false);
  const [progressBar, setProgressBar] = useState();
  const [order, setOrder] = useState();
  const navigate = useNavigate();
  useEffect(() => {
    CompanyInfo();
  }, []);
  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      console.log(error);
    }
  }
  const { AxiosGet, AxiosPost } = useAxiosHelper();

  const handlePagination = (page) => {
    setCurrentPage(page);
  };

  var x = 0;

  useEffect(() => {
    if (x === 0) {
      FetchData();
      x++;
    }
  }, []);
  const FetchData = async (page = currentPage) => {
    try {
      const queryParams = {
        page,
        limit: 20,
        planId: 5,
      };
      if (startDate && endDate) {
        queryParams.startDate = startDate;
        queryParams.endDate = endDate;
      }
      setLoading(true);
      const queryString = new URLSearchParams(
        Object.entries(queryParams).flatMap(([key, value]) =>
          Array.isArray(value) ? value.map((v) => [key, v]) : [[key, value]]
        )
      ).toString();
      const response = await AxiosGet(
        `${ApiPaths.getOrders}?${new URLSearchParams(queryString).toString()}`
      );
      BasicInfo.isDebug && console.log("order history", response);
      setPaymentTransaction(response?.data || []);
      setTotalPages(response?.totalPages || 1);
    } catch (error) {
      console.error("Error fetching payment transactions:", error);
    } finally {
      setLoading(false);
    }
  };
  function resetData() {
    setStartDate("");
    setEndDate("");
    FetchData(currentPage);
  }

  async function handleAction(orderId, orderData) {
    try {
      console.log(order);
      setLoading(true);
      const body = {
        order_Id: orderId,
      };
      console.log(body);
      const res = await AxiosPost(ApiPaths.progress, body);
      console.log(res, "..");
      setProgressBar(res?.data);
      setOrder(orderData);
      // navigate("/dashboard/progress_bar", {
      //   state: { progressBar: res?.data, order },
      // });
      setShowPopUp(true);
    } catch (e) {
      toastFailed(e?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      {loading ? <Loader /> : null}
      <section style={{ marginTop: " 20px" }}>
        <div className="incomeSelectBox">
          <div></div>
          <button onClick={() => setFilterVisiblity(!filterVisiblity)}>
            {filterVisiblity ? "Hide Filters" : "Show Filters"}
            <i>
              {" "}
              <MdOutlineFilterList />
            </i>{" "}
          </button>
        </div>
        {filterVisiblity ? (
          <section className="filtersection inputPrimary">
            <Row>
              <Col lg="2" md="4" xs="12">
                <input
                  type="date"
                  name=""
                  id=""
                  placeholder="Start Date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </Col>
              <Col lg="2" md="4" xs="12">
                <input
                  type="date"
                  name=""
                  id=""
                  placeholder="End Date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </Col>
              <Col lg="2" md="4" xs="6">
                <button onClick={() => FetchData()}>Search</button>
              </Col>
              <Col lg="2" md="4" xs="6">
                <button onClick={() => resetData()}>Reset</button>
              </Col>
            </Row>
          </section>
        ) : null}

        <section className="history">
          <h1 className="textHeading">Active Investment Details</h1>
          <div className="table">
            <table>
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Amount ({companyData?.currency_sign})</th>
                  <th>Investment Plan</th>
                  <th>Order Date</th>
                  <th>Maturity Date</th>
                  {/* <th>Earned Incomes</th>
                  <th>Pending Incomes</th>
                  <th>Total Incomes</th> */}
                  <th>Status</th>
                  {/* <th>Expiry Date</th> */}
                  <th>Username(name)</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {paymentTransaction != null && Array.isArray(paymentTransaction)
                  ? paymentTransaction?.map((x, i) => {
                      return (
                        <tr>
                          {/* <td>{parseInt(incomeData?.start_from) + 1 + i}</td> */}

                          <td>{i + 1}</td>
                          <td>{parseFloat(x?.amount).toFixed(2)}</td>
                          <td>{x?.package_type}</td>
                          <td>{moment(x?.order_Date).format("DD MMM YY")}</td>
                          <td>
                            {moment(x?.order_Date)
                              .add(x?.maturity_Date, "months")
                              .format("DD MMM YY")}
                          </td>
                          {/* <td>{x?.earned_income}</td>
                        <td>{x?.pending_income}</td>
                        <td>{x?.total_income}</td> */}
                          {x?.status == "0" ? (
                            <td>Pending</td>
                          ) : x?.status == "1" ? (
                            <td style={{ color: "green" }}>Success</td>
                          ) : (
                            <td style={{ color: "red" }}>Rejected</td>
                          )}
                          {/* <td>{new Date(x?.order_Date).toLocaleDateString()}</td> */}
                          {/* <td>{moment(x?.order_Date).add(x?.maturity_Date, 'months').format("DD MMM YY")}</td> */}
                          <td>
                            {x?.username}({x?.name})
                          </td>
                          <td>
                            {" "}
                            <button
                              onClick={() => handleAction(x?.order_Id, x)}
                              className="btnPrimary m-0"
                            >
                              Info.
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  : ""}
              </tbody>
            </table>
            {paymentTransaction == 0 ? <p>No history yet</p> : null}
          </div>
          {paymentTransaction != null && (
            <PaginationComponent
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePagination}
            />
          )}
          {showPopUp && (
            <div className="otpSection" style={{ zIndex: "999" }}>
              <div className="otpContainer" style={{ width: "400px" }}>
                <h4>
                  <strong>Progress for this transaction </strong>
                </h4>
                <div className="progressBarData">
                  <p>
                    <strong>Name:</strong>
                  </p>
                  <p>{order?.name}</p>
                </div>
                <div className="progressBarData">
                  <p>
                    <strong>Username:</strong>
                  </p>
                  <p>{order?.username}</p>
                </div>
                <div className="progressBarData">
                  <p>
                    <strong>Order Date:</strong>
                  </p>
                  <p>{moment(order?.order_Date).format("DD MMM YY")}</p>
                </div>
                <div className="progressBarData">
                  <p>
                    <strong>Maturity Date:</strong>
                  </p>
                  <p>
                    {moment(order?.order_Date)
                      .add(order?.maturity_Date, "months")
                      .format("DD MMM YY")}
                  </p>
                </div>
                <div className="progressBarData">
                  <p>
                    <strong>Invested Amount:</strong>
                  </p>
                  <p>
                    {companyData?.currency}{" "}
                    {parseFloat(progressBar?.amount).toFixed(2)}
                  </p>
                </div>
                <div className="progressBarData">
                  <p>
                    <strong>Total Income:</strong>
                  </p>
                  <p>
                    {companyData?.currency}{" "}
                    {parseFloat(progressBar?.totalHybridRoiIncome).toFixed(2)}
                  </p>
                </div>

                <div className="progress-bar-wrapper">
                  <div className="crownProgress">
                    <label htmlFor="progressBar">
                      <strong>Progress:</strong>
                    </label>
                    <i>
                      <FaCrown />
                    </i>
                  </div>
                  <div className="progress-bar-container">
                    <div
                      className="progressBar"
                      style={{
                        width: `${
                          (progressBar?.totalHybridRoiIncome /
                            progressBar?.totalOrderAmount) *
                          100
                        }%`,
                        background: "var(--colorPrimary)",
                        marginTop: "0px",
                      }}
                    ></div>
                  </div>
                  <div className="progressAmount">
                    <div></div>
                    <div>
                      <p>
                        {companyData?.currency} {progressBar?.totalOrderAmount}
                      </p>
                    </div>
                  </div>
                </div>

                <button
                  className="refer-popup-close-btn"
                  onClick={() => setShowPopUp(false)}
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </section>
      </section>
    </>
  );
};

export default OrderHistory;
