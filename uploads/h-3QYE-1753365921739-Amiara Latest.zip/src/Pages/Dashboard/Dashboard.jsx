import React, { useEffect, useState } from "react";
import "./Dashboard.css";
import "./Slot.css";
import { HiMiniUserGroup } from "react-icons/hi2";
import { MdBusinessCenter } from "react-icons/md";
import { RiGroup2Fill, RiSendPlaneLine } from "react-icons/ri";
import { Row, Col } from "react-bootstrap";
import Loader from "../../Components/Loader/Loader";
import { useLocation, useNavigate } from "react-router-dom";
import { BasicInfo, toastFailed, toastSuccess } from "./../../Config/BasicInfo";
import { ApiPaths } from "./../../Config/ApiPath";
import useAxiosHelper from "./../../Common/AxiosHelper";
import { useSelector, useDispatch } from "react-redux";
import User from "./../../Images/user.png";
import { setUserPersonalInfo } from "../../Redux/ProfileDataSlice";
import { setIncomeWallet } from "../../Redux/IncomeWallet";
import { setTeamSection } from "../../Redux/TeamSlice";
import ArrayToObject from "../../Common/ArrayToObject";
import moment from "moment/moment";
import PopUp from "./../../Components/LoginPopUp/LoginPopUp";
import { FaUserFriends } from "react-icons/fa";
import ReferPopUp from "./../../Components/ReferPopUp/ReferPopUp";
import { IoIosAdd } from "react-icons/io";
import { AiFillPlusCircle } from "react-icons/ai";
import { setPopupShown, resetPopupState } from "../../Redux/NotificationSlice";

const Dashboard = () => {
  // let myArray = Array.from({ length: 8 });
  const { AxiosGet, AxiosPost } = useAxiosHelper();
  const [totalInvestment, setTotalInvestment] = useState();
  const [totalIncome, setTotalIncome] = useState();
  const [orderHistory, setOrderHistory] = useState([]);
  const [todayIncomeData, setTodayIncomeData] = useState([]);
  const [totalCapping, setTotalcapping] = useState();
  const [thisMonthlyIncomeData, setThisMonthlyIncomeData] = useState([]);
  const [lastMonthlyIncomeData, setLastMonthlyIncomeData] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newsData, setNewsData] = useState();
  const isPopupOpen = useSelector((state) => state.notification.isPopupOpen);
  const [hasUserClosed, setHasUserClosed] = useState(false);
  const dispatch = useDispatch();
  const location = useLocation();

  async function fetchPopupNews() {
    if (!isPopupOpen) return;

    const queryParams = new URLSearchParams({ popup: 1 });
    const queryString = queryParams.toString();
    const tempData = await AxiosGet(
      `${ApiPaths.getNotifications}?${queryString}`
    );
    setNewsData(tempData?.data);

    console.log("tempData222", tempData?.data);
    console.log("image formation", tempData?.data?.[0]?.image);
    if (tempData?.data?.length > 0) {
      dispatch(setPopupShown()); // Open popup only if data exists
    }
  }

  useEffect(() => {
    if (isPopupOpen) {
      fetchPopupNews(); // Fetch data only if popup should be open
    }
  }, [isPopupOpen]);

  const handleClose = () => {
    dispatch(resetPopupState()); // Close popup and keep it closed
  };

  const handleShowModal = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };
  const [showPopUp, setShowPopUp] = useState({
    visible: false,
    sipId: null,
    amount: null,
    maturityDate: null,
    installmentId: null,
  });
  const [typingTimeout, setTypingTimeout] = useState(null);
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState("");
  const [sponsorLoading, setSponsorLoading] = useState(false);
  const navigate = useNavigate();
  const [companyData, setCompanyData] = useState([]);
  const [amountError, setAmountError] = useState("");
  const [amount, setAmount] = useState();
  const [convertAmount, setConvertAmount] = useState();
  const [amt, setAmt] = useState();
  const [color, setColor] = useState("");
  const [link, setLink] = useState();
  const [isError, setIsError] = useState(false);
  const profileData = useSelector(
    (state) => state.profileData.userPersonalInfo
  );
  const incomeData = useSelector((state) => state.incomeData.incomeWallet);
  const teamData = useSelector((state) => state.teamData?.teamSection);
  var x = 0;
  useEffect(() => {
    if (x === 0) {
      fetchData();
      fetchIncome();
      CompanyInfo();
      FetchOrderHistory();
      fetchColor();
      fetchLink();
      x++;
    }
  }, []);
  const [isReferOpen, setIsReferOpen] = useState(false);
  const referButton = () => {
    setIsReferOpen(!isReferOpen);
  };

  async function fetchLink() {
    try {
      const res = await AxiosGet(ApiPaths.getLink);
      console.log("linkkkkkkkkkkkkkkkkk", res?.meeting?.[0]);
      setLink(res?.meeting?.[0]);
      setIsError(false);
    } catch (e) {
      if (e?.response?.status === 404) {
        setIsError(true);
      }
      toastFailed(e?.response?.data?.message);
    }
  }
  const handleDeposit = () => {
    if (amount > 0) {
      const data = { amount: amount };
      const queryParams = new URLSearchParams(data).toString();
      window.location.href = `dashboard/payment-upi?${queryParams}`;
    } else {
      toastFailed("Invalid amount");
    }
  };
  const [recentHistory, setRecentHistory] = useState([]);
  const FetchOrderHistory = async () => {
    try {
      setLoading(true);
      const response = await AxiosGet(ApiPaths.getPaymentTransaction); // Assuming this API returns order history
      BasicInfo.isDebug && console.log("ordersssssss", response?.data);
      const allOrders = response?.data || []; // Assuming API response contains an array
      setOrderHistory(allOrders);

      // Extract the most recent 5 orders
      const recentOrders = allOrders.slice(0, 5);
      setRecentHistory(recentOrders); // Assuming 'orders' is the key for the list of orders
    } catch (error) {
      BasicInfo.isDebug &&
        console.error("Error fetching order history:", error);
      toastFailed(error?.message);
    } finally {
      setLoading(false);
    }
  };
  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }
  async function fetchData() {
    try {
      const [res1, res2, tempTeam] = await Promise.all([
        AxiosGet(ApiPaths.getProfile),
        AxiosGet(ApiPaths.getWallets),
        AxiosGet(ApiPaths.getTeams),
      ]);
      if (res1) dispatch(setUserPersonalInfo(res1));
      if (res2) {
        setTodayIncomeData(res2?.todayIncome);
        setTotalIncome(res2?.totalIncome);
        // setThisMonth(res2?.)
        setThisMonthlyIncomeData(res2?.thisMonthIncome);
        setLastMonthlyIncomeData(res2?.lastMonthIncome);
        dispatch(setIncomeWallet(res2?.wallets));
        const objectToArray = ArrayToObject(res2?.wallets);
      }
      if (tempTeam) dispatch(setTeamSection(tempTeam));
    } catch (error) {
      toastFailed(error?.tempTeam?.message);
      BasicInfo.isDebug && console.log(error);
    }
  }
  const FetchData = async () => {
    try {
      setLoading(true);
      const response = await AxiosGet(ApiPaths.getOrders);
    } catch (error) {
      BasicInfo.isDebug &&
        console.error("Error fetching payment transactions:", error);
    } finally {
      setLoading(false);
    }
  };
  async function fetchIncome() {
    try {
      const res = await AxiosGet(ApiPaths.getPackages);
      console.log(res?.packages[0]?.package?.total_capping, "...");
      setTotalcapping(res?.packages[0]?.package?.total_capping);
    } catch (e) {
      toastFailed(e?.response?.data?.message);
    }
  }
  const [userId, setUserId] = useState("");
  const [userIdError, setUserIdError] = useState("");
  const [showOtp, setShowOtp] = useState(false);
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);
  const [checkSponsorExist, setCheckSponsorExist] = useState([]);
  const [status, setStatus] = useState("0");
  const [change, setChange] = useState();
  const profileImg = profileData?.profileImg;

  useEffect(() => {
    if (Array.isArray(incomeData)) {
      const total = incomeData
        .filter((x) => x.wallet_type === "investment")
        .reduce((sum, x) => sum + parseFloat(x.value || 0), 0);

      setTotalInvestment(total);
    }
  }, [incomeData]);
  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }
  async function FundTransferFunc() {
    setAmountError("");
    setUserIdError("");
    setOtpError("");
    if (!amount > 0) {
      setAmountError("Invalid Amount");
    }
    if (!userId.length > 0) {
      setUserIdError("Invalid User ID");
    }
    if (otp.length != 6) {
      toastFailed("Invalid OTP");
    }
    const body = {
      username: userId,
      amount: amount,
      otp: otp,
      action: "Fund transfer",
    };
    BasicInfo.isDebug && console.log("body", body);
    if (amount > 0 && userId.length > 0 && otp.length == 6) {
      try {
        setOtpLoading(true);
        const response = await AxiosPost(ApiPaths.p2pTransfer, body);
        toastSuccess(response?.message);
        setChange(Date.now());
        setShowOtp(false);
        FetchData();
        setUserId("");
        setAmount("");
        setOtp("");
        BasicInfo.isDebug && console.log("response", response);
        setOtpLoading(false);
      } catch (e) {
        toastFailed(e?.response?.data?.message);
        BasicInfo.isDebug && console.log("error", e);
        setOtpLoading(false);
      }
    }
  }
  async function FundConvert() {
    if (convertAmount <= 0) {
      toastFailed("Invalid Amount");
      return;
    }
    const body = {
      amount: convertAmount,
    };
    BasicInfo.isDebug && console.log("body", body);
    try {
      setOtpLoading(true);
      const response = await AxiosPost(ApiPaths.fundConvert, body);
      BasicInfo.isDebug && console.log("response of fundConvert", response);
      fetchData();
      FetchOrderHistory();
      toastSuccess(response?.message);
      setOtpLoading(false);
    } catch (e) {
      toastFailed(e?.response?.data?.message);
      BasicInfo.isDebug && console.log("error", e);
    }
  }
  const fetchColor = async () => {
    try {
      const response = await AxiosGet(ApiPaths.getColor); // replace with your API
      console.log("getColor", response);
      setColor(response?.hex_value);
    } catch (error) {
      console.error("Error fetching color:", error);
    }
  };
  const packageBuyBtn = async (slug) => {
    console.log("slug==>", slug);
    if (slug === "self_investment") {
      navigate("coin-stacking-plan");
    } else if (slug === "self_fd") {
      navigate("fixed-deposit-plan");
    } else if (slug === "self_sip") {
      navigate("growth-sip-plan");
    } else if (slug === "self_hybride") {
      navigate("hybrid-plan");
    }
  };
  const [showLoginPopUp, setShowLoginPopUp] = useState(false); // Pop-up visibility
  const handleLoginPopUp = () => {
    const isLogin = localStorage.getItem("isLogin");
    if (!isLogin && profileData?.Activation_date) {
      setTimeout(() => {
        setShowLoginPopUp(true);
        localStorage.setItem("isLogin", true);
      }, 5000); // 5000 milliseconds = 5 seconds
    }
  };

  // useEffect(() => {
  //   if (!isPopupShown) {
  //     fetchPopupNews();
  //     dispatch(setPopupShown());
  //   }
  // }, [isPopupShown, dispatch]);
  // const handleNewsPopUp = () => {
  //   const isLogin = localStorage.getItem("isLogin");
  //   if (!isLogin) {
  //     setTimeout(() => {
  //       setIsNewsPopUpOpen(true);
  //       localStorage.setItem("isLogin", true);
  //     });
  //   }
  // };
  useEffect(() => {
    handleLoginPopUp();
    // handleNewsPopUp();
    // fetchPopupNews();
  }, []);
  const [isNewsPopUpOpen, setIsNewsPopUpOpen] = useState(true); // Assuming popup starts open

  return (
    <>
      {loading ? <Loader /> : null}
      {newsData?.length > 0 && isPopupOpen && (
        <div className="popup-overlay">
          <div
            className="popup-container pb-5"
            style={{ maxWidth: "80vw", width: "fit-content" }}
          >
            <h2>Latest Notification</h2>
            <h3 style={{ color: "var(--colorPrimary)" }}>
              {newsData[0]?.title || "No Title Available"}
            </h3>
            {newsData[0]?.image ? (
              <img
                src={newsData[0]?.image}
                alt="News Image"
                style={{ width: "100%", marginBottom: "10px" }}
              />
            ) : null}
            <p>{newsData[0]?.description || "No description available."}</p>
            <div
              style={{
                display: "flex",
                gap: "10px",
                position: "absolute",
                right: "10px",
              }}
            >
              <button
                className="btnPrimary"
                style={{
                  width: "fit-content",
                }}
                onClick={() => {
                  navigate("notification");
                }}
              >
                All Notifications
              </button>
              <button
                className="btnPrimary"
                style={{
                  width: "fit-content",
                }}
                onClick={handleClose}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
      {showLoginPopUp && (
        <PopUp
          title="Refer & Earn !"
          description="Invite your friends to join and earn exciting rewards for every successful referral."
          referralLink={
            window.location.origin + "/register?ref=" + profileData?.username
          }
          onClose={() => setShowLoginPopUp(false)}
        />
      )}
      <section className="dashboard">
        <section className="cappingSection mb-4">
          <div className="d-flex justify-content-between pkgSlfInvstmnt">
            <h1 className="textHeading">Packages</h1>
            <h1 className="dashboardCardHeading">
              Self Investment: {companyData?.currency}{" "}
              {totalInvestment && totalInvestment.toFixed(2)}
            </h1>
          </div>
          <div
            className="packagesContent"
            style={{ background: color || "var(--btnBackground)" }}
          >
            <Row md="12" className="gx-3 gy-3">
              {Array.isArray(incomeData) &&
                incomeData?.map((x, i) => {
                  return (
                    x?.wallet_type == "investment" && (
                      //  x?.slug != "self_hybride" &&
                      <Col md="3">
                        <div
                          className="dashboardIncomeCard"
                          style={{ height: "100%" }}
                        >
                          <div className="dashboardData">
                            <div>
                              <h5
                                className="dashboardCardHeading"
                                style={{ textTransform: "capitalize" }}
                              >
                                {x?.name}
                              </h5>
                              <h1>
                                {companyData?.currency}{" "}
                                {parseFloat(x?.value).toFixed(2) ?? "0"}
                              </h1>
                            </div>
                            <div>
                              <button
                                className="btnPrimary"
                                onClick={() => packageBuyBtn(x?.slug)}
                              >
                                Buy
                              </button>
                            </div>
                          </div>
                        </div>
                      </Col>
                    )
                  );
                })}
            </Row>
          </div>
        </section>
        <div className="fundOption">
          <div>
            <p>Total Balance</p>
            {incomeData?.map((x, i) => {
              return (
                x?.name === "Fund Wallet" && (
                  <h5>
                    {companyData?.currency_sign}
                    {(x?.value && x?.value.toFixed(2)) || 0.0}
                  </h5>
                )
              );
            })}
          </div>
          <div className="d-flex gap-2">
            <button
              className="d-flex justify-content-center align-items-center gap-1"
              onClick={() => navigate("fund")}
            >
              Add <IoIosAdd size={20} />
            </button>
            <button
              className="d-flex justify-content-center align-items-center gap-1"
              onClick={() => navigate("fund-transfer")}
            >
              Send <RiSendPlaneLine size={18} />
            </button>
            {/* <button className="d-flex justify-content-center align-items-center gap-1" onClick={()=>navigate()}>
              Convert <GrPowerCycle size={14} />
            </button> */}
          </div>
        </div>
        <Row md="12" className="gx-3 gy-3 incomProfile">
          <Col lg="8" className="">
            <Row lg="4" className="gx-3 gy-3">
              {Array.isArray(incomeData) &&
                incomeData?.map((x, i) => {
                  return (
                    x?.wallet_type == "wallet" && (
                      <Col lg="4">
                        <div
                          className="dashboardIncomeCard"
                          style={{ height: "100%" }}
                        >
                          <div className="dashboardData">
                            <div>
                              <h5
                                className="dashboardCardHeading"
                                style={{ textTransform: "capitalize" }}
                              >
                                {x?.name}
                              </h5>
                              <h1>
                                {companyData?.currency}{" "}
                                {parseFloat(x?.value).toFixed(2) ?? "0"}
                              </h1>
                            </div>
                          </div>
                        </div>
                      </Col>
                    )
                  );
                })}
            </Row>
            <h1 className="textHeading mt-2">Incomes</h1>
            <Row lg="4" className="gx-3 gy-3">
              {Array.isArray(incomeData) &&
                incomeData?.map((x, i) => {
                  return (
                    x?.wallet_type == "income" && (
                      <Col lg="4" className="">
                        <div
                          className="dashboardIncomeCard"
                          style={{
                            cursor: "pointer",
                          }}
                          onClick={() => {
                            navigate("incomes", {
                              state: { selectIncome: x?.slug },
                            });
                          }}
                        >
                          <div className="dashboardData">
                            <div>
                              <h5
                                className="dashboardCardHeading"
                                style={{ textTransform: "capitalize" }}
                              >
                                {x?.name}
                              </h5>
                              <h1>
                                {companyData?.currency}{" "}
                                {parseFloat(x?.value).toFixed(2) ?? "0"}
                              </h1>
                              {Array.isArray(todayIncomeData) &&
                                todayIncomeData?.map(
                                  (item, index) =>
                                    item?.slug == x?.slug && (
                                      <div
                                        className="d-flex gap-2 mt-1"
                                        key={index}
                                      >
                                        <span
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          {" "}
                                          {companyData?.currency}{" "}
                                          {parseFloat(
                                            todayIncomeData?.[index]?.income
                                          ).toFixed(2)}
                                        </span>
                                        <span
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          Today
                                        </span>
                                      </div>
                                    )
                                )}
                              {Array.isArray(thisMonthlyIncomeData) &&
                                thisMonthlyIncomeData?.map(
                                  (item, index) =>
                                    item?.slug == x?.slug && (
                                      <div
                                        className="d-flex gap-2 mt-1"
                                        key={index}
                                      >
                                        <span
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          {" "}
                                          {companyData?.currency}{" "}
                                          {parseFloat(
                                            thisMonthlyIncomeData?.[index]
                                              ?.income
                                          ).toFixed(2)}
                                        </span>
                                        <span
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          This Month
                                        </span>
                                      </div>
                                    )
                                )}
                              {Array.isArray(lastMonthlyIncomeData) &&
                                lastMonthlyIncomeData?.map(
                                  (item, index) =>
                                    item?.slug == x?.slug && (
                                      <div
                                        className="d-flex gap-2 mt-1"
                                        key={index}
                                      >
                                        <span
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          {" "}
                                          {companyData?.currency}{" "}
                                          {parseFloat(
                                            lastMonthlyIncomeData?.[index]
                                              ?.income
                                          ).toFixed(2)}
                                        </span>
                                        <span
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          Last Month
                                        </span>
                                      </div>
                                    )
                                )}
                              {/* {Array.isArray(thisMonthlyIncomeData) &&
                                thisMonthlyIncomeData?.map(
                                  (item, index) =>
                                    item?.slug == x?.slug && (
                                      <div
                                        className="d-flex gap-2 "
                                        key={index}
                                      >
                                        <p
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          {parseFloat(
                                            thisMonthlyIncomeData?.[index]
                                              ?.income
                                          ).toFixed(2)}
                                        </p>
                                        <p
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          This Month
                                        </p>
                                      </div>
                                    )
                                )} */}
                              {/* {Array.isArray(lastMonthlyIncomeData) &&
                                lastMonthlyIncomeData?.map(
                                  (item, index) =>
                                    item?.slug == x?.slug && (
                                      <div
                                        className="d-flex gap-2 "
                                        key={index}
                                      >
                                        <p
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          {parseFloat(
                                            lastMonthlyIncomeData?.[index]
                                              ?.income
                                          ).toFixed(2)}
                                        </p>
                                        <p
                                          style={{
                                            fontSize: "12px",
                                            color: "var(--textColor)",
                                          }}
                                        >
                                          Last Month
                                        </p>
                                      </div>
                                    )
                                )} */}
                            </div>
                          </div>
                        </div>
                      </Col>
                    )
                  );
                })}
            </Row>
          </Col>
          <Col lg="4" className="gx-3 gy-3">
            <div className="dashboardMainAccountCard d-flex flex-column justify-content-between dshProfilediv">
              <div className="metaDiv">
                <div className="topProfile">
                  <img src={profileImg || User} alt="Profile Image" />
                  <AiFillPlusCircle
                    onClick={() =>
                      navigate("profile", { state: { activeTab: "image" } })
                    }
                    className="addIcon"
                  />
                </div>

                <div
                  className=" justify-content-center gap-2 profileReferLink"
                  style={{ color: "var(--colorPrimary)" }}
                >
                  <button
                    className="btnPrimary d-flex gap-2 justify-content-center"
                    style={{ width: "max-content" }}
                    onClick={referButton}
                  >
                    Refer a Friend
                    <FaUserFriends size={18} />
                  </button>
                  {isReferOpen && (
                    <ReferPopUp
                      link={`${window.location.origin}/register?ref=${profileData?.username}`}
                      isOpen={referButton}
                      onClose={referButton}
                    />
                  )}
                </div>

                <div className="dashboardProfile">
                  <p>Username:</p>
                  <p>{profileData?.username}</p>
                </div>
                <div className="dashboardProfile">
                  <p>Name:</p>
                  <p>{profileData?.name}</p>
                </div>
                <div className="dashboardProfile">
                  <p>Joining Date:</p>
                  <p>{moment(profileData?.joining_date).format("DD MMM YY")}</p>
                </div>
                <div className="dashboardProfile">
                  <p>Activation Date:</p>
                  <p>
                    {profileData?.Activation_date
                      ? moment(profileData.Activation_date).format("DD MMM YY")
                      : "Inactive"}
                  </p>
                </div>
                <div className="dashboardProfile">
                  <p>Rank:</p>
                  <p>{profileData?.myrank?.rankName || "Not Achived Yet"}</p>
                </div>
                <div className="dashboardProfile">
                  <p>Sponsor Name:</p>
                  <p>{profileData?.sponsor_name || "Admin"}</p>
                </div>
                {profileData?.overall_kyc_status && (
                  <div className="dashboardProfile">
                    <p>Kyc Status:</p>
                    <p>
                      <span
                        style={{
                          height: "10px",
                          width: "10px",
                          borderRadius: "50%",
                          display: "inline-block",
                          backgroundColor:
                            profileData?.overall_kyc_status === "approved"
                              ? "green"
                              : profileData?.overall_kyc_status === "rejected"
                              ? "red"
                              : "orange",
                        }}
                      ></span>{" "}
                      {profileData?.overall_kyc_status}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {link && (
              <div className="dashboardLinkCard">
                <h2>Link</h2>
                <div className="dashboardProfile">
                  <p>Title:</p>
                  <p>{link?.title}</p>
                </div>
                <div className="dashboardProfile">
                  <p>Description:</p>
                  <p>
                    {" "}
                    {link?.description.length > 10 ? (
                      <>
                        {`${link?.description.substring(0, 10)}... `}
                        <button
                          className="read-more-btn"
                          onClick={handleShowModal}
                          style={{
                            color: "rgb(0, 0, 0)",
                            background: "none",
                            border: "none",
                            cursor: "pointer",
                          }}
                        >
                          Read More
                        </button>
                      </>
                    ) : (
                      link?.description
                    )}
                  </p>

                  {isModalOpen && (
                    <div className="linkPopup">
                      <div className="linkPopupContent">
                        <h4
                          className="text-center"
                          style={{ marginBottom: "10px" }}
                        >
                          {link?.title}
                        </h4>
                        <p
                          style={{ textAlign: "center", marginBottom: "10px" }}
                        >
                          {link?.description}
                        </p>
                        <p style={{ marginBottom: "15px" }}>
                          {" "}
                          <a
                            href={link?.meetingLink}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            {link?.meetingLink}
                          </a>
                        </p>
                        <button
                          className="btnPrimary linkClosePopup"
                          onClick={handleCloseModal}
                        >
                          Close
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                <div className="dashboardProfile">
                  <p>Link:</p>
                  <p style={{ width: "185px", wordBreak: "break-word" }}>
                    <a
                      href={link?.meetingLink}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {link?.meetingLink}
                    </a>
                  </p>
                </div>
                {link?.startTime == null &&
                link?.endTime == null ? null : link?.startTime == null ? (
                  <div className="dashboardProfile">
                    <p>End Time:</p>
                    <p>{moment(link?.endTime).format("DD MMM YY")}</p>
                  </div>
                ) : link?.endTime == null ? (
                  <div className="dashboardProfile">
                    <p>Start Time:</p>
                    <p>{moment(link?.startTime).format("DD MMM YY")}</p>
                  </div>
                ) : (
                  <>
                    {" "}
                    <div className="dashboardProfile">
                      <p>Start Time:</p>
                      <p>{moment(link?.startTime).format("DD MMM YY")}</p>
                    </div>
                    <div className="dashboardProfile">
                      <p>End Time:</p>
                      <p>{moment(link?.endTime).format("DD MMM YY")}</p>
                    </div>
                  </>
                )}
              </div>
            )}
          </Col>
        </Row>
        <Row md="12" className="mt-3">
          {/* Fund Deposit */}
          <Col lg="4" className="mb-2">
            <div className="addfundDiv dashFundDiv inputPrimary">
              <div className="d-flex justify-content-center align-items-center">
                {/* <img src={deposit} width="30px" /> */}
                <h1>Deposit</h1>
              </div>

              <div className="subscriptionWallets">
                {incomeData?.map((x, i) => {
                  return (
                    x?.name == "Fund Wallet" && (
                      <div className="fundWallet">
                        <p>{x?.name}</p>
                        <h5>
                          {companyData?.currency_sign}
                          {x?.value && (x?.value).toFixed(2)}
                        </h5>
                      </div>
                    )
                  );
                })}
              </div>
              <label htmlFor="Amount">Amount ({companyData?.currency})</label>
              <input
                type="number"
                className="inputPrimary"
                placeholder="Enter Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <p className="errorMsg">{amountError}</p>
              <button className="btnPrimary mt-3" onClick={handleDeposit}>
                Deposit
              </button>
            </div>
          </Col>
          <Col lg="4" className="mb-2">
            {showOtp == true ? (
              <div className="otpSection">
                <div className="otpContainer">
                  <h1>OTP</h1>
                  <p>OTP sent to your registered email address</p>
                  <input
                    type="text"
                    maxLength={6}
                    size={6}
                    placeholder="Enter OTP"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                  />
                  <p className="errorMsg">{otpError}</p>
                  {otpLoading ? (
                    <div className="otpLoading"></div>
                  ) : (
                    <div>
                      <button
                        className="btnSecondary"
                        onClick={() => (setOtp(""), setShowOtp(false))}
                      >
                        Cancel
                      </button>
                      <button className="btnPrimary" onClick={FundTransferFunc}>
                        Submit
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : null}
            <div className="addfundDiv dashFundDiv inputPrimary">
              <h1>Fund Converter</h1>
              <div className="subscriptionWallets">
                {incomeData?.map((x, i) => {
                  return (
                    x?.name == "Main Wallet" && (
                      <div className="fundWallet">
                        <p>{x?.name}</p>
                        <h5>
                          {companyData?.currency_sign}
                          {x?.value && (x?.value).toFixed(2)}
                        </h5>
                      </div>
                    )
                  );
                })}
              </div>
              <p className="errorMsg">{userIdError}</p>
              <label htmlFor="Amount">
                Amount ({companyData?.currency_sign})
              </label>
              <input
                min={1}
                required
                type="number"
                placeholder="Enter Amount"
                value={convertAmount}
                onChange={(e) => setConvertAmount(e.target.value)}
              />
              <p className="errorMsg">{amountError}</p>
              <button className="btnPrimary mt-3" onClick={FundConvert}>
                Proceed
              </button>
            </div>
          </Col>
          <Col lg="4" className="mb-2">
            <Row md="12" className="mt-2">
              <Col md="12" className="mb-2">
                <div className="dashboardIncomeCard" style={{ height: "100%" }}>
                  <div className="dashboardData">
                    <div>
                      <h5
                        className="dashboardCardHeading"
                        style={{ textTransform: "capitalize" }}
                      >
                        Total Connections
                      </h5>
                      <h1>{teamData?.sum?.total_team || "0"}</h1>
                    </div>
                    <div>
                      <i
                        style={{ cursor: "pointer" }}
                        onClick={() => {
                          navigate("generation_team");
                        }}
                      >
                        <HiMiniUserGroup size={30} />
                      </i>
                    </div>
                  </div>
                </div>
              </Col>
              <Col md="12" className="mb-2">
                <div className="dashboardIncomeCard" style={{ height: "100%" }}>
                  <div className="dashboardData">
                    <div>
                      <h5
                        className="dashboardCardHeading"
                        style={{ textTransform: "capitalize" }}
                      >
                        Prime Connections{" "}
                      </h5>
                      <h1>{teamData?.teamSection?.[0]?.total_team || "0"}</h1>
                    </div>
                    <div>
                      <i
                        style={{ cursor: "pointer" }}
                        onClick={() => {
                          navigate("direct_team");
                        }}
                      >
                        <RiGroup2Fill size={30} />
                      </i>
                    </div>
                  </div>
                </div>
              </Col>
              <Col md="12" className="mb-2">
                <div className="dashboardIncomeCard">
                  <div className="dashboardData">
                    <div>
                      <h5
                        className="dashboardCardHeading"
                        style={{ textTransform: "capitalize" }}
                      >
                        Total Business{" "}
                      </h5>
                      <h1>
                        {companyData?.currency}{" "}
                        {/* {teamData?.sum?.business
                          ? parseFloat(teamData?.sum?.business).toFixed(2)
                          : "0.00"} */}
                        {teamData?.sum
                          ? (
                              (teamData?.sum?.coin_staking || 0) +
                              (teamData?.sum?.fd_business || 0) +
                              (teamData?.sum?.hybride_business || 0) +
                              (teamData?.sum?.sip_business || 0)
                            ).toFixed(2)
                          : "0.00"}
                      </h1>
                    </div>
                    <div>
                      <i>
                        <MdBusinessCenter size={30} />
                      </i>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
        <h1 className="textHeading mt-2">Investment Plan Business</h1>
        <Row md="12" className="mt-2">
          <Col md="3" className="mb-2">
            <div className="dashboardIncomeCard" style={{ height: "100%" }}>
              <div className="dashboardData">
                <div>
                  <h5
                    className="dashboardCardHeading"
                    style={{ textTransform: "capitalize" }}
                  >
                    FD Business
                  </h5>
                  <h1>
                    {companyData?.currency} {teamData?.sum?.fd_business || "0"}
                  </h1>
                </div>
                {/* <div>
                  <i>
                    <HiMiniUserGroup size={30} />
                  </i>
                </div> */}
              </div>
            </div>
          </Col>
          <Col md="3" className="mb-2">
            <div className="dashboardIncomeCard" style={{ height: "100%" }}>
              <div className="dashboardData">
                <div>
                  <h5
                    className="dashboardCardHeading"
                    style={{ textTransform: "capitalize" }}
                  >
                    Hybrid Business
                  </h5>
                  <h1>
                    {companyData?.currency}{" "}
                    {teamData?.sum?.hybride_business || "0"}
                  </h1>
                </div>
              </div>
            </div>
          </Col>
          <Col md="3" className="mb-2">
            <div className="dashboardIncomeCard" style={{ height: "100%" }}>
              <div className="dashboardData">
                <div>
                  <h5
                    className="dashboardCardHeading"
                    style={{ textTransform: "capitalize" }}
                  >
                    SIP Business
                  </h5>
                  <h1>
                    {companyData?.currency} {teamData?.sum?.sip_business || "0"}
                  </h1>
                </div>
                {/* <div>
                  <i>
                    <HiMiniUserGroup size={30} />
                  </i>
                </div> */}
              </div>
            </div>
          </Col>
          <Col md="3" className="mb-2">
            <div className="dashboardIncomeCard" style={{ height: "100%" }}>
              <div className="dashboardData">
                <div>
                  <h5
                    className="dashboardCardHeading"
                    style={{ textTransform: "capitalize" }}
                  >
                    Coin Staking
                  </h5>
                  <h1>
                    {companyData?.currency} {teamData?.sum?.coin_staking || "0"}
                  </h1>
                </div>
                {/* <div>
                  <i>
                    <HiMiniUserGroup size={30} />
                  </i>
                </div> */}
              </div>
            </div>
          </Col>
        </Row>
        <Row>
          <Col md="12" lg="12" className="mb-2">
            <div className="transactionDiv mt-2">
              <h1>Recent Transaction History</h1>
              <div className="table">
                <table style={{ width: "100%" }}>
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>Amount ({companyData?.currency_sign})</th>
                      <th>Source</th>
                      <th>Date</th>
                      <th>Credit / Debit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentHistory.length && recentHistory?.status != 2 ? (
                      recentHistory?.map((x, i) => (
                        <tr key={i}>
                          <td style={{ textAlign: "center" }}>{i + 1}</td>
                          <td style={{ textAlign: "center" }}>
                            {parseFloat(x?.amount).toFixed(2)}
                          </td>
                          <td>
                            {x?.source?.toUpperCase().split("_").join(" ")}
                          </td>
                          <td style={{ textAlign: "center" }}>
                            {moment(x?.time).format("DD MMM YY")}
                          </td>
                          <td>
                            {x?.status === 1 ? x?.debit_credit : "Pending"}
                          </td>
                          {/* {x?.debit_credit == "debit" ? (
                            <td style={{ textAlign: "center" }}>
                              Send to {x?.from} ({x?.name})
                            </td>
                          ) : (
                            <td style={{ textAlign: "center" }}>
                              Received from {x?.from} ({x?.name})
                            </td>
                          )} */}
                        </tr>
                      ))
                    ) : (
                      <p>No history yet</p>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </Col>
        </Row>
      </section>
    </>
  );
};

export default Dashboard;
