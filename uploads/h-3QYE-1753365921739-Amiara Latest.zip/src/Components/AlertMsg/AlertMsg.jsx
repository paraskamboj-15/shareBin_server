import React, { useEffect } from "react";
import "./AlertMsg.css";
const AlertMsg = () => {
  useEffect(() => {
    console.log("jdfbjdbf jobdbo");
  });

  return <div>AlertMsg</div>;
};

export default AlertMsg;
