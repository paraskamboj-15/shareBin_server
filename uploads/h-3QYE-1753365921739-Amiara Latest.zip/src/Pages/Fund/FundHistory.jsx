import React, { useEffect, useState } from "react";
import { MdOutlineFilterList } from "react-icons/md";
import { ApiPaths } from "./../../Config/ApiPath";
import Loader from "./../../Components/Loader/Loader";
import PaginationComponent from "./../../Components/PaginationControls/PaginationControls";
import useAxiosHelper from "./../../Common/AxiosHelper";
import { useSelector } from "react-redux";
import { Row, Col } from "react-bootstrap";
// import "./FundHistory.css";
import { BasicInfo } from "./../../Config/BasicInfo";
import { AiOutlineClose } from "react-icons/ai";
import { FiMaximize2 } from "react-icons/fi";
import moment from "moment";

const FundHistory = ({ status }) => {
  const [filterVisibility, setFilterVisibility] = useState(false);
  const [loading, setLoading] = useState(false);
  const [paymentTransaction, setPaymentTransaction] = useState([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [totalPages, setTotalPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedImage, setSelectedImage] = useState(null); // State to manage selected image
  const { AxiosGet } = useAxiosHelper();
  const incomeData = useSelector((state) => state.incomeData?.incomeWallet);
  const [search, setSearch] = useState({
    startDate: "",
    endDate: "",
  });
  const [companyData, setCompanyData] = useState([])
  useEffect(() => {
    CompanyInfo();
  }, []);
  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      // console.log(JSON.parse(data));
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }

  useEffect(() => {
    FetchData(currentPage);
  }, [status, currentPage]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(name, value);
    setSearch((prev) => ({ ...prev, [name]: value }));
  };

  const AddFilter = () => {
    const queryParams = {
      page: currentPage,
      limit: 20,
      ...Object.fromEntries(
        Object.entries(search).filter(
          ([_, value]) => value !== "" && value !== 0
        )
      ),
    };
    FetchData(queryParams);
  };

  const FetchData = async (page) => {
    try {
      const filteredSearch = Object.fromEntries(
        Object.entries(search).filter(([key, value]) => value !== "")
      );

      const filters = {
        source: "add_fund",
        status: status,
        ...filteredSearch,
      };
      const queryParams = {
        page: page,
        limit: 20,
        ...filters,
      };

      setLoading(true);
      const response = await AxiosGet(
        `${ApiPaths.getPaymentTransaction}?${new URLSearchParams(
          queryParams
        ).toString()}`
      );
      BasicInfo.isDebug && console.log("Fund history", response);

      setPaymentTransaction(response?.data || []);
      setTotalPages(response?.totalPages || 1);
    } catch (error) {
      console.error("Error fetching payment transactions:", error);
    } finally {
      setLoading(false);
    }
  };

  const handlePagination = (page) => {
    setCurrentPage(page);
  };

  function resetData() {
    setSearch({
      startDate: "",
      endDate: "",
    });
  }

  useEffect(() => {
    if (search.startDate === "" && search.endDate === "") {
      FetchData();
    }
  }, [search]);
  const handleSearch = () => {
    setCurrentPage(1); // Reset to first page on search
    FetchData(1);
  };

  const openImagePopup = (imageUrl) => {
    setSelectedImage(imageUrl); // Set selected image for popup
  };

  const closeImagePopup = () => {
    setSelectedImage(null); // Close popup by setting image to null
  };

  return (
    <>
      {loading && <Loader />}

      <section>
        <div className="incomeSelectBox">
          <button onClick={() => setFilterVisibility(!filterVisibility)}>
            {filterVisibility ? "Hide Filters" : "Show Filters"}
            <i>
              <MdOutlineFilterList />
            </i>
          </button>
        </div>
        {filterVisibility && (
          <section className="filtersection inputPrimary">
            <Row>
              <Col lg="2" md="4" xs="12">
                <input
                  type="date"
                  placeholder="From Date"
                  name="startDate"
                  value={search.startDate}
                  onChange={handleChange}
                />
              </Col>
              <Col lg="2" md="4" xs="12">
                <input
                  type="date"
                  placeholder="End Date"
                  name="endDate"
                  value={search.endDate}
                  onChange={handleChange}
                />
              </Col>
              <Col lg="2" md="4" xs="6">
                <button onClick={AddFilter}>Search</button>
              </Col>
              <Col lg="2" md="4" xs="6">
                <button onClick={resetData}>Reset</button>
              </Col>
            </Row>
          </section>
        )}

        <section className="history">
          <h1 className="textHeading">Fund History</h1>
          <div className="table">
            <table>
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Amount ({companyData?.currency_sign})</th>
                  {/* <th>Status</th> */}
                  <th>Tx ID</th>
                  <th>Proof</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {paymentTransaction.length ? (
                  paymentTransaction.map((x, i) => (
                    <tr key={i}>
                      <td style={{ textAlign: "center" }}>{i + 1}</td>
                      <td style={{ textAlign: "center" }}>
                        {parseFloat(x?.amount).toFixed(2)}
                      </td>
                      {/* <td style={{ textAlign: "center" }}>
                      {x?.status === 1 ? "Approved" : x?.status === 0 ? "Processing" : "Error"}
                      </td> */}
                      <td style={{ textAlign: "center" }}>{x?.reqest_tx_Id}</td>
                      <td className="proofView">
                        <img
                          src={x?.proofUrl}
                          width={50}
                          height={50}
                          style={{ cursor: "pointer", objectFit: "contain" }}
                        />
                        <i onClick={() => openImagePopup(x?.proofUrl)}>
                          <FiMaximize2 />
                        </i>
                      </td>
                      <td style={{ textAlign: "center" }}>{moment(x?.time).format("DD MMM YY")}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td style={{ textAlign: "center" }} colSpan="5">
                      No history yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            {paymentTransaction.length > 0 && (
              <PaginationComponent
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePagination}
              />
            )}
          </div>
        </section>

        {/* Image Popup */}
        {/* {selectedImage && (
          <div className="popup">
            <div className="popup-content d-flex justify-content-center">
              <span className="close-icon" style={{ color: "var(--textColor)", fontSize: "10px" }} onClick={closeImagePopup}>
                <AiOutlineClose />
              </span>
              <img src={selectedImage} alt="proof" height="150px" className="popup-image" />
            </div>
          </div>
        )} */}



        {selectedImage && (
          <div className="popup" style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0, 0, 0, 0.7)", // Translucent background
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 1000, // Ensure it stays on top
            backdropFilter: "blur(8px)"
          }}>
            <div className="popup-content" style={{ position: "relative" }}>
              <span className="close-icon"
                style={{
                  color: "var(--textColor)",
                  fontSize: "20px",
                  position: "absolute",
                  top: "10px",
                  right: "10px",
                  cursor: "pointer"
                }}
                onClick={closeImagePopup}>
                <AiOutlineClose />
              </span>
              <img src={selectedImage} alt="proof"
                style={{ maxHeight: "80vh", maxWidth: "90vw" }}
                className="popup-image" />
            </div>
          </div>
        )}

      </section>
    </>
  );
};

export default FundHistory;
