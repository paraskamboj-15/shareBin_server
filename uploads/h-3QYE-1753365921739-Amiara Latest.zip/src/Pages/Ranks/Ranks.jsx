import React, { useEffect, useState } from "react";
import { ApiPaths } from "../../Config/ApiPath";
import Loader from "../../Components/Loader/Loader";
import useAxiosHelper from "../../Common/AxiosHelper";
import { toastSuccess, toastFailed } from "../../Common/Data";
import moment from "moment/moment";
import { BasicInfo } from "../../Config/BasicInfo";
import { Col, Row } from "react-bootstrap";

const Ranks = () => {
  const [loading, setLoading] = useState(false);
  const [rewardData, setRewardData] = useState([]);
  const [selectedValues, setSelectedValues] = useState({});
  const [companyData, setCompanyData] = useState();
  const { AxiosGet } = useAxiosHelper();
  useEffect(() => {
    FetchData();
    CompanyInfo();
  }, []);

  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }
  const FetchData = async () => {
    try {
      setLoading(true);
      const tempRank = await AxiosGet(ApiPaths.getRanks);
      setRewardData(tempRank);
    } catch (error) {
      BasicInfo.isDebug && console.error("Error fetching payment transactions:", error);
    } finally {
      setLoading(false);
    }
  };

  // Get current rank name (assuming first rank is the current one)
  const rankName = rewardData.find(item => item.status === 0);
  const currentRank = rankName ? rankName.rankname : "No Rank";

  const requiredBusiness = (rankName?.required_business) / 2; // Example: Required business value
  const achievedBusinessTop = (rankName?.top); // Example: Achieved business value
  const achievedBusinessBottom = (rankName?.down); // Example: Achieved business value

  // Calculate progress percentage
  const progressofTop = (achievedBusinessTop / requiredBusiness) * 100;
  const progressofBottom = (achievedBusinessBottom / requiredBusiness) * 100;

  return (
    <>
      {loading ? <Loader /> : null}
      <section className="dashboard">
        <section className="history">
          <h1 className="textHeading">Ranks</h1>

          {/* Progress Bar Section */}
          <h4 className="d-flex justify-content-center">{currentRank}</h4>
          <Row md="12" className="justify-content-around gap-10 m-0">
            <Col md="5" className="progress-section">
              <h5>1-3 Level</h5>
              <div className="progress-container">
                <div
                  className="progress-bar"
                  style={{
                    width: `${progressofTop}%`,
                    maxWidth: "100%",
                    backgroundColor: progressofTop === 100 ? "var(--lightColor)" : "var(--colorPrimary)",
                  }}
                />
              </div>
              <div className="progress-info">
                {/* <span>{`Achieved: ${achievedBusiness}`}</span>
              <span>{`Required: ${requiredBusiness}`}</span> */}
                <span>{`Progress: ${Math.min(progressofTop, 100).toFixed(2)}%`}</span>
              </div>
            </Col>
            <Col md="5" className="progress-section">
              <h5>4-10 Level</h5>
              <div className="progress-container">
                <div
                  className="progress-bar"
                  style={{
                    width: `${progressofBottom}%`,
                    maxWidth: "100%",
                    backgroundColor: progressofBottom === 100 ? "var(--lightColor)" : "var(--colorPrimary)",
                  }}
                />
              </div>
              <div className="progress-info">
                {/* <span>{`Achieved: ${achievedBusiness}`}</span>
              <span>{`Required: ${requiredBusiness}`}</span> */}
                <span>{`Progress: ${Math.min(progressofBottom, 100).toFixed(2)}%`}</span>
              </div>
            </Col>
          </Row>

          <div className="table">
            <table>
              <thead>
                {rewardData &&
                  Array.isArray(rewardData) &&
                  rewardData.length > 0 && (
                    <tr>
                      <th>S.No</th>
                      <th>Rank</th>
                      <th>Total Business ({companyData?.currency_sign})</th>
                      <th>1-3 Level/ Required Business ({companyData?.currency_sign}) </th>
                      <th>4-10 Level/ Required Business ({companyData?.currency_sign})</th>
                      <th>Status</th>
                      <th>Achieved Date</th>
                    </tr>
                  )}
              </thead>
              <tbody>
                {rewardData &&
                  Array.isArray(rewardData) &&
                  rewardData.length > 0 ? (
                  rewardData.map((x, i) => (
                    <tr key={x?.rankId}>
                      <td>{i + 1}</td>
                      <td>{x?.rankname}</td>
                      <td>
                        {x?.required_business}
                      </td>
                      <td>{x?.top} / {x?.required_business / 2}
                      </td>
                      <td>{x?.down} / {x?.required_business / 2}
                      </td>


                      <td>
                        {x?.status == "0" ? (
                          "Pending"
                        ) : (
                          <>
                            {x?.rewardClaimStatus === 0 ? (
                              "Achived"
                            ) : (
                              <>
                                {x?.paid === 0 ? (
                                  <div
                                    style={{ color: "yellow", border: "none" }}
                                  >
                                    Claim Requested
                                  </div>
                                ) : x?.paid === 2 ? (
                                  <div style={{ color: "red", border: "none" }}>
                                    Rejected
                                  </div>
                                ) : (
                                  <div
                                    style={{ color: "green", border: "none" }}
                                  >
                                    Achieved
                                  </div>
                                )}
                              </>
                            )}
                          </>
                        )}
                      </td>
                      <td>
                        {x?.rewardAchievedDate && x.rewardAchievedDate !== '-'
                          ? moment(x.rewardAchievedDate).format("DD MMM YY")
                          : '-'}
                      </td>

                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="8">No history yet</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </section>
    </>
  );
};

export default Ranks;
