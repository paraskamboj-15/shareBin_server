import React from 'react';
import './CallButton.css'; // Optional: For custom styling if needed
import { FaPhoneAlt, FaPhoneSquare } from "react-icons/fa";
import { BsFillTelephoneOutboundFill } from "react-icons/bs";


// CallButton component
const CallButton = ({ phoneNumber }) => {
  return (
    <div className="call-button-container">
      {/* Tel link to initiate the phone call */}
      <a href={`tel:${phoneNumber}`} className="call-button">
      {phoneNumber} <i className="fas fa-phone-alt"> <BsFillTelephoneOutboundFill />
      </i> 
      </a>
    </div>
  );
};

export default CallButton;
