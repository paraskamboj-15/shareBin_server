import React, { useEffect, useState } from "react";
import { useDropzone } from "react-dropzone";
import { FiUploadCloud } from "react-icons/fi";
import { Col, Row } from "react-bootstrap";
import { MdOutlineModeEdit } from "react-icons/md";
import useAxiosHelper from "./../../Common/AxiosHelper";
import { ApiPaths } from "./../../Config/ApiPath";
import { BasicInfo, toastFailed, toastSuccess } from "./../../Config/BasicInfo";
import imageCompression from "browser-image-compression";
import "./Support.css";
import moment from "moment/moment";
import { FiMaximize2 } from "react-icons/fi";
import { AiOutlineClose } from "react-icons/ai";
import { IoIosAdd } from "react-icons/io";
import { PiChatTextLight } from "react-icons/pi";

const Support = () => {
  const { AxiosPost, AxiosGet } = useAxiosHelper();
  const [files, setFiles] = useState([]);
  const [ticketType, setTicketType] = useState("");
  const [ticketList, setTicketList] = useState();
  const [description, setDescription] = useState("");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [previews, setPreviews] = useState([]);
  const [ticketsData, setTicketsData] = useState([]);
  const [selectedImage, setSelectedImage] = useState(null); // State to manage selected image

  const onDrop = async (acceptedFiles) => {
    const compressedFiles = await Promise.all(
      acceptedFiles.map(async (file) => {
        const options = {
          maxSizeMB: 1, // Maximum file size in MB
          maxWidthOrHeight: 1024, // Maximum width or height in pixels
          useWebWorker: true,
        };
        try {
          return await imageCompression(file, options);
        } catch (err) {
          console.error("Error compressing image:", err);
          return file;
        }
      })
    );

    setFiles(compressedFiles);
    setPreviews(compressedFiles.map((file) => URL.createObjectURL(file)));
  };
  const uploadFiles = async () => {
    setUploading(true);
    setError(null);

    const formData = new FormData();
    files.forEach((file) => {
      formData.append("attachments", file);
    });

    // Append additional data
    formData.append("subject", ticketType);
    formData.append("description", description);

    for (let [key, value] of formData.entries()) {
      console.log(`${key}: ${value}`);
    }

    try {
      const response = await AxiosPost(ApiPaths.createTicket, formData);
      BasicInfo.isDebug && console.log("Upload success:", response);
      setFiles([]);
      setPreviews([]);
      setTicketType("");
      setDescription("");
      toastSuccess(response?.message);
      FetchTickets();
    } catch (err) {
      console.error("Upload error:", err);
      setError("Failed to upload files. Please try again.");
      toastFailed(err?.response?.data?.message);
    } finally {
      setUploading(false);
    }
  };
  const { getRootProps, getInputProps } = useDropzone({ onDrop });
  useEffect(() => {
    FetchTickets();
    FetchTicketsTypes();
  }, []);
  const openImagePopup = (imageUrl) => {
    setSelectedImage(imageUrl); // Set selected image for popup
  };
  const closeImagePopup = () => {
    setSelectedImage(null); // Close popup by setting image to null
  };
  const handleClearPreview = (index) => {
    // Remove the preview at the specified index
    setPreviews(prevPreviews => prevPreviews.filter((_, i) => i !== index));
  };
  async function FetchTickets() {
    try {
      const res = await AxiosGet(ApiPaths?.getTickets);
      console.log("res", res);
      setTicketsData(res);
    } catch (error) {
      console.log(error);
    }
  }
  async function FetchTicketsTypes() {
    try {
      const res = await AxiosGet(ApiPaths?.getTicketsType);
      console.log("FetchTicketsTypes==>", res);
      setTicketList(res);
    } catch (error) {
      console.log(error);
    }
  }
  const handleChat = (ticketId, status) => {
    console.log(ticketId, status, "ticketId and status");

    if (ticketId) {
      if (status) {
        // Create a query string using only the ticketId
        const queryParams = new URLSearchParams({ ticketId, status }).toString();

        // Navigate to the tickets route with the ticketId as a query parameter
        window.location.href = `tickets?${queryParams}`;
      } else {
        // Show a toast message if the ticket status is not 'open'
        toastFailed("Ticket is not active");
      }
    } else {
      // Handle cases where ticketId is missing
      toastFailed("Invalid ticket ID");
    }
  };

  return (
    <div className="dashbord">
      <Row className="mt-5">
        <Col md="12" className="mb-4">
          <div className="myProfileInputField">
            <span id="myProfileInputFieldTitle">Ticket Type</span>
            <select
              id="myProfileInputFieldInput"
              className="bg-transparent"
              value={ticketType}
              onChange={(e) => setTicketType(e.target.value)}
            >
              <option value="" disabled>
                Select Ticket Type
              </option>
              {ticketList?.length > 0 &&
                ticketList.map((ticket, index) => (
                  <option key={index} value={ticket?.title}>
                    {ticket?.title}
                  </option>
                ))}
            </select>
          </div>
        </Col>
        <Col md="12">
          <div className="myProfileInputField">
            <span id="myProfileInputFieldTitle">Description</span>
            <input
              id="myProfileInputFieldInput"
              type="text"
              placeholder="Please write your query here"
              value={description}
              onChange={(e) => setDescription(e.target.value.toUpperCase())}
            />
            <i id="myProfileInputFieldIcon">
              <MdOutlineModeEdit />
            </i>
          </div>
        </Col>
      </Row>
      <div className="file-upload-container">
        <div {...getRootProps({ className: "dropzone" })}>
          <input {...getInputProps()} />
          {previews.length > 0 ? (
            <div className="previews">
              {previews.map((preview, index) => (
                <div key={index} className="preview">
                  <img src={preview} alt={`Preview ${index}`} />
                  <button
                    className="clear-preview"
                    onClick={() => handleClearPreview(index)}
                    aria-label={`Remove preview ${index}`}
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="d-flex">
              <i>
                <IoIosAdd />
              </i>
              <p>Drop your files here</p>
            </div>
          )}
        </div>
        <button
          className="upload-button"
          onClick={uploadFiles}
          // disabled={uploading || files.length === 0}
        >
          <i>
            <FiUploadCloud />
          </i>
          {uploading ? "Submitting..." : "Submit"}
        </button>
        {error && <p className="error-message">{error}</p>}
      </div>
      <div className="table supportTable">
        <table className="w-100">
          <thead>
            <tr>
              <th>Sr No.</th>
              <th>Ticket Type</th>
              <th>Description</th>
              <th>Image</th>
              <th>Date & Time</th>
              <th>Status</th>
              <th>Chat</th>
            </tr>
          </thead>
          <tbody>
            {Array.isArray(ticketsData) &&
              ticketsData?.map((x, i) => {
                return (
                  <tr>
                    <td>{i + 1}</td>
                    <td>{x?.subject}</td>
                    <td style={{ minWidth: "250px",whiteSpace:"break-spaces" }}>{x?.description}</td>
                    <td className="proofView">
                      <img
                        src={x?.attachments[0]}
                        width={50}
                        height={50}
                        style={{ cursor: "pointer", objectFit: "contain" }}
                      />
                      <i onClick={() => openImagePopup(x?.attachments[0])}>
                        <FiMaximize2 />
                      </i>
                    </td>
                    <td>
                      {moment(x?.created_at).format("DD-MM-YYYY   &   HH:mm")}
                    </td>
                    <td>
                      {x?.status}
                    </td>
                    <td>
                      <button className="btnPrimary d-flex justify-content-around align-items-center" onClick={() => handleChat(x?.ticketId, x?.status)}> <PiChatTextLight size={20} />
                        Chat</button>
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>
      {selectedImage && (
        <div className="popup" style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(0, 0, 0, 0.7)", // Translucent background
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          zIndex: 1000, // Ensure it stays on top
          backdropFilter: "blur(8px)"
        }}>
          <div className="popup-content" style={{ position: "relative" }}>
            <span className="close-icon"
              style={{
                color: "var(--textColor)",
                fontSize: "20px",
                position: "absolute",
                top: "10px",
                right: "10px",
                cursor: "pointer"
              }}
              onClick={closeImagePopup}>
              <AiOutlineClose />
            </span>
            <img src={selectedImage} alt="proof"
              style={{ maxHeight: "80vh", maxWidth: "90vw" }}
              className="popup-image" />
          </div>
        </div>
      )}
    </div>
  );
};

export default Support;
