import React, { useEffect, useState } from "react";
import "./Plans.css";
import { Row } from "react-bootstrap";
import Loader from "../../Components/Loader/Loader";
import { useDispatch, useSelector } from "react-redux";
import { ApiPaths } from "../../Config/ApiPath";
import { AiOutlineUser } from "react-icons/ai";
import useAxiosHelper from "../../Common/AxiosHelper";
import { setUserPersonalInfo } from "../../Redux/ProfileDataSlice";
import { setIncomeWallet } from "../../Redux/IncomeWallet";
import { BasicInfo, toastFailed, toastSuccess } from "../../Config/BasicInfo";
import ArrayToObject from "../../Common/ArrayToObject";
import OrderHistory from "./CoinStackingOrder";
import { useNavigate } from "react-router-dom";
import moment from "moment";
import TermAndConditions from "../../Components/PaymentT&C/TermAndConditions";
import animationData from "./../../Components/animation/celebration.json";
import Lottie from "react-lottie";
import { toastInfo } from "../../Common/Data";

const CoinStacking = () => {
  const dispatch = useDispatch();
  const [typingTimeout, setTypingTimeout] = useState(null);
  const [loading, setLoading] = useState(false);
  const [load, setLoad] = useState(false);
  const [existUserName, setExistUserName] = useState();
  const [amount, setAmount] = useState();
  const [amountError, setAmountError] = useState("");
  const [username, setUsername] = useState("");
  const [fundBalance, setFundBalance] = useState();
  const [selectIncome, setSelectIncome] = useState();
  const [selectPackage, setSelectPackage] = useState([]);
  const [sponsorLoading, setSponsorLoading] = useState(false);
  const { AxiosPost, AxiosGet } = useAxiosHelper();
  const incomeData = useSelector((state) => state.incomeData.incomeWallet);
  const profileData = useSelector(
    (state) => state.profileData.userPersonalInfo
  );
  const [showPopUp, setShowPopUp] = useState(false);
  const [planId, setPlanId] = useState();
  const navigate = useNavigate();
  const [topUpSuccess, setTopUpSuccess] = useState(false);
  const [sponsorName, setSponsorName] = useState("");
  const [companyData, setCompanyData] = useState([]);
  const [monthlyIntrest, setMonthlyIntrest] = useState("");

  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      console.log(error);
    }
  }

  const isUserExist = async () => {
    setLoad(true);

    if (!username) {
      setExistUserName(". . .");
      setLoad(false);
      return;
    }
    try {
      setLoad(true);
      const body = {
        username: username,
      };
      BasicInfo.isDebug && console.log("body", body);
      const res = await AxiosPost(ApiPaths.checkSponsor, body);
      if (res) {
        toastSuccess(res?.message);
        setExistUserName(res.name);
      } else {
        setExistUserName("User not exists");
      }
    } catch (e) {
      toastFailed(e?.response?.data?.message);
      setExistUserName("User not exists");
    } finally {
      setLoad(false);
    }
  };

  useEffect(() => {
    // Clear the timeout when the user is typing
    if (typingTimeout) {
      clearTimeout(typingTimeout);
    }
    // Set a new timeout to call the API after the user stops typing
    setTypingTimeout(
      setTimeout(() => {
        isUserExist();
      }, 500) // 500ms debounce delay
    );

    // Cleanup the timeout when the component is unmounted or when typing continues
    return () => clearTimeout(typingTimeout);
  }, [username]);

  useEffect(() => {
    if (profileData?.username) {
      setUsername(profileData.username);
    }
  }, [profileData]);
  var x = 0;
  useEffect(() => {
    if (x == 0) {
      FetchData();
      fetchIncome();
      CompanyInfo();
      x++;
    }
  }, []);

  async function fetchIncome() {
    try {
      const res = await AxiosGet(ApiPaths.getPackages);
      if (res) {
        setSelectPackage(res?.packages);

        const fixedDepositPackage = res?.packages.find(
          (plan) =>
            plan?.sip_status == "0" &&
            plan?.fd_status == "0" &&
            plan?.hybride_status == "0"
        );
        // Set select income with the value of "Meta F Time Deposit"
        if (fixedDepositPackage) {
          setSelectIncome(fixedDepositPackage.package.name);
          setPlanId(fixedDepositPackage?.planId);
          setMonthlyIntrest(fixedDepositPackage?.roi_income?.income);
        } else {
          BasicInfo.isDebug && console.log(" Time Deposit package not found");
        }
      }
    } catch (e) {
      toastFailed(e?.response?.data?.message);
    }
  }
  async function FetchData() {
    try {
      const [res1, res2] = await Promise.all([
        AxiosGet(ApiPaths.getProfile),
        AxiosGet(ApiPaths.getWallets),
      ]);

      if (res1) {
        dispatch(setUserPersonalInfo(res1));
      }

      if (res2?.wallets) {
        dispatch(setIncomeWallet(res2?.wallets));
        const objectWalletData = ArrayToObject(res2?.wallets);
        setFundBalance(objectWalletData?.fund_wallet?.value);
      }
    } catch (error) {
      toastFailed("Error loading data");
    }
  }
  const [isAccepted, setIsAccepted] = useState(false);
  const [showTermAndConditions, setShowTermAndConditions] = useState(false);
  const handleTerms = () => {
    setIsAccepted(!isAccepted);
  };
  const handleTermAndConditionPopUp = () => {
    setShowTermAndConditions(!showTermAndConditions);
  };
  function checkValidation() {
    // Check if income is selected
    if (!selectIncome) {
      toastFailed("Please select Package");
      return false;
    }
    // Check if amount is greater than 0
    if (amount <= 0) {
      toastFailed("Please enter amount");
      return false;
    }
    // Check if terms and conditions are accepted
    if (!isAccepted) {
      toastFailed("Please accept the terms & conditions");
      return false;
    }
    // Check if the amount is greater than available funds
    if (amount > fundBalance) {
      toastFailed("Insufficient funds");
      return false;
    }

    // If all checks pass, return true
    return true;
  }
  const handleProceedClick = () => {
    const valid = checkValidation();
    if (valid) {
      setShowPopUp(true);
    }
  };
  const handleTopUpSuccess = () => {
    setTopUpSuccess(true);
    setShowPopUp(false);
  };
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  return (
    <>
      {loading ? <Loader /> : null}
      {topUpSuccess ? (
        <section className="registerSuccessDetails">
          <div style={{ position: "absolute", transform: "scale(8)" }}>
            <Lottie options={defaultOptions} height={100} width={300} />
          </div>
          <div style={{ zIndex: "999" }}>
            <div id="successIcon">
              <h1>Success</h1>
            </div>
            <div id="successDetails">
              <p className="mb-4">
                Congratulations your Investment has been successfully saved
              </p>
              <div style={{ display: "block" }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Name:</p>
                  <p className="successData">{username}</p>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Investment Plan:</p>
                  <p className="successData">Amiara Coin Staking</p>
                </div>
                {/* <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Plan Type:</p>
                  <p className="successData">{selectIncome}</p>
                </div> */}
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Monthly Interest:</p>
                  <p className="successData">{monthlyIntrest} %</p>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Package Amount:</p>
                  <p className="successData">
                    {companyData?.currency} {amount}
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  setTopUpSuccess(false);
                  navigate("/dashboard");
                }}
              >
                Continue
              </button>
            </div>
          </div>
        </section>
      ) : null}
      <section className="dashboard">
        <h1 className="textHeadingWithMargin mt-0 mt-4">Amiara Coin Staking</h1>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div className="planDiv">
            <div className="addfundDiv inputPrimary ">
              <h1>Activation</h1>
              <div className="subscriptionWallets">
                {incomeData?.map(
                  (x) =>
                    x?.name === "Fund Wallet" && (
                      <div className="fundWallet" key={x?.name}>
                        <p>Fund Wallet</p>
                        <h5>
                          {" "}
                          {companyData?.currency} {x?.value}
                        </h5>
                      </div>
                    )
                )}
              </div>
              <div className="d-flex">
                <label htmlFor="Amount">User ID</label>
                <label htmlFor="Amount" style={{ textAlign: "end" }}>
                  <span>{load && username ? "Loading..." : existUserName}</span>
                </label>
              </div>
              <div style={{ position: "relative" }}>
                <div>
                  <i
                    style={{
                      position: "absolute",
                      top: 5,
                      left: 2,
                      color: "var(--colorPrimary)",
                    }}
                  >
                    <AiOutlineUser />
                  </i>
                </div>
                <input
                  type="text"
                  style={{ padding: "8px 20px" }}
                  placeholder="Enter User ID"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toUpperCase())}
                />
                {sponsorLoading ? <i id="sponsorLoading"></i> : null}
              </div>

              <label htmlFor="Amount">Amount ({companyData?.currency} )</label>
              <input
                type="number"
                className="inputPrimary"
                placeholder="Enter Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <p className="errorMsg">{amountError}</p>
              <div className="mt-1">
                <label className="d-flex">
                  <input
                    className="w-auto mx-1"
                    style={{ marginBottom: "-1px" }}
                    type="checkbox"
                    checked={isAccepted}
                    onChange={handleTerms}
                  />
                  I agree to{" "}
                  <span
                    className="termAndConditions"
                    onClick={handleTermAndConditionPopUp}
                    style={{ cursor: "pointer", color: "var(--colorPrimary)" }}
                  >
                    Terms & Conditions
                  </span>
                </label>
                {showTermAndConditions && (
                  <TermAndConditions onClose={handleTermAndConditionPopUp} />
                )}
              </div>

              <button className="btnPrimary mt-3" onClick={handleProceedClick}>
                Proceed
              </button>
              {showPopUp && (
                <PopUp
                  amount={amount}
                  planId={planId}
                  username={username}
                  fundBalance={fundBalance}
                  interest={monthlyIntrest}
                  selectIncome={selectIncome}
                  onClose={() => setShowPopUp(false)} // Pass a prop to close the pop-up
                  onTopUpSuccess={handleTopUpSuccess} // Pass a callback for top-up success
                  setShowPopUp={() => setShowPopUp(false)}
                />
              )}
            </div>
          </div>
        </div>
        <OrderHistory />
      </section>
    </>
  );
};

export default CoinStacking;

function PopUp({
  username,
  planId,
  amount,
  selectIncome, // Package name
  interest,
  onClose,
  onTopUpSuccess,
}) {
  const [loading, setLoading] = useState(false);
  const { AxiosPost } = useAxiosHelper();
  const [companyData, setCompanyData] = useState([]);

  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      console.log(error);
    }
  }
  useEffect(() => {
    CompanyInfo();
  }, []);

  async function TopUp() {
    try {
      setLoading(true);
      const body = {
        username,
        planId,
        amount,
      };
      console.log(body, "bodyyy");
      const res = await AxiosPost(ApiPaths.topUp, body);
      const packageTime = res?.date;
      onTopUpSuccess(packageTime); // Pass packageTime to the parent
    } catch (e) {
      toastFailed(e?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div className="otpSection" style={{ zIndex: "999" }}>
        <div className="otpContainer" style={{ width: "400px" }}>
          <p>
            Are you sure you want to proceed with the top-up for the following
            details?
          </p>
          <div style={{ marginBottom: "20px", flexDirection: "column" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong>User ID:</strong>
              </p>
              <p>{username}</p>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong style={{ whiteSpace: "nowrap" }}>
                  Investment Plan:
                </strong>
              </p>
              {/* <p>{selectIncome}</p> */}
              <p>Amiara Coin Staking</p>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong style={{ whiteSpace: "nowrap" }}>
                  Monthly Interest:
                </strong>
              </p>
              <p>{interest} %</p>
            </div>
            {/* <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong>Package Time:</strong>
              </p>
              <p>{moment(packageTime).format("DD-MM-YYYY")}</p>
            </div> */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong>Amount:</strong>
              </p>
              <p>
                {companyData?.currency} {amount}
              </p>
            </div>
          </div>
          <div>
            <button className="btnSecondary" onClick={onClose}>
              No
            </button>
            <button className="btnPrimary" onClick={TopUp} disabled={loading}>
              {loading ? "Processing..." : "Yes"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
