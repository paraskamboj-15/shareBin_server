import React, { useEffect, useState } from "react";
import "./ForgetPassword.css";
import Logo from "./../../Images/logo.png";
import { Container } from "react-bootstrap";
import { AiOutlineUser } from "react-icons/ai";
import { ApiPaths } from "../../Config/ApiPath";
import Loader from "../../Components/Loader/Loader";
import { Link, useNavigate } from "react-router-dom";
import { Data, toastFailed, toastSuccess } from "../../Common/Data";
import "./ForgetPassword.css";
import useAxiosHelper from "../../Common/AxiosHelper";
import { BasicInfo } from "../../Config/BasicInfo";
import { FaRegEye, FaRegEyeSlash } from "react-icons/fa";
const ForgetPassword = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [passwordVisility, setPasswordVisiblity] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);
  const navigate = useNavigate();
  const { AxiosPost } = useAxiosHelper();
  const [companyData, setCompanyData] = useState([]);
  const [error, setError] = useState('');
  const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  const handlePasswordChange = (e) => {
    const newPassword = e.target.value;
    setPassword(newPassword);

    // Validate the password on every change
    if (!passwordPattern.test(newPassword)) {
      setError('invalid format');
    } else {
      setError('');
    }
  };

  useEffect(() => {
    CompanyInfo();
  }, []);
  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      // console.log(JSON.parse(data));
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }
  async function SendForgetOtp() {
    if (!username) {
      toastFailed("Username is required");
      return;
    }
    setLoading(true);

    const body = {
      username: username,
      action: "forgot_password",
    };
    BasicInfo.isDebug && console.log("Body", body);
    try {
      const res = await AxiosPost(ApiPaths.sendOtp, body);
      BasicInfo.isDebug && console.log("Response of send Otp", res);

      toastSuccess(res?.message || "OTP sent successfully");
      setShowOtp(true);
    } catch (e) {
      BasicInfo.isDebug && console.error("Error", e);
      toastFailed(e.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }


  const isPasswordValid = () => {
    return passwordPattern.test(password);
  }


  async function ForgetPasswordFunc() {
    // Validate OTP and password
    if (!otp || otp.length !== 6) {
      setOtpError("Invalid OTP");
      return;
    }

    if (!password) {
      toastFailed("Password cannot be empty");
      return;
    }

    if (!isPasswordValid()) {
      toastFailed("Password must be in correct format.");
      return;
    }

    setOtpLoading(true);
    const body = {
      username: username, // Include username in the request body
      otp: otp,
      newPassword: password, // Assuming the backend expects password in the request body
      action: "forgot_password",
    };
    BasicInfo.isDebug && console.log("Body of Forgot Passsword", body);
    try {
      // Call the forgotPassword API
      const res = await AxiosPost(ApiPaths.forgotPassword, body);
      BasicInfo.isDebug && console.log("Response of Forgot Password", res);
      // Handle success response
      if (res?.status == "201") {
        toastSuccess(res?.message);
        setShowOtp(false); // Hide OTP input section
        setOtp(""); // Reset OTP field
        navigate("/"); // Redirect to login page or home
      } else {
        toastFailed(res?.data?.message); // Show error message
      }
    } catch (e) {
      BasicInfo.isDebug && console.error(e);
      BasicInfo.isDebug &&
        console.error(
          "Error details:",
          e.response ? e.response.data : e.message
        );
      toastFailed(e.response?.data?.message);
    } finally {
      setOtpLoading(false); // Stop loading spinner
    }
  }

  return (
    <>
      {loading ? <Loader /> : null}

      {showOtp ? (
        <div className="otpSection">
          <div className="otpContainer">
            <h1>OTP</h1>
            <p>OTP sent to your registered email address</p>
            <input
              type="number"
              maxLength={6}
              size={6}
              placeholder="Enter OTP"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
            />
            <p className="errorMsg">{otpError}</p>

            {/* Add the password input here when OTP is shown */}

            <div className="passwordContainer" style={{ position: "relative" }}>
              <input
                id="viewInput"
                type={passwordVisility ? 'text' : 'password'}
                placeholder="Set New Password"
                value={password}
                onChange={handlePasswordChange}
                style={{ marginTop: '10px' }}
                pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
                title=" Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one digit, and one special character (@$!%*?&)"
              />

              {/* Eye Icon to toggle password visibility */}
              <i
                // className="eyeIcon"
                id="eyeIcon"
                onClick={() => setPasswordVisiblity(!passwordVisility)}
                style={{
                  position: "absolute",
                  right: "10px",
                  top: "55%",
                  transform: "translateY(-50%)",
                  cursor: "pointer",
                  fontSize: "22px"
                }}
              >
                {passwordVisility ? <FaRegEye /> : <FaRegEyeSlash />}
              </i>
            </div>
            {error && <p style={{ color: 'red' }}>{error}</p>}

            {otpLoading ? (
              <div className="otpLoading"></div>
            ) : (
              <div>
                <button
                  className="btnSecondary"
                  onClick={() => (setOtp(""), setShowOtp(false))}
                >
                  Cancel
                </button>
                <button
                  className="btnPrimary"
                  onClick={() => ForgetPasswordFunc()}
                >
                  Submit
                </button>
              </div>
            )}
          </div>
        </div>
      ) : null}

      <Container id="logincontainer">
        <div className="forgotContainerContent">
          <div className="loginContent">
            <a className="loginLogo" href={companyData?.contactInfo?.website}>
              <img src={Logo} alt="logo.png" height="100px" />
            </a>
            <h5>Forget Password?</h5>
            <div className="forgotContent_inner">
              <div className="loginInputs">
                <div className="loginInput_inner">
                  <span>Username</span>
                  <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value.toUpperCase())}
                  />

                  <i>
                    <AiOutlineUser />
                  </i>
                </div>
              </div>
              <div className="loginFooter_btn">
                <button
                  className="btnPrimary mb-2"
                  onClick={() => SendForgetOtp()}
                  id="viewBtn"
                >
                  Send OTP
                </button>
                <p className="sign_log">
                  Don't have an account?
                  <Link style={{ padding: "0px" }} to="/register">
                    Register
                  </Link>
                </p>
                <Link to="/" className="btnPrimary">
                  Login
                </Link>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </>
  );
};

export default ForgetPassword;
