import React, { useEffect, useState } from "react";
import { Container } from "react-bootstrap";
import "./TermsCondition.css";
import { ApiPaths } from "../../Config/ApiPath";
import useAxiosHelper from "../../Common/AxiosHelper";

const TermsCondition = () => {
  const [companyData, setCompanyData] = useState([])
  useEffect(() => {
    CompanyInfo();

  }, []);
  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      // console.log(JSON.parse(data));
      setCompanyData(JSON.parse(data));
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <>
      <Container style={{ borderRadius: "30px" }}>
        <div className="termsContainerContent">
          <div className="termsContent">
            <h2>Terms and Conditions</h2>
            <ul>
              <li>
                There are no registration fees to become a business
                associate.Anyone can become a business associate just on sponsor
                of a paid users of company product besides him, but it is
                essential for him/her to be user {companyData?.companyName} product.All the
                benefits of the marketing Plan will go to the business associate
                according to plan.
              </li>
              <li>
                The business associate can display {companyData?.companyName} Name and/or
                logo as designed by the company for printing his/her personal
                stationary, but only with the company's prior written
                permission. The associate shall not use the trademark patent or
                any other intellectual property of the company for a purpose
                other than that of promoting its business.
              </li>
              <li>
                After becoming a business associate, anyone cannot work with
                other establishment engaged in a similar nature of work and/or
                with the similar working plan and product range.
              </li>
              <li>
                If observed, that the Business associate of {companyData?.companyName} is
                enrolled with another establishment engaged in similar nature of
                work and/or with a similar working plan and product range,
                his/her enrollment with {companyData?.companyName} will be terminated, and
                he/she shall be held responsible for making losses and for the
                consequences sustained by other business associate and/or {companyData?.companyName}
                Recovery will be made from business associate.
              </li>
              <li>
                Upon death of business associate, the rights and
                responsibilities of the business associate will be passed on to
                the rightful nominee or legal heir as per the law. The nominee
                or legal heir shall be bound by the original terms and
                conditions.
              </li>
              <li>
                {companyData?.companyName} reserves the right to make any amendments in the
                terms and conditions/marketing plan found necessary by it at any
                time after the Terms &Conditions has been signed or acceptance
                and the business associate shall abide by such amendments. No
                prior notice will be sent to any person for any new amendment.
                Keeping the company's website continuously for latest
                update/information, this is the responsibility of the business
                associate.
              </li>
              <li>
                The company/organization may terminate a business associate
                without any prior notice according to these conditions:
                <ol type="A">
                  <li>
                    If the business associate concerned represents any
                    establishment engaged in a similar nature of business and/or
                    with a similar working plan and product range.
                  </li>
                  <li>
                    If the business associate concerned acts against the
                    interest of {companyData?.companyName} in any way.
                  </li>
                  <li>
                    If any statement or information in the application is found
                    to be false or misleading.
                  </li>
                  <li>
                    If the business associate concerned uses premises/venue
                    concerned with {companyData?.companyName} to represent any other
                    establishment.
                  </li>
                  <li>
                    If the business associate concerned misguides any client or
                    any other business associate of {companyData?.companyName}
                  </li>
                  <li>
                    If a business associate will not activate his account within
                    24hours, after receiving payment/proposal from any client.
                  </li>
                  <li>
                    If a business associate misuse the record/funds of {companyData?.companyName} in any manner.
                  </li>
                  <li>
                    If a business associate is found guilty of any type of
                    character.
                  </li>
                </ol>
              </li>
              <li>
                Any dispute arising out of or in relation to this agreement
                shall be referred to a single arbitrator to be appointed by {companyData?.companyName} business associate shall not raise any
                objection on the ground the arbitrator. So appointed is person
                employed in or having connection with {companyData?.companyName} .
              </li>
              <li>
                The right of a terminated business associate to receive
                commission (in whatever form) from {companyData?.companyName}
                ceases/cancelled immediately with effect from the date of
                termination.
              </li>
              <li>
                In case of any difference of opinion, the decision of {companyData?.companyName} shall be final.
              </li>
              <li>
                {companyData?.companyName} reserves the right to rename or transfer a
                business associate.
              </li>
              <li>
                All right reserved to accept/reject the proposal/application to
                be a business associate with sole discretion of {companyData?.companyName}.
              </li>
            </ul>
            <p className="termsText">
              All disputes shall be subject to the legal Jurisdiction only.
            </p>
            <h4>Declaration</h4>
            <p>
              Hereby declared that I accept and agree to all the terms and
              conditions of <span>{companyData?.companyName} </span> after studying your
              website <span>{companyData?.contactInfo?.website}</span> and discussion with your business
              associates.
            </p>

            {/* <h2>
              Amiara Agent Terms and Conditions

            </h2>
            1. Introduction :

            These Terms and Conditions (hereinafter referred to as "Agreement") govern the relationship between Amiara (hereinafter referred to as "the Company"), a company incorporated under the laws of India and having its registered office at [Insert Company's Registered Address], and the individual or entity acting as an agent (hereinafter referred to as "the Agent") for the promotion and sale of Amiara's financial products and services. By accepting this Agreement, the Agent agrees to be bound by its terms.

            2. Definitions:

            <br /> Agent: Refers to an individual or entity formally appointed by the Company to promote and sell its products and services.
            <br />Referring Agent: Refers to an existing Investor who refers a new client to the Company, thereby becoming subject to specific, limited provisions of this Agreement.
            <br />Referred Client: Refers to a new client introduced to the Company by a Referring Agent.
            <br />Company: Refers to Amiara, the provider of the financial products and services.
            <br />Agreement: Refers to these Amiara Agent Terms and Conditions.
            <br />Referral Program Commission Schedule: A separate document outlining the commission structure for Referring Agents.
            <br /><br />
            3. Appointment and Scope of Authority (For Formal Agents)

            The Company hereby appoints the Agent as a non-exclusive agent to solicit and promote the sale of specific Amiara products and services as outlined in the Agent's appointment letter or separate product-specific agreements.
            The Agent's authority is limited to:
            <br /> Presenting information about Amiara's products and services using approved marketing materials.
            <br /> Collecting completed application forms and initial investments/premiums.
            <br /> Forwarding collected funds and applications to the Company according to established procedures.
            <br />   The Agent is not authorized to:
            Make any promises or guarantees about returns or performance beyond what is stated in official Company materials.
            Accept cash payments directly from clients (unless specifically authorized in writing by the Company).<br />
            Modify or alter the terms of any Amiara product or service.
            Enter into any contracts or agreements on behalf of the Company.
            Provide financial advice to clients.
            <br /><br />
            4. Referral Program and Limited Agent Status (For Referring Agents)
            <br />
            Any existing Investor in good standing with Amiara may participate in the Referral Program.
            Limited Agent Status and Applicable Terms:** Upon successful enrollment of a Referred Client (meaning the new client has completed the application and made the required investment), the referring Investor will be considered a "Referring Agent" for the limited purpose of that specific referral and will be subject to the following sections of these Amiara Agent Terms and Conditions: 5 (Commission and Compensation), 6 (Term and Termination - limited to the specific referral), 8 (Confidentiality), 13 (Dispute Resolution) and 14 (Governing Law).
            <br /><br />Commission Structure for Referrals:<br /> The Referring Agent will receive a commission/reward as outlined in the separate Referral Program Commission Schedule, which is incorporated herein by reference.

            **5. Agent Responsibilities (For Formal Agents and Referring Agents)**

            *   **Compliance with Laws and Regulations:** The Agent/Referring Agent shall comply with all applicable laws, rules, and regulations, including but not limited to those related to:
            *   Financial services and marketing.
            *   Anti-money laundering (AML) and combating the financing of terrorism (CFT).
            *   Know your customer (KYC) and customer due diligence (CDD).
            *   Data privacy and protection (including [mention specific relevant laws like India's Personal Data Protection Bill, if enacted]).
            *   Taxation.
            *   **Ethical Conduct and Professionalism:** The Agent/Referring Agent shall conduct business with honesty, integrity, and professionalism, acting in the best interests of both the Company and the clients. This includes:
            *   Avoiding any misleading or deceptive practices.
            *   Providing accurate and complete information about Amiara's products and services.
            *   Maintaining confidentiality and protecting client data.
            *   Avoiding conflicts of interest.
            *   **Use of Approved Materials:** The Agent/Referring Agent shall use only marketing and promotional materials that have been approved in writing by the Company. They shall not create or distribute any unauthorized materials.
            *   **Client Interaction and Communication:** The Agent/Referring Agent shall:
            *   Treat all clients with respect and courtesy.
            *   Respond to client inquiries promptly and accurately.
            *   Clearly explain the terms and conditions of Amiara's products and services.
            *   Not provide any financial advice or recommendations unless specifically authorized in writing by the Company and appropriately qualified to do so.
            *   **Handling of Funds and Applications (If Applicable):** The Agent/Referring Agent shall (if authorized to handle funds):
            *   Handle client funds and application forms with care and diligence.
            *   Forward all collected funds and completed applications to the Company according to established procedures and within specified timeframes.
            *   Not accept cash payments directly from clients unless specifically authorized in writing by the Company.
            *   **Record Keeping (If Applicable):** The Agent/Referring Agent shall (if authorized to handle applications):
            * Maintain accurate records of all client interactions, applications, and transactions, as required by the Company and applicable regulations.
            *   **Training and Development:** Formal Agents shall participate in mandatory training programs provided by the Company. Referring Agents may be offered optional training related to the referral program.
            *   **Reporting:** Formal Agents shall submit regular reports to the Company as required, detailing their sales activities and client interactions. Referring Agents are not typically required to submit formal reports beyond the initial referral information.
            *   **Representations:** The Agent/Referring Agent shall not make any representations or warranties about Amiara's products or services that are not expressly authorized in writing by the Company.
            *   **Non-Solicitation (Formal Agents Only):** During the term of this Agreement and for a period of [Number] years after its termination, the Formal Agent shall not solicit or attempt to solicit any clients of the Company for any competing business. This does not apply to Referring Agents regarding clients they did not directly refer.

            **6. Commission and Compensation (For Formal Agents and Referring Agents)**

            *   The commission structure for Formal Agents will be outlined in a separate commission schedule or agreement.
            *   The commission structure for Referring Agents will be outlined in the separate Referral Program Commission Schedule.
            *   Commissions will be paid upon successful processing and acceptance of client applications and receipt of funds by the Company.
            *   The Company reserves the right to modify the commission structure with reasonable written notice to the Agent/Referring Agent.

            **7. Term and Termination (For Formal Agents and Referring Agents)**

            *   **Formal Agents:** This Agreement for Formal Agents shall commence on the date of signing and continue for an initial term of [Duration, e.g., one year], and shall be renewed automatically for successive periods of the same duration unless either party provides written notice of termination at least [Number, e.g., 30] days prior to the expiration of the current term.
            *   **Referring Agents:** The limited "Referring Agent" status and the application of the specified sections of this Agreement will terminate automatically upon the maturity, full withdrawal, or termination of the Referred Client's investment.
            *   The Company may terminate this Agreement immediately for cause for Formal Agents, including but not limited to:
            *   Breach of this Agreement.
            *   Misrepresentation of Company products or services.
            *   Unethical conduct or fraud.
            *   Violation of applicable laws or regulations.

            **8. Indemnification**

            The Agent/Referring Agent shall indemnify and hold harmless the Company, its officers, directors, employees, and affiliates from any claims, losses, damages, liabilities, and expenses (including reasonable legal fees) arising out of the Agent's/Referring Agent's breach of this Agreement or their negligent or willful acts or omissions.

            **9. Confidentiality**

            The Agent/Referring Agent shall maintain the confidentiality of all Company information, including but not limited to client data, business strategies, financial information, and marketing materials. This obligation shall survive the termination of this Agreement.

            **10. Intellectual Property**

            All trademarks, logos, and other intellectual property owned by the Company shall remain the exclusive property of the Company. The Agent/Referring Agent is granted a limited, non-exclusive, revocable license to use these materials solely for the purpose of promoting Amiara products and services as authorized by the Company.

            **11. Data Privacy**

            The Agent/Referring Agent shall comply with all applicable data privacy laws and regulations, including but not limited to [mention specific relevant laws like India's Personal Data Protection Bill, if enacted]. The Agent/Referring Agent shall obtain all necessary consents from clients before collecting, using, or disclosing their personal information.

            **12. Non-Circumvention**

            The Agent/Referring Agent agrees not to circumvent the Company by directly contacting or soliciting clients introduced by the Company for any business related to the Company’s services, either during the term of this Agreement or for a period
 */}

          </div>
        </div>
      </Container>
    </>
  );
};

export default TermsCondition;
