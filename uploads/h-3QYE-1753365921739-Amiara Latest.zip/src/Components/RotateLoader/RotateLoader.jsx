import React from 'react';
import './RotateLoader.css';
const RotateLoader = () => {
    return (
        <div className='rotateLoaderDiv'>
            <div className='rotateLoader'></div>
        </div>
    )
}

export default RotateLoader