import React, { useEffect, useState } from "react";
import "./ForgetUserName.css";
import Logo from "./../../Images/logo.png";
import Slide from "./../../Images/side.png";
import { Container, Row, Col } from "react-bootstrap";
import { CiMail } from "react-icons/ci";
import { HiLockClosed, HiLockOpen } from "react-icons/hi";
import axios from "axios";
import { ApiPaths } from "../../Config/ApiPath";
import Loader from "../../Components/Loader/Loader";
import { Link, useNavigate } from "react-router-dom";
import { Data, toastFailed, toastSuccess } from "../../Common/Data";
import {
  AiFillEye,
  AiOutlineMail,
  AiOutlinePhone,
  AiFillEyeInvisible,
  AiOutlineCheckCircle,
} from "react-icons/ai";
import useAxiosHelper from "../../Common/AxiosHelper";
import ProgressBar from "react-bootstrap/ProgressBar";
import { BasicInfo } from "../../Config/BasicInfo";

const ForgetUserName = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [passwordVisility, setPasswordVisiblity] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);
  const [emailError, setEmailError] = useState("");
  const navigate = useNavigate();
  const { AxiosPost, AxiosGet } = useAxiosHelper();
  const [companyData, setCompanyData] = useState([]);

  useEffect(() => {
    CompanyInfo();
  }, []);

  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }

  // Function to validate email format
  const validateEmail = (email) => {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailPattern.test(email);
  };

  // Function to handle email change (force lowercase and validate)
  const handleEmailChange = (e) => {
    const inputEmail = e.target.value.toLowerCase();  // Force to lowercase
    setEmail(inputEmail);

    // Email format validation
    if (!validateEmail(inputEmail)) {
      setEmailError("Please enter a valid email address.");
    } else {
      setEmailError("");  // Clear error if valid
    }
  };

  async function SendForgetOtp() {
    if (!email || !validateEmail(email)) {
      toastFailed("Please enter a valid email.");
      return;
    }
    setLoading(true);

    const body = {
      email: email,
      action: "forgot_username",
    };
    console.log("BODY==>", body)
    try {
      const res = await AxiosPost(ApiPaths.sendForgotOtp, body);
      toastSuccess(res?.message || "OTP sent successfully");
      setShowOtp(true);
    } catch (e) {
      toastFailed(e.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  async function ForgetUsernameFunc() {
    // Validate OTP and password
    if (!otp || otp.length !== 6) {
      setOtpError("Invalid OTP");
      return;
    }

    setOtpLoading(true);
    const body = {
      email: email, // Include email in the request body
      otp: otp,
      action: "forgot_username",
    };
    try {
      const res = await AxiosPost(ApiPaths.forgotUsername, body);
      if (res?.status == 200) {
        toastSuccess(res?.message);
        setShowOtp(false); // Hide OTP input section
        setOtp(""); // Reset OTP field
        navigate("/"); // Redirect to login page or home
      } else {
        toastFailed(res?.data?.message); // Show error message
      }
    } catch (e) {
      toastFailed(e.response?.data?.message);
    } finally {
      setOtpLoading(false); // Stop loading spinner
    }
  }

  return (
    <>
      {loading ? <Loader /> : null}
      {showOtp ? (
        <div className="otpSection">
          <div className="otpContainer">
            <h1>OTP</h1>
            <p>OTP sent to your registered email address</p>
            <input
              type="text"
              maxLength={6}
              size={6}
              placeholder="Enter OTP"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
            />
            <p className="errorMsg">{otpError}</p>

            {otpLoading ? (
              <div className="otpLoading"></div>
            ) : (
              <div>
                <button
                  className="btnSecondary"
                  onClick={() => (setOtp(""), setShowOtp(false))}
                >
                  Cancel
                </button>
                <button
                  className="btnPrimary"
                  onClick={() => ForgetUsernameFunc()}
                >
                  Submit
                </button>
              </div>
            )}
          </div>
        </div>
      ) : null}

      <Container id="logincontainer">
        <div className="forgotContainerContent">
          <div className="loginContent">
            <a className="loginLogo" href={companyData?.contactInfo?.website}>
              <img src={Logo} alt="logo.png" height="100px" />
            </a>
            <h5>Forget Username?</h5>
            <div className="forgotContent_inner">
              <div className="loginInputs">
                <div className="loginInput_inner">
                  <span>Email</span>
                  <input
                    type="text"
                    placeholder="Email"
                    value={email}
                    onChange={handleEmailChange}
                  />
                  <i>
                    <CiMail />
                  </i>
                </div>
                {emailError && <p className="errorMsg">{emailError}</p>}
              </div>
              <div className="loginFooter_btn">
                <button
                  className="btnPrimary mb-2"
                  onClick={() => SendForgetOtp()}
                  id="viewBtn"
                >
                  Send OTP
                </button>
                <p className="sign_log">
                  Don't have an account?
                  <Link style={{ padding: "0px" }} to="/register">
                    Register
                  </Link>
                </p>
                <Link to="/" className="btnPrimary">
                  Login
                </Link>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </>
  );
};

export default ForgetUserName;
