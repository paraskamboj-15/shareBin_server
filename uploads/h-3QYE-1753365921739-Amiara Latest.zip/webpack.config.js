const webpack = require("webpack");
// const path = require('path');
// const NodePolyfillPlugin = require("node-polyfill-webpack-plugin");

module.exports = {
  // ... other configurations
  resolve: {
    fallback: {
      process: require.resolve("process/browser"),
      stream: require.resolve("stream-browserify"),
    },
    // alias: {
    //   process: path.resolve(__dirname, '/node_modules/process/browser.js')
    // }
  },
  plugins: [
    new webpack.ProvidePlugin({
      process: "process/browser",
    }),
    // new NodePolyfillPlugin(),
  ],
};
