import React, { useEffect, useState } from "react";
import "./FundTransfer.css";
import axios from "axios";
import { Row, Col } from "react-bootstrap";
import { ApiPaths } from "./../../Config/ApiPath";
import { ToastContainer, toast } from "react-toastify";
import Loader from "./../../Components/Loader/Loader";
// import FundHistory from "../FundRequest/FundHistory";
import useAxiosHelper from "../../Common/AxiosHelper";
import { BasicInfo } from "../../Config/BasicInfo";
import FundTransferHistory from "./FundTransferHistory";
// import FundHistory from "./FundHistory";
const FundTransfer = () => {
  const [fundWallet, setFundWallet] = useState("");
  const [username, setUsername] = useState("");
  const [typingTimeout, setTypingTimeout] = useState(null);
  const [amount, setAmount] = useState("");
  const [userId, setUserId] = useState("");
  const [amountError, setAmountError] = useState("");
  const [userIdError, setUserIdError] = useState("");
  const [loading, setLoading] = useState(false);
  const [dashboardData, setDashboardData] = useState([]);
  const [showOtp, setShowOtp] = useState(false);
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);
  const [sponsorLoading, setSponsorLoading] = useState(false);
  const [checkSponsorExist, setCheckSponsorExist] = useState([]);
  const [status, setStatus] = useState("0");
  const [change, setChange] = useState();
  const { AxiosPost, AxiosGet } = useAxiosHelper();
  const [companyData, setCompanyData] = useState();

  const handleShowFundHistory = (newStatus) => {
    setStatus(newStatus);
  };

  const toastSuccess = (msg) => toast.success(msg);
  const toastFailed = (msg) => toast.error(msg);

  useEffect(() => {
    FetchData();
    CompanyInfo();
  }, []);

  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }

  async function FetchData() {
    try {
      const tempData = await AxiosGet(ApiPaths.getWallets);
      BasicInfo.isDebug && console.log("tempData", tempData);
      tempData?.wallets?.map((x, i) => {
        if (x?.slug == "fund_wallet") {
          setFundWallet(x?.value);
        }
      });
    } catch (e) {
      BasicInfo.isDebug && console.log(e);
    }
  }

  async function TransferOTP() {
    try {
      if (!username ) {
        toastFailed('Enter Valid Username.');
        return; // Exit the function without calling the API
      }
      if (amount<=0) {
        toastFailed('Enter a valid Amount.');
        return; // Exit the function without calling the API
      }
      setLoading(true);
      const body = {
        action: "Fund transfer",
        // username:userId
      };
      BasicInfo.isDebug && console.log("Body===>", body);
      const tempOtpData = await AxiosPost(ApiPaths.sendOtp, body);
      BasicInfo.isDebug && console.log("tempOtpData", tempOtpData);
      toastSuccess(tempOtpData?.message);
      setLoading(false);
      setShowOtp(true);
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
      toastFailed(error?.response?.data?.message);
      setLoading(false);
    }
  }

  async function FundTransferFunc() {
    setAmountError("");
    setUserIdError("");
    setOtpError("");
    if (!amount > 0) {
      setAmountError("Invalid Amount");
    }
    if (!userId.length > 0) {
      setUserIdError("Invalid User ID");
    }
    // if (otp.length != 6) {
    //   toastFailed("Invalid OTP");
    // }
    const body = {
      username: userId,
      amount: amount,
      otp: otp,
      action: "Fund transfer",
    };
    BasicInfo.isDebug && console.log("body", body);
    if (amount > 0 && userId.length > 0 ) {
      try {
        setOtpLoading(true);
        const response = await AxiosPost(ApiPaths.p2pTransfer, body);
        toastSuccess(response?.message);
        setChange(Date.now());
        setShowOtp(false);
        FetchData();
        setUserId("");
        setAmount("");
        setOtp("");
        BasicInfo.isDebug && console.log("response", response);
        setOtpLoading(false);
      } catch (e) {
        toastFailed(e?.response?.data?.message);
        BasicInfo.isDebug && console.log("error", e);
        setOtpLoading(false);
      }
    }
  }
  async function onUserStoppedTyping(sponID) {
    setSponsorLoading(true);
    try {
      const body = { username: sponID };
      const res = await AxiosPost(ApiPaths.checkSponsor, body);

      if (res.status == 200) {
        setCheckSponsorExist(true);
        setUsername(res?.name);
      }
    } catch (error) {
      BasicInfo.isDebug && console.error("error here", error);
    } finally {
      setSponsorLoading(false);
    }
  }
  const handleInputChange = (e) => {
    setUserIdError("");
    const value = e.target.value;
    setUserId(value);
    if (typingTimeout) {
      clearTimeout(typingTimeout);
    }
    setTypingTimeout(
      setTimeout(() => {
        if (value.length > 0) {
          onUserStoppedTyping(value);
        } else {
          setUsername("");
        }
      }, 500)
    );
  };

  return (
    <section className="dashboard">
      {loading ? <Loader /> : null}
      {showOtp == true ? (
        <div className="otpSection">
          <div className="otpContainer">
            <h1>OTP</h1>
            <p>OTP sent to your registered email address</p>
            <input
              type="text"
              maxLength={6}
              size={6}
              placeholder="Enter OTP"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
            />
            <p className="errorMsg">{otpError}</p>
            {otpLoading ? (
              <div className="otpLoading"></div>
            ) : (
              <div>
                <button
                  className="btnSecondary"
                  onClick={() => (setOtp(""), setShowOtp(false))}
                >
                  Cancel
                </button>
                <button className="btnPrimary" onClick={FundTransferFunc}>
                  Submit
                </button>
              </div>
            )}
          </div>
        </div>
      ) : null}
      <div className="addfundDiv inputPrimary">
        <h1>Fund Transfer</h1>
        <div className="addfundDivFundWallet">
          <p>Fund Wallet</p>
          <p>
            {companyData?.currency_sign}
            {parseFloat(fundWallet).toFixed(2)}
          </p>
        </div>
        <label htmlFor="Amount">User ID</label>
        {username?.length > 0 ? (
          <p id="sponsorVerified">{username}</p>
        ) : (
          userId?.length > 0 && (
            <p id="sponsorVerified" style={{ color: "red" }}>
              Not Exist
            </p>
          )
        )}
        <div className="loginInput_inner">
          <input
            style={{ borderRadius: "5px" }}
            min={1}
            required
            type="text"
            placeholder="User Id"
            value={userId}
            onChange={(e) => handleInputChange(e)}
            onInput={(e) => {
              e.target.value = e.target.value.toUpperCase()
            }}
          />
          {sponsorLoading ? <i id="sponsorLoading"></i> : null}
        </div>
        <p className="errorMsg">{userIdError}</p>
        <label htmlFor="Amount">Amount ({companyData?.currency_sign})</label>
        <input
          min={1}
          required
          type="number"
          placeholder="Enter Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <p className="errorMsg">{amountError}</p>
        <button className="btnPrimary mt-3" onClick={TransferOTP}>
        {/* <button className="btnPrimary mt-3" onClick={FundTransferFunc}> */}
          Send OTP
          {/* Transfer */}
        </button>
      </div>
      <section>
        <div>
          {status && <FundTransferHistory key={change} status={status} />}
        </div>
      </section>
    </section>
  );
};

export default FundTransfer;
