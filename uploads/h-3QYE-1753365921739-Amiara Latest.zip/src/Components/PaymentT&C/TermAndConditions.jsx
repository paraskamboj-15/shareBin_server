import React from 'react';
import './TermAndConditions.css';

export default function TermAndConditions({ onClose }) {
    return (
        <div className="term-and-conditions__overlay">
            <div className="term-and-conditions__content">
                <div>
                    <h1 className="textHeading">Terms & Conditions</h1>
                </div>

                <p>
                    By using this service, you agree to pay all fees associated with the products or services purchased. Payments are due at the time of purchase unless otherwise specified. Accepted payment methods include credit/debit cards, PayPal, and other options listed on our site. All payments are non-refundable except where required by law. You are responsible for ensuring your payment information is accurate and up to date. We reserve the right to suspend or cancel services in case of failed payments or if your account is in arrears. Any disputes should be resolved within 30 days.
                </p>
                <button className="term-and-conditions__button" onClick={onClose}>Close</button>
            </div>
        </div>
    );
}
