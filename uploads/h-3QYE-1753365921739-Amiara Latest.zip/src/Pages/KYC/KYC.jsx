import React, { useEffect, useState } from "react";
import { Row, Col } from "react-bootstrap";
import { useDropzone } from "react-dropzone";
import imageCompression from "browser-image-compression";
import "./KYC.css";
import Loader from "../../Components/Loader/Loader";
import useAxiosHelper from "../../Common/AxiosHelper";
import { ApiPaths } from "../../Config/ApiPath";
import { BasicInfo, toastFailed, toastSuccess } from "../../Config/BasicInfo";
import moment from "moment";

const KYC = () => {
  const [activeTab, setActiveTab] = useState("bank");
  const [loading, setLoading] = useState(false);
  const [accNo, setAccNo] = useState("");
  const [ifscCode, setIfscCode] = useState("");
  const [bankName, setBankName] = useState("");
  const [errors, setErrors] = useState({});
  const [address, setAddress] = useState("");
  const [isAbove18, SetIsAbove18] = useState("");
  const [idNo, setIdNo] = useState("");
  const [nomineeIdNo, setNomineeIdNo] = useState("");
  const [panNo, setPanNo] = useState("");
  const [selectedValue, setSelectedValue] = useState("");
  const [idDocumentType, setIdDocumentType] = useState("");
  const [selectedBankType, setSelectedBankType] = useState("");
  const [holderName, setHolderName] = useState("");
  const [name, setName] = useState("");
  const { AxiosPost, AxiosGet } = useAxiosHelper();
  const [files, setFiles] = useState([]);
  const [backFiles, setBackFiles] = useState([]);
  const [nomineeName, setNomineeName] = useState("");
  const [nomineeRelationship, setNomineeRelationship] = useState("");
  const [nomineeStatus, setNomineeStatus] = useState(0);
  const [nomineeDetails, setNomineeDetails] = useState();

  const [previews, setPreviews] = useState({
    bank: [],
    pan: [],
    addressFront: [],
    addressBack: [],
    nomineeFront: [],
    nomineeBack: [],
  });
  const [bankStatus, setBankStatus] = useState();
  const [panStatus, setPanStatus] = useState();
  const [addressStatus, setAddressStatus] = useState();
  const [isApproved, setIsApproved] = useState();
  const [bankDetails, setBankDetails] = useState();
  const [panDetails, setPanDetails] = useState();
  const [addressDetails, setAddressDetails] = useState();
  const [dob, setDob] = useState("");
  const [isMinor, setIsMinor] = useState(false);
  const [isMajor, setIsMajor] = useState(false);

  const handleChange = () => {
    if (age >= 18) {
      setIsMinor(false);
      setIsMajor(true);
      SetIsAbove18("yes");
    } else {
      setIsMinor(true);
      setIsMajor(false);
      SetIsAbove18("no");
    }
  };

  const [age, setAge] = useState(null); // State to hold the calculated age

  // Function to calculate age based on DOB
  const calculateAge = (dob) => {
    const birthDate = new Date(dob); // Convert DOB string to Date object
    const currentDate = new Date(); // Get current date

    let calculatedAge = currentDate.getFullYear() - birthDate.getFullYear(); // Calculate the initial difference in years
    const monthDifference = currentDate.getMonth() - birthDate.getMonth(); // Calculate the month difference
    const dayDifference = currentDate.getDate() - birthDate.getDate(); // Calculate the day difference

    // If the current date is before the birthdate (i.e., birthday hasn't happened yet this year), subtract one from age
    if (monthDifference < 0 || (monthDifference === 0 && dayDifference < 0)) {
      calculatedAge--;
    }
    return calculatedAge;
  };

  const handleDobChange = (e) => {
    const selectedDob = e.target.value;
    setDob(selectedDob);

    if (selectedDob) {
      const calculatedAge = calculateAge(selectedDob);
      setAge(calculatedAge); // Set the calculated age
      handleChange(calculatedAge); // Pass age to handleChange
    } else {
      setAge(null); // Reset age if DOB is cleared
      handleChange(null); // Reset minor/major status
    }
  };

  var x = 0;
  useEffect(() => {
    if (x == 0) {
      fetchKycDetails();
      x++;
    }
  }, []);
  const fetchKycDetails = async () => {
    try {
      setLoading(true);

      const KycDetails = await AxiosGet(ApiPaths.getKycStatus);
      BasicInfo.isDebug && console.log(KycDetails, "Check Kyc Status");
      setBankDetails(KycDetails?.bankDetails);
      setPanDetails(KycDetails?.panDetails);
      setNomineeDetails(KycDetails?.nomineeDetails);
      setAddressDetails(KycDetails?.addressDetails);
      setBankStatus(KycDetails?.bankStatus);
      setPanStatus(KycDetails?.panStatus);
      setNomineeStatus(KycDetails?.nomineeStatus);
      setAddressStatus(KycDetails?.addressStatus);
      setIsApproved(KycDetails?.isApproved);
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
      toastFailed(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };
  const handleFilesChange = (newFiles, type) => {
    BasicInfo.isDebug && console.log("KYC TYPE==>", type);
    if (type == "addressBack") {
      setBackFiles(newFiles);
    }
    setFiles(newFiles);
    setPreviews((prevPreviews) => ({
      ...prevPreviews,
      [type]: newFiles.map((file) => URL.createObjectURL(file)),
    }));
  };

  const handleBank = async () => {
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("accountNumber", accNo);
      formData.append("ifscCode", ifscCode);
      formData.append("bankName", bankName);
      formData.append("accountType", selectedBankType);
      formData.append("holderName", holderName);
      files.forEach((file) => {
        formData.append("document", file);
      });
      for (let [key, value] of formData.entries()) {
        console.log(`${key}:`, value);
      }
      const response = await AxiosPost(ApiPaths.getBankDetails, formData);
      console.log("Response of Bank api==>", response);

      if (response) {
        toastSuccess(response?.message);
      }
    } catch (e) {
      BasicInfo.isDebug && console.error("Error submitting bank details:", e);
      toastFailed(e?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePan = async () => {
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("panNumber", panNo);
      formData.append("dob", dob);
      formData.append("isAbove18", isAbove18);
      files.forEach((file) => {
        formData.append("document", file);
      });
      for (let [key, value] of formData.entries()) {
        console.log(`${key}:`, value);
      }
      const res = await AxiosPost(ApiPaths.getPanCardDetails, formData);
      console.log("Response of PanCard api==>", res);

      if (res) {
        toastSuccess(res?.message);
      }
    } catch (e) {
      BasicInfo.isDebug && console.error("Error submitting PAN details:", e);
      toastFailed(e?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };
  const handleAddress = async () => {
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("idType", selectedValue);
      formData.append("idNumber", idNo);
      formData.append("name", name);
      formData.append("address", address);
      // formData.append("isAbove18", isAbove18 || "no");
      files.forEach((file) => {
        formData.append("documentFront", file);
      });
      backFiles.forEach((backfile) => {
        formData.append("documentBack", backfile);
      });
      for (let [key, value] of formData.entries()) {
        console.log(`${key}:`, value);
      }
      const resp = await AxiosPost(ApiPaths.getAddressDetails, formData);
      console.log("Response of Address api==>", resp);

      if (resp) {
        toastSuccess(resp?.message);
      }
    } catch (e) {
      BasicInfo.isDebug &&
        console.error("Error submitting address details:", e);
      toastFailed(e?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };
  const handleNominee = async () => {
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("nomineeName", nomineeName);
      formData.append("relationship", nomineeRelationship);
      formData.append("idDocumentType", idDocumentType);
      formData.append("idDocumentNumber", nomineeIdNo);

      files.forEach((file) => {
        formData.append("documentFront", file);
      });
      backFiles.forEach((backfile) => {
        formData.append("documentBack", backfile);
      });

      for (let [key, value] of formData.entries()) {
        console.log(`${key}: ${value}`);
      }

      const response = await AxiosPost(ApiPaths.getNomineeDetails, formData);
      console.log("Response of Nominee api==>", response);
      if (response) {
        toastSuccess(response?.message);
      }
    } catch (e) {
      BasicInfo.isDebug &&
        console.error("Error submitting nominee details:", e);
      toastFailed(e?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };
  const onDrop = async (acceptedFiles, type) => {
    const acceptedImageTypes = ["image/jpeg", "image/png"]; // JPEG and PNG MIME types
    const imageFiles = acceptedFiles.filter(
      (file) =>
        acceptedImageTypes.includes(file.type) ||
        file.name.endsWith(".jpg") ||
        file.name.endsWith(".jpeg")
    );

    const compressedFiles = await Promise.all(
      imageFiles.map(async (file) => {
        const options = {
          maxSizeMB: 1,
          maxWidthOrHeight: 1024,
          useWebWorker: true,
        };
        try {
          const compressedFile = await imageCompression(file, options);
          return compressedFile;
        } catch (err) {
          BasicInfo.isDebug && console.error("Error compressing image:", err);
          return file; // Return the original file if compression fails
        }
      })
    );

    if (type === "addressFront") {
      setFiles(compressedFiles); // Keep front files in `files`
      setPreviews((prevPreviews) => ({
        ...prevPreviews,
        addressFront: compressedFiles.map((file) => URL.createObjectURL(file)),
      }));
    } else if (type === "addressBack") {
      setBackFiles(compressedFiles); // Store back files in `backFiles`
      setPreviews((prevPreviews) => ({
        ...prevPreviews,
        addressBack: compressedFiles.map((file) => URL.createObjectURL(file)),
      }));
    } else if (type === "nomineeFront") {
      setFiles(compressedFiles); // Keep front files in `files`
      setPreviews((prevPreviews) => ({
        ...prevPreviews,
        nomineeFront: compressedFiles.map((nomineefile) =>
          URL.createObjectURL(nomineefile)
        ),
      }));
    } else if (type === "nomineeBack") {
      setBackFiles(compressedFiles); // Store back files in `backFiles`
      setPreviews((prevPreviews) => ({
        ...prevPreviews,
        nomineeBack: compressedFiles.map((nomineefile) =>
          URL.createObjectURL(nomineefile)
        ),
      }));
    } else {
      handleFilesChange(compressedFiles, type); // Keep existing logic for other types
    }
  };
  const { getRootProps: getBankRootProps, getInputProps: getBankInputProps } =
    useDropzone({ onDrop: (acceptedFiles) => onDrop(acceptedFiles, "bank") });
  const { getRootProps: getPanRootProps, getInputProps: getPanInputProps } =
    useDropzone({ onDrop: (acceptedFiles) => onDrop(acceptedFiles, "pan") });
  const {
    getRootProps: getAddressFrontRootProps,
    getInputProps: getAddressFrontInputProps,
  } = useDropzone({
    onDrop: (acceptedFiles) => onDrop(acceptedFiles, "addressFront"),
  });
  const {
    getRootProps: getAddressBackRootProps,
    getInputProps: getAddressBackInputProps,
  } = useDropzone({
    onDrop: (acceptedFiles) => onDrop(acceptedFiles, "addressBack"),
  });
  const {
    getRootProps: getNomineeFrontRootProps,
    getInputProps: getNomineeFrontInputProps,
  } = useDropzone({
    onDrop: (acceptedFiles) => onDrop(acceptedFiles, "nomineeFront"),
  });
  const {
    getRootProps: getNomineeBackRootProps,
    getInputProps: getNomineeBackInputProps,
  } = useDropzone({
    onDrop: (acceptedFiles) => onDrop(acceptedFiles, "nomineeBack"),
  });
  return (
    <section className="dashboard" style={{ paddingTop: "10px" }}>
      {loading && <Loader />}

      <Row className="mt-4 d-flex justify-content-center">
        <Col lg="9" className="mb-2">
          <div
            className="tabButton"
            style={{
              display: "flex",
              flexDirection: "row",
              flexWrap: "wrap",
              justifyContent: "center",
              gap: "10px",
              padding: "10px",
            }}
          >
            <button
              className="btnPrimary"
              style={{
                flex: "1 1 auto",
                padding: "10px 20px",
                minWidth: "100px",
                maxWidth: "150px",
                fontSize: "1em",
                margin: "5px",
              }}
              onClick={() => setActiveTab("bank")}
            >
              Bank KYC
            </button>
            <button
              className="btnPrimary"
              style={{
                flex: "1 1 auto",
                padding: "10px 20px",
                minWidth: "100px",
                maxWidth: "150px",
                fontSize: "1em",
                margin: "5px",
              }}
              onClick={() => setActiveTab("pan")}
            >
              Pan KYC
            </button>
            {/* <button
              className="btnPrimary"
              style={{
                flex: "1 1 auto",
                padding: "10px 20px",
                minWidth: "100px",
                maxWidth: "150px",
                fontSize: "1em",
                margin: "5px",
              }}
              onClick={() => setActiveTab("address")}
            >
              Address KYC
            </button> */}
            <button
              className="btnPrimary"
              style={{
                flex: "1 1 auto",
                padding: "10px 20px",
                minWidth: "100px",
                maxWidth: "150px",
                fontSize: "1em",
                margin: "5px",
                whiteSpace: "nowrap",
              }}
              onClick={() => setActiveTab("nominee")}
            >
              Nominee KYC
            </button>
          </div>
          {activeTab === "bank" && (
            <div className="editProfile inputPrimary">
              <h3>Bank Details</h3>

              {isApproved?.bank == 2 ? (
                <p style={{ color: "green", fontSize: "15px" }}>
                  Bank KYC is approved
                </p>
              ) : isApproved?.bank == 3 ? (
                <>
                  <p className="error">Bank KYC is rejected</p>
                  {/* Add reason for rejection if available */}
                  {bankDetails?.reason && (
                    <p className="error">
                      Rejection Reason: {bankDetails.reason}
                    </p>
                  )}
                </>
              ) : bankStatus == 1 ? (
                <p className="error">
                  Bank KYC is already Submitted, wait for approval.
                </p>
              ) : (
                ""
              )}

              {/* Allow re-entry if status is rejected (bankStatus == 3) */}
              <label htmlFor="">Account No</label>
              {/* Account Number */}
              <input
                type="number"
                placeholder="Account No"
                value={
                  accNo ||
                  (isApproved?.bank == 3 ? "" : bankDetails?.accountNumber)
                }
                onChange={(e) => setAccNo(e.target.value.toUpperCase())}
                required
              />
              {errors.accNo && <p className="error">{errors.accNo}</p>}

              <label htmlFor="">IFSC Code</label>
              <input
                type="text"
                placeholder="IFSC Code"
                value={
                  ifscCode ||
                  (isApproved?.bank == 3 ? "" : bankDetails?.ifscCode)
                }
                onChange={(e) => {
                  // Convert to uppercase and restrict invalid characters
                  let value = e.target.value.toUpperCase();

                  // Check if the value is a valid IFSC format
                  if (/^[A-Z]{0,4}0{0,1}[A-Z0-9]{0,6}$/.test(value)) {
                    // Enforce the length and character restrictions for valid IFSC
                    if (
                      value.length <= 11 &&
                      (value.length < 5 || value[4] === "0")
                    ) {
                      setIfscCode(value);
                    }
                  }
                }}
                required
                pattern="^[A-Z]{4}0[A-Z0-9]{6}$" // Enforces the IFSC code format
                title="Please enter a valid IFSC code in the format ABCD0XXXXXX (e.g., HDFC0123456)"
                // maxLength="11"  // Restrict the input length to 11 characters
              />
              {errors.ifscCode && <p className="error">{errors.ifscCode}</p>}

              <label htmlFor="">Bank Name</label>
              <input
                type="text"
                placeholder="Bank Name"
                value={
                  bankName ||
                  (isApproved?.bank == 3 ? "" : bankDetails?.bankName)
                }
                onChange={(e) => {
                  // Only allow alphabetic characters (A-Z, a-z) and spaces
                  let value = e.target.value.replace(/[^A-Za-z ]/g, ""); // Remove non-alphabetic characters
                  setBankName(value.toUpperCase()); // Assuming setBankName is a state setter function
                }}
                required
              />
              {errors.bankName && <p className="error">{errors.bankName}</p>}

              <label htmlFor="">Bank Type</label>
              <select
                id="mySelect"
                value={
                  selectedBankType ||
                  (isApproved?.bank == 3 ? "" : bankDetails?.accountType)
                }
                onChange={(e) => setSelectedBankType(e.target.value)}
                required
              >
                <option>Choose Bank Type</option>
                <option value="Saving">SAVING</option>
                <option value="Current">CURRENT</option>
              </select>
              {errors.selectedBankType && (
                <p className="error">{errors.selectedBankType}</p>
              )}

              <label htmlFor="">Holder Name</label>

              <input
                type="text"
                placeholder="Holder Name"
                value={
                  holderName ||
                  (isApproved?.bank == 3 ? "" : bankDetails?.holderName)
                }
                onChange={(e) => {
                  // Only allow alphabetic characters (A-Z, a-z) and spaces
                  let value = e.target.value.replace(/[^A-Za-z ]/g, ""); // Remove non-alphabetic characters
                  setHolderName(value.toUpperCase()); // Assuming setBankName is a state setter function
                }}
                // onChange={(e) => setHolderName(e.target.value.toUpperCase())}
                pattern="^[A-Z]+(([',. -][A-Z ])?[A-Z]*)*$"
                title="Please enter a valid holder name with capital letters"
                required
              />
              {errors.holderName && (
                <p className="error">{errors.holderName}</p>
              )}

              <label htmlFor="">Upload Document</label>
              <div className="file-upload-container">
                {/* Re-enable document upload if bank KYC is rejected */}
                {bankStatus == 0 || isApproved?.bank == 3 ? (
                  <>
                    <div {...getBankRootProps({ className: "dropzone" })}>
                      <input {...getBankInputProps()} />
                      <p>
                        {/* Drag 'n' drop bank document here, or click to select one */}
                        Upload Bank document here (.jpg, .jpeg & .png)
                      </p>
                    </div>
                  </>
                ) : null}

                {/* Show previews or existing document */}
                {previews.bank.length > 0 ? (
                  previews.bank.map((url, index) => (
                    <img
                      key={index}
                      src={url}
                      alt={`preview-${index}`}
                      style={{ width: 100, height: 100, margin: 10 }}
                    />
                  ))
                ) : bankDetails?.document && isApproved?.bank !== 3 ? ( // Hide old document if rejected
                  <img
                    src={bankDetails?.document}
                    alt="Bank Document"
                    style={{ width: 100, height: 100, margin: 10 }}
                  />
                ) : null}
              </div>

              {bankStatus == 1 ||
              bankStatus == 2 ||
              isApproved?.bank == 1 ||
              isApproved?.bank == 2 ? null : (
                <button className="btnPrimary" onClick={handleBank}>
                  Submit
                </button>
              )}
            </div>
          )}

          {activeTab === "pan" && (
            <div className="editProfile inputPrimary">
              <h3>PAN Details</h3>

              {isApproved?.pan == 2 ? (
                <p style={{ color: "green", fontSize: "15px" }}>
                  PAN KYC is approved
                </p>
              ) : isApproved?.pan == 3 ? (
                <>
                  <p className="error">PAN KYC is rejected</p>
                  {/* Display rejection reason */}
                  {panDetails?.reason && (
                    <p className="error">
                      Rejection Reason: {panDetails.reason}
                    </p>
                  )}
                </>
              ) : panStatus == 1 ? (
                <p className="error">
                  PAN KYC is already submitted, wait for approval.
                </p>
              ) : (
                ""
              )}

              {/* Allow re-upload if status is rejected (panStatus == 3) */}
              <label htmlFor="">PAN No</label>
              <input
                type="text"
                placeholder="PAN No"
                value={
                  panNo || (isApproved?.pan == 3 ? "" : panDetails?.panNumber)
                } // Clear PAN No if rejected
                onChange={(e) => setPanNo(e.target.value.toUpperCase())}
                onInput={(e) => {
                  // Remove invalid characters while typing
                  const regex = /^[A-Z]{0,5}[0-9]{0,4}[A-Z]{0,1}$/; // Valid PAN card format
                  if (!regex.test(e.target.value.toUpperCase())) {
                    e.target.value = panNo || ""; // Revert to last valid value
                  } else {
                    setPanNo(e.target.value.toUpperCase());
                  }
                }}
                pattern="^[A-Z]{5}[0-9]{4}[A-Z]{1}$" // Final validation for PAN format
                title="Please enter a valid PAN card number (e.g., ABCDE1234F)"
                maxLength={10} // PAN numbers have a fixed length of 10 characters
                required
              />

              {errors.panNo && <p className="error">{errors.panNo}</p>}
              <label htmlFor="dob">Date of Birth</label>
              {/* <input
                type="date"
                id="dob"
                value={dob}
                onChange={handleDobChange}
                required
              /> */}
              {isApproved?.pan == 3 || isApproved?.pan == 0 ? (
                <input
                  type="date"
                  id="dob"
                  value={dob}
                  onChange={handleDobChange}
                  required
                /> // Show DOB input if isApproved?.pan is not 3
              ) : (
                <input
                  type="text"
                  value={moment(panDetails?.dob).format("DD MMM YYYY")}
                  disabled
                />
              )}
              <label htmlFor="ageCheck">
                If you are under 18 years old, select "Minor".
              </label>
              {/* <div>
                <div>
                  <label htmlFor="minorCheck">Minor</label>
                  <input
                    type="checkbox"
                    id="minorCheck"
                    checked={isMinor}
                    onChange={handleChange}
                  />
                </div>

                <div>
                  <label htmlFor="majorCheck">Major</label>
                  <input
                    type="checkbox"
                    id="majorCheck"
                    checked={isMajor}
                    onChange={handleChange}
                  />
                </div>
              </div> */}

              {isApproved?.pan == 3 || isApproved?.pan == 0 ? (
                <div className="d-flex align-items-center gap-5 m-2">
                  <div className="d-flex align-items-center">
                    <label htmlFor="minorCheck" className="me-2">
                      Minor
                    </label>
                    <input
                      type="checkbox"
                      id="minorCheck"
                      checked={isMinor}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="d-flex align-items-center">
                    <label htmlFor="majorCheck" className="me-2">
                      Major
                    </label>
                    <input
                      type="checkbox"
                      id="majorCheck"
                      checked={isMajor}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              ) : (
                <div className="d-flex align-items-center gap-5 m-2">
                  <div className="d-flex align-items-center">
                    <label htmlFor="minorCheck" className="me-2">
                      Minor
                    </label>
                    <input
                      type="checkbox"
                      id="minorCheck"
                      checked={panDetails?.isAbove18 == "no"}
                    />
                  </div>

                  <div className="d-flex align-items-center">
                    <label htmlFor="majorCheck" className="me-2">
                      Major
                    </label>
                    <input
                      type="checkbox"
                      id="majorCheck"
                      checked={panDetails?.isAbove18 == "yes"}
                    />
                  </div>
                </div>
              )}

              <label htmlFor="">Upload Document</label>
              <div className="file-upload-container">
                {panStatus == 0 || isApproved?.pan == 3 ? ( // Re-enable upload if status is rejected
                  <>
                    <div {...getPanRootProps({ className: "dropzone" })}>
                      <input {...getPanInputProps()} />
                      <p>
                        {/* Drag 'n' drop PAN document here, or click to select one */}
                        Upload PAN document here (.jpg, .jpeg & .png)
                      </p>
                    </div>
                  </>
                ) : null}

                {/* Show previews or existing document */}
                {previews?.pan?.length > 0 ? (
                  previews?.pan?.map((url, index) => (
                    <img
                      key={index}
                      src={url}
                      alt={`preview-${index}`}
                      style={{ width: 100, height: 100, margin: 10 }}
                    />
                  ))
                ) : panDetails?.document && isApproved?.pan !== 3 ? ( // Hide old document if rejected
                  <img
                    src={panDetails?.document}
                    alt="PAN Document"
                    style={{ width: 100, height: 100, margin: 10 }}
                  />
                ) : null}
              </div>

              {panStatus == 1 ||
              panStatus == 2 ||
              isApproved?.pan == 1 ||
              isApproved?.pan == 2 ? (
                <button
                  style={{ display: "none" }}
                  className="btnPrimary"
                  onClick={handlePan}
                >
                  Submit
                </button>
              ) : (
                <button className="btnPrimary" onClick={handlePan}>
                  Submit
                </button>
              )}
            </div>
          )}

          {activeTab === "address" && (
            <div className="editProfile inputPrimary">
              <h3>Address Details</h3>

              {isApproved?.address == 2 ? (
                <p style={{ color: "green", fontSize: "15px" }}>
                  Address KYC is approved
                </p>
              ) : isApproved?.address == 3 ? (
                <>
                  <p className="error">Address KYC is rejected</p>
                  {addressDetails?.reason && (
                    <p className="error">
                      Rejection Reason: {addressDetails.reason}
                    </p>
                  )}
                </>
              ) : addressStatus == 1 ? (
                <p className="error">
                  Address KYC is Submitted, wait for approval.
                </p>
              ) : (
                ""
              )}

              {/* <label htmlFor="">ID Type</label>
              <select
                id="mySelect"
                value={
                  selectedValue ||
                  (isApproved?.address == 3 ? "" : addressDetails?.idType)
                } // Clear if rejected
                onChange={(e) => setSelectedValue(e.target.value.toUpperCase())}
                required
              >
                <option value="">Choose ID Type</option>
                <option value="ADHAR CARD">AADHAR CARD</option>
                <option value="PASSPORT">PASSPORT</option>
                <option value="DRIVER LICENSE">DRIVER LICENSE</option>
                <option value="VOTER ID">VOTER ID</option>
              </select>
              {errors.selectedValue && (
                <p className="error">{errors.selectedValue}</p>
              )}

              <label htmlFor="">ID Number</label>
              <input
                type="text"
                placeholder="ID Number"
                value={
                  idNo ||
                  (isApproved?.address == 3 ? "" : addressDetails?.idNumber)
                } // Clear if rejected
                onChange={(e) => setIdNo(e.target.value.toUpperCase())}
                required
              />
              {errors.idNo && <p className="error">{errors.idNo}</p>} */}

              <label htmlFor="">ID Type</label>
              <select
                id="mySelect"
                value={
                  selectedValue ||
                  (isApproved?.address == 3 ? "" : addressDetails?.idType)
                } // Clear if rejected
                onChange={(e) => setSelectedValue(e.target.value.toUpperCase())}
                required
              >
                <option value="">Choose ID Type</option>
                <option value="ADHAR CARD">AADHAR CARD</option>
                <option value="PASSPORT">PASSPORT</option>
                <option value="DRIVER LICENSE">DRIVER LICENSE</option>
                <option value="VOTER ID">VOTER ID</option>
              </select>
              {errors.selectedValue && (
                <p className="error">{errors.selectedValue}</p>
              )}

              <label htmlFor="">ID Number</label>
              <input
                type="text"
                placeholder="ID Number"
                value={
                  idNo ||
                  (isApproved?.address == 3 ? "" : addressDetails?.idNumber)
                } // Clear if rejected
                onInput={(e) => {
                  const value = e.target.value.toUpperCase();

                  // Restrict input based on selectedValue
                  let regex = null;

                  switch (selectedValue) {
                    case "ADHAR CARD":
                      regex = /^[0-9]{0,12}$/; // Only allow up to 12 digits
                      break;
                    case "PASSPORT":
                      regex = /^[A-Z]{0,1}[0-9]{0,7}$/; // First letter and up to 7 digits
                      break;
                    case "DRIVER LICENSE":
                      regex = /^[A-Z]{0,2}[0-9]{0,13}$/; // Two letters and up to 13 digits
                      break;
                    case "VOTER ID":
                      regex = /^[A-Z]{0,3}[0-9]{0,7}$/; // Three letters and up to 7 digits
                      break;
                    default:
                      break;
                  }

                  if (regex && !regex.test(value)) {
                    e.target.value = idNo || ""; // Revert to last valid value
                    return;
                  }

                  setIdNo(value);
                }}
                required
              />
              {errors.idNo && <p className="error">{errors.idNo}</p>}

              <label htmlFor="">Name</label>
              <input
                type="text"
                placeholder="Name"
                value={
                  name || (isApproved?.address == 3 ? "" : addressDetails?.name)
                } // Clear if rejected
                onChange={(e) => {
                  // Only allow alphabetic characters (A-Z, a-z)
                  let value = e.target.value.replace(/[^A-Za-z]/g, ""); // Remove non-alphabetic characters
                  setName(value.toUpperCase()); // Assuming setBankName is a state setter function
                }}
                // onChange={(e) => setName(e.target.value.toUpperCase())}
                pattern="^[A-Z]+(([',. -][A-Z ])?[A-Z]*)*$"
                title="Please enter a valid name with capital letters"
              />
              {errors.name && <p className="error">{errors.name}</p>}

              <label htmlFor="">Address</label>
              <input
                type="text"
                placeholder="Address"
                value={
                  address ||
                  (isApproved?.address == 3 ? "" : addressDetails?.address)
                } // Clear if rejected
                onChange={(e) => setAddress(e.target.value.toUpperCase())}
                pattern="^[A-Z]+(([',. -][A-Z ])?[A-Z]*)*$"
                title="Please enter a valid address with capital letters"
              />
              {errors.address && <p className="error">{errors.address}</p>}

              {/* Front Document Upload */}
              <label htmlFor="">Upload Document (Front)</label>
              <div className="file-upload-container">
                {addressStatus == 0 || isApproved?.address == 3 ? (
                  <>
                    <div
                      {...getAddressFrontRootProps({ className: "dropzone" })}
                    >
                      <input {...getAddressFrontInputProps()} />
                      <p>
                        {/* Drag 'n' drop address front document here, or click to select one */}
                        Upload Address front document here (.jpg, .jpeg, or
                        .png)
                      </p>
                    </div>
                    {previews.addressFront.map((url, index) => (
                      <img
                        key={index}
                        src={url}
                        alt={`preview-${index}`}
                        style={{ width: 100, height: 100, margin: 10 }}
                      />
                    ))}
                  </>
                ) : (
                  addressDetails?.documentFront &&
                  isApproved?.address !== 3 && (
                    <img
                      src={addressDetails.documentFront}
                      alt="address-front-preview"
                      style={{ width: 100, height: 100, margin: 10 }}
                    />
                  )
                )}
              </div>

              {selectedValue !== "PASSPORT" && (
                <>
                  <label htmlFor="">Upload Document (Back)</label>
                  <div className="file-upload-container">
                    {addressStatus == 0 || isApproved?.address == 3 ? (
                      <>
                        <div
                          {...getAddressBackRootProps({
                            className: "dropzone",
                          })}
                        >
                          <input {...getAddressBackInputProps()} />
                          <p>
                            Upload Address back document here (.jpg, .jpeg, or
                            .png)
                          </p>
                        </div>
                        {previews.addressBack.map((url, index) => (
                          <img
                            key={index}
                            src={url}
                            alt={`preview-${index}`}
                            style={{ width: 100, height: 100, margin: 10 }}
                          />
                        ))}
                      </>
                    ) : (
                      addressDetails?.documentBack &&
                      isApproved?.address !== 3 && (
                        <img
                          src={addressDetails.documentBack}
                          alt="document-back-preview"
                          style={{ width: 100, height: 100, margin: 10 }}
                        />
                      )
                    )}
                  </div>
                </>
              )}

              {addressStatus == 1 ||
              isApproved?.address == 1 ||
              addressStatus == 2 ||
              isApproved?.address == 2 ? null : (
                <button className="btnPrimary" onClick={handleAddress}>
                  Submit
                </button>
              )}
            </div>
          )}

          {activeTab === "nominee" && (
            <div className="editProfile inputPrimary">
              <h3>Nominee Details</h3>

              {isApproved?.nominee == 2 ? (
                <p style={{ color: "green", fontSize: "15px" }}>
                  Nominee Details are approved
                </p>
              ) : isApproved?.nominee == 3 ? (
                <>
                  <p className="error">Nominee Details are rejected</p>
                  {nomineeDetails?.reason && (
                    <p className="error">
                      Rejection Reason: {nomineeDetails.reason}
                    </p>
                  )}
                </>
              ) : nomineeStatus == 1 ? (
                <p className="error">
                  Nominee Details are Submitted, wait for approval.
                </p>
              ) : (
                ""
              )}

              <label htmlFor="">Nominee Name</label>
              <input
                type="text"
                placeholder="Nominee Name"
                value={
                  nomineeName ||
                  (isApproved?.nominee == 3 ? "" : nomineeDetails?.nomineeName)
                } // Clear if rejected
                onChange={(e) => {
                  // Only allow alphabetic characters (A-Z, a-z)
                  let value = e.target.value.replace(/[^A-Za-z]/g, ""); // Remove non-alphabetic characters
                  setNomineeName(value.toUpperCase()); // Assuming setBankName is a state setter function
                }}
                pattern="^[A-Z]+(([',. -][A-Z ])?[A-Z]*)*$"
                title="Please enter a valid nominee name with capital letters"
              />

              <label htmlFor="">Relationship</label>
              <input
                type="text"
                placeholder="Relationship"
                value={
                  nomineeRelationship ||
                  (isApproved?.nominee == 3 ? "" : nomineeDetails?.relationship)
                } // Clear if rejected
                onChange={(e) => {
                  // Only allow alphabetic characters (A-Z, a-z)
                  let value = e.target.value.replace(/[^A-Za-z]/g, ""); // Remove non-alphabetic characters
                  setNomineeRelationship(value.toUpperCase()); // Assuming setBankName is a state setter function
                }}
                pattern="^[A-Z]+(([',. -][A-Z ])?[A-Z]*)*$"
                title="Please enter a valid relationship with capital letters"
              />

              {/* <label htmlFor="">ID Type</label>
              <select
                id="mySelect"
                value={idDocumentType || nomineeDetails?.idDocumentType}
                onChange={(e) =>
                  setIdDocumentType(e.target.value.toUpperCase())
                }
                required
              >
                <option value="">Choose ID Type</option>
                <option value="ADHAR CARD">AADHAR CARD</option>
                <option value="PASSPORT">PASSPORT</option>
                <option value="DRIVER LICENSE">DRIVER LICENSE</option>
                <option value="VOTER ID">VOTER ID</option>
              </select>
              {errors.idDocumentType && (
                <p className="error">{errors.idDocumentType}</p>
              )}

              <label htmlFor="">ID Number</label>
              <input
                type="text"
                placeholder="ID Number"
                value={
                  nomineeIdNo ||
                  (isApproved?.nominee == 3
                    ? ""
                    : nomineeDetails?.idDocumentNumber)
                } // Clear if rejected
                onChange={(e) => setNomineeIdNo(e.target.value.toUpperCase())}
                required
              />
              {errors.idDocumentNumber && (
                <p className="error">{errors.idDocumentNumber}</p>
              )} */}

              <label htmlFor="">ID Type</label>
              <select
                id="mySelect"
                value={idDocumentType || nomineeDetails?.idDocumentType}
                onChange={(e) =>
                  setIdDocumentType(e.target.value.toUpperCase())
                }
                required
              >
                <option value="">Choose ID Type</option>
                <option value="ADHAR CARD">AADHAR CARD</option>
                <option value="PASSPORT">PASSPORT</option>
                <option value="DRIVER LICENSE">DRIVER LICENSE</option>
                <option value="VOTER ID">VOTER ID</option>
              </select>
              {errors.idDocumentType && (
                <p className="error">{errors.idDocumentType}</p>
              )}

              <label htmlFor="">ID Number</label>
              <input
                type="text"
                placeholder="ID Number"
                value={
                  nomineeIdNo ||
                  (isApproved?.nominee == 3
                    ? ""
                    : nomineeDetails?.idDocumentNumber)
                } // Clear if rejected
                onInput={(e) => {
                  const value = e.target.value.toUpperCase();

                  // Restrict input based on idDocumentType
                  let regex = null;

                  switch (idDocumentType) {
                    case "ADHAR CARD":
                      regex = /^[0-9]{0,12}$/; // Only allow up to 12 digits
                      break;
                    case "PASSPORT":
                      regex = /^[A-Z]{0,1}[0-9]{0,7}$/; // First letter and up to 7 digits
                      break;
                    case "DRIVER LICENSE":
                      regex = /^[A-Z]{0,2}[0-9]{0,13}$/; // Two letters and up to 13 digits
                      break;
                    case "VOTER ID":
                      regex = /^[A-Z]{0,3}[0-9]{0,7}$/; // Three letters and up to 7 digits
                      break;
                    default:
                      break;
                  }

                  if (regex && !regex.test(value)) {
                    e.target.value = nomineeIdNo || ""; // Revert to last valid value
                    return;
                  }

                  setNomineeIdNo(value);
                }}
                required
              />
              {errors.idDocumentNumber && (
                <p className="error">{errors.idDocumentNumber}</p>
              )}

              {/* Front Document Upload */}
              <label htmlFor="">Upload Document (Front)</label>
              <div className="file-upload-container">
                {nomineeStatus == 0 || isApproved?.nominee == 3 ? (
                  <>
                    <div
                      {...getNomineeFrontRootProps({ className: "dropzone" })}
                    >
                      <input {...getNomineeFrontInputProps()} />
                      <p>
                        Upload Nominee front document here (.jpg, .jpeg, or
                        .png)
                      </p>
                    </div>
                    {previews.nomineeFront.map((url, index) => (
                      <img
                        key={index}
                        src={url}
                        alt={`preview-${index}`}
                        style={{ width: 100, height: 100, margin: 10 }}
                      />
                    ))}
                  </>
                ) : (
                  nomineeDetails?.documentFront &&
                  isApproved?.nominee !== 3 && (
                    <img
                      src={nomineeDetails.documentFront}
                      alt="nominee-front-preview"
                      style={{ width: 100, height: 100, margin: 10 }}
                    />
                  )
                )}
              </div>

              {/* Conditionally render Back Document Upload based on selected ID Type */}
              {idDocumentType !== "PASSPORT" && (
                <>
                  <label htmlFor="">Upload Document (Back)</label>
                  <div className="file-upload-container">
                    {nomineeStatus == 0 || isApproved?.nominee == 3 ? (
                      <>
                        <div
                          {...getNomineeBackRootProps({
                            className: "dropzone",
                          })}
                        >
                          <input {...getNomineeBackInputProps()} />
                          <p>
                            Upload Nominee back document here (.jpg, .jpeg, or
                            .png)
                          </p>
                        </div>
                        {previews.nomineeBack.map((url, index) => (
                          <img
                            key={index}
                            src={url}
                            alt={`preview-${index}`}
                            style={{ width: 100, height: 100, margin: 10 }}
                          />
                        ))}
                      </>
                    ) : (
                      nomineeDetails?.documentBack &&
                      isApproved?.nominee !== 3 && (
                        <img
                          src={nomineeDetails.documentBack}
                          alt="nominee-back-preview"
                          style={{ width: 100, height: 100, margin: 10 }}
                        />
                      )
                    )}
                  </div>
                </>
              )}

              {nomineeStatus == 1 ||
              isApproved?.nominee == 1 ||
              nomineeStatus == 2 ||
              isApproved?.nominee == 2 ? null : (
                <button className="btnPrimary" onClick={handleNominee}>
                  Submit
                </button>
              )}
            </div>
          )}
        </Col>
      </Row>
    </section>
  );
};

export default KYC;
