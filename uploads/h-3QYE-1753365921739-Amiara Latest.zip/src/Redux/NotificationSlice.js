import { createSlice } from "@reduxjs/toolkit";

export const notificationSlice = createSlice({
  name: "notification",
  initialState: {
    isPopupOpen: true, // Initially, the popup is opened
  },
  reducers: {
    setPopupShown: (state) => {
        console.log("Redux: Setting popup open");
      state.isPopupOpen = true; // Open the popup
    },
    resetPopupState: (state) => {
        console.log("Redux: Resetting popup state (closing)");
      state.isPopupOpen = false; // Close the popup
    },
  },
});

export const { setPopupShown, resetPopupState } = notificationSlice.actions;
export default notificationSlice.reducer;
