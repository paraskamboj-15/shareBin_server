import React, { useEffect, useState } from "react";
import "./Header.css";
import Logo from "./../../Images/logo.png";
import Logo1 from "./../../Images/logo.png";
import { GiShakingHands } from "react-icons/gi";
import { FaUserFriends } from "react-icons/fa";
import ReferPopUp from "./../ReferPopUp/ReferPopUp";

// import LogoIcon from "./../../Images/logoIcon.png";
import User from "./../../Images/user.png";
import { FiCopy } from "react-icons/fi";
import { HiMoon } from "react-icons/hi2";
import { HiSun } from "react-icons/hi";
import { FaUserCircle } from "react-icons/fa";
import { TiArrowSortedDown } from "react-icons/ti";
import { FiMenu } from "react-icons/fi";
import { setSidebarDisplay } from "./../../Redux/SideDisplaySlice";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import CopyFromtag from "../../Common/CopyFromtag";
import PlayStore from "./../../Images/playstore.png";
import AppleStore from "./../../Images/applestore.png";
import { IoIosNotifications } from "react-icons/io";
import { MdNotificationsActive } from "react-icons/md";
import ReferralComponent from "../ReferralComponent";
import { FaUserAlt } from "react-icons/fa";
import { IoIosArrowUp } from "react-icons/io";
import useAxiosHelper from "../../Common/AxiosHelper";
import { ApiPaths } from "../../Config/ApiPath";

const Header = (props) => {
  const navigate = useNavigate();
  const { AxiosGet } = useAxiosHelper();
  const [logo, setLogo] = useState(Logo);
  const [settingDisplay, setSettingDisplay] = useState("none");
  const [alertmsg, setAlertmsg] = useState("-130px");
  const [activeDropdown, setActiveDropdown] = useState(null);
  const dispatch = useDispatch();
  const delay = (delayInms) => {
    return new Promise((resolve) => setTimeout(resolve, delayInms));
  };
  const Dark = () => {
    setLogo(Logo);
    let ThemeColor = document.querySelector(":root");
    var rs = getComputedStyle(ThemeColor);
    ThemeColor.style.setProperty("--bodyColor", "#151515");
    ThemeColor.style.setProperty("--containerColor", "#1D1D1D");
    ThemeColor.style.setProperty("--textHeading", "#FFFFFF");
    ThemeColor.style.setProperty("--sideActiveColor", "#FFFFFF");
    ThemeColor.style.setProperty("--lightColor", "#252525");
    ThemeColor.style.setProperty("--borderColor", "#fff");
    ThemeColor.style.setProperty("--darkLightText", "#fff");
    ThemeColor.style.setProperty("--darkLightBackground", "#181818");
    ThemeColor.style.setProperty("--activeTextColor", "#FFFFFF");
    ThemeColor.style.setProperty("--textColor", "white");
    ThemeColor.style.setProperty("--rewardCardActive", "#73ba3f2b ");
    ThemeColor.style.setProperty("--rewardCardInactive", "#72ba3f0c ");
    ThemeColor.style.setProperty("--colorPrimary", "#d574b8");
    ThemeColor.style.setProperty("--boxShadow", "none");
    ThemeColor.style.setProperty(
      "--btnBackground",
      "linear-gradient(56deg, rgba(130, 130, 130, 0.05) 0%, rgba(130, 130, 130, 0.05) 33.333%, rgba(255, 255, 255, 0.05) 33.333%, rgba(255, 255, 255, 0.05) 66.666%, rgba(198, 198, 198, 0.05) 66.666%, rgba(198, 198, 198, 0.05) 99.999%), linear-gradient(29deg, rgba(94, 94, 94, 0.05) 0%, rgba(94, 94, 94, 0.05) 33.333%, rgba(185, 185, 185, 0.05) 33.333%, rgba(185, 185, 185, 0.05) 66.666%, rgba(113, 113, 113, 0.05) 66.666%, rgba(113, 113, 113, 0.05) 99.999%), linear-gradient(129deg, rgba(196, 196, 196, 0.05) 0%, rgba(196, 196, 196, 0.05) 33.333%, rgba(148, 148, 148, 0.05) 33.333%, rgba(148, 148, 148, 0.05) 66.666%, rgba(24, 24, 24, 0.05) 66.666%, rgba(24, 24, 24, 0.05) 99.999%), linear-gradient(76deg, rgba(19, 19, 19, 0.05) 0%, rgba(19, 19, 19, 0.05) 33.333%, rgba(159, 159, 159, 0.05) 33.333%, rgba(159, 159, 159, 0.05) 66.666%, rgba(108, 108, 108, 0.05) 66.666%, rgba(108, 108, 108, 0.05) 99.999%), linear-gradient(112deg, rgba(225, 225, 225, 0.05) 0%, rgba(225, 225, 225, 0.05) 33.333%, rgba(13, 13, 13, 0.05) 33.333%, rgba(13, 13, 13, 0.05) 66.666%, rgba(81, 81, 81, 0.05) 66.666%, rgba(81, 81, 81, 0.05) 99.999%), linear-gradient(90deg, rgb(151 4 56), rgb(179 94 154))"
    );
  };
  const Light = () => {
    setLogo(Logo1);
    let ThemeColor = document.querySelector(":root");
    ThemeColor.style.setProperty("--bodyColor", "rgb(244, 247, 252)");
    ThemeColor.style.setProperty("--containerColor", "#fff");
    ThemeColor.style.setProperty("--textHeading", "black;");
    ThemeColor.style.setProperty("--sideActiveColor", "#000");
    ThemeColor.style.setProperty("--lightColor", "#d3ebd494");
    ThemeColor.style.setProperty("--borderColor", "#fff");
    ThemeColor.style.setProperty("--darkLightText", "#f87735");
    ThemeColor.style.setProperty("--darkLightBackground", "#EFEFEF");
    ThemeColor.style.setProperty("--activeTextColor", "Black");
    ThemeColor.style.setProperty("--textColor", "black");
    ThemeColor.style.setProperty("--rewardCardActive", "#f87735 ");
    ThemeColor.style.setProperty("--rewardCardInactive", "#f87735");
    ThemeColor.style.setProperty("--colorPrimary", "#7a3f60 ");
    ThemeColor.style.setProperty("--boxShadow", "0 0 12px 0 #1d438347;");
    ThemeColor.style.setProperty(
      "--btnBackground",
      "linear-gradient(56deg, rgba(130, 130, 130, 0.05) 0%, rgba(130, 130, 130, 0.05) 33.333%, rgba(255, 255, 255, 0.05) 33.333%, rgba(255, 255, 255, 0.05) 66.666%, rgba(198, 198, 198, 0.05) 66.666%, rgba(198, 198, 198, 0.05) 99.999%), linear-gradient(29deg, rgba(94, 94, 94, 0.05) 0%, rgba(94, 94, 94, 0.05) 33.333%, rgba(185, 185, 185, 0.05) 33.333%, rgba(185, 185, 185, 0.05) 66.666%, rgba(113, 113, 113, 0.05) 66.666%, rgba(113, 113, 113, 0.05) 99.999%), linear-gradient(129deg, rgba(196, 196, 196, 0.05) 0%, rgba(196, 196, 196, 0.05) 33.333%, rgba(148, 148, 148, 0.05) 33.333%, rgba(148, 148, 148, 0.05) 66.666%, rgba(24, 24, 24, 0.05) 66.666%, rgba(24, 24, 24, 0.05) 99.999%), linear-gradient(76deg, rgba(19, 19, 19, 0.05) 0%, rgba(19, 19, 19, 0.05) 33.333%, rgba(159, 159, 159, 0.05) 33.333%, rgba(159, 159, 159, 0.05) 66.666%, rgba(108, 108, 108, 0.05) 66.666%, rgba(108, 108, 108, 0.05) 99.999%), linear-gradient(112deg, rgba(225, 225, 225, 0.05) 0%, rgba(225, 225, 225, 0.05) 33.333%, rgba(13, 13, 13, 0.05) 33.333%, rgba(13, 13, 13, 0.05) 66.666%, rgba(81, 81, 81, 0.05) 66.666%, rgba(81, 81, 81, 0.05) 99.999%), linear-gradient(90deg, rgb(75, 2, 28), rgb(175, 60, 142))"
    );
  };
  const [showDropdown, setShowDropdown] = useState(false);
  const [isReferOpen, setIsReferOpen] = useState(false);
  const [confirmLogout, setConfirmLogout] = useState(false);

  const referButton = () => {
    setIsReferOpen(!isReferOpen);
  };
  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };
  const profileImg = props?.profiledata?.profileImg;
  const handleEditProfile = () => {
    setShowDropdown(false);
    navigate("profile"); // Navigate to profile page
  };
  function LogOut() {
    setConfirmLogout(true);
  }
  function LogoutFunc() {
    localStorage.clear();
    navigate("/");
  }
  const [newsCount, setNewsCount] = useState([]);
  useEffect(() => {
    FetchData();
  }, []);

  async function FetchData() {
    const queryParams = new URLSearchParams({ news_section: 1 });
    const queryString = queryParams.toString();
    const res = await AxiosGet(`${ApiPaths.getNotifications}?${queryString}`);
    setNewsCount(res?.data?.length);
    console.log("Notification Data", res?.data?.length);
  }

  return (
    <>
      {confirmLogout ? (
        <div className="otpSection" style={{ zIndex: "999" }}>
          <div className="otpContainer">
            <h1>Logout</h1>
            <p>Are you sure you want to log out?</p>
            {
              <div>
                <button
                  className="btnSecondary"
                  onClick={() => setConfirmLogout(false)}
                >
                  No
                </button>
                <button className="btnPrimary" onClick={() => LogoutFunc()}>
                  Yes
                </button>
              </div>
            }
          </div>
        </div>
      ) : null}

      <div className="header">
        <div className="alertMsg" id="CopiedMsg" style={{ top: alertmsg }}>
          Link Copied!
        </div>
        <div>
          <Link to="/dashboard">
            <img id="logoicon" src={Logo} alt="logo.png" />
          </Link>
          <div className="headerLogoLink headerLinkHeader">
            <button className="btnPrimary d-flex gap-2" onClick={referButton}>
              Refer a Friend
              <FaUserFriends size={18} />
            </button>
            {isReferOpen && (
              <ReferPopUp
                link={props.link}
                isOpen={referButton}
                onClose={referButton}
              />
            )}
          </div>
        </div>

        <div className="headerProfileColorDiv">
          <div className="themeChangeIcons">
            {/* <p>color <br></br>mode</p> */}
            {/* <i id="moon" onClick={Dark}>
              {" "}
              <HiMoon />
            </i> */}
            {/* <i onClick={Light}>
              <HiSun />
            </i> */}
            <Link to="/dashboard/notification">
              <i style={{ position: "relative" }}>
                <MdNotificationsActive />
                {newsCount > 0 ? (
                  <div
                    style={{
                      position: "absolute",
                      left: "10px",
                      top: "-10px",
                      fontSize: "12px",
                      color: "#fff",
                      background: "red",
                      padding: "2px",
                      borderRadius: "50%",
                      height: "20px",
                      width: "20px",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    {newsCount}
                  </div>
                ) : (
                  <div
                    style={{
                      position: "absolute",
                      left: "10px",
                      top: "-10px",
                      fontSize: "12px",
                      color: "#fff",
                      background: "green",
                      padding: "2px",
                      borderRadius: "50%",
                      height: "20px",
                      width: "20px",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    0
                  </div>
                )}
              </i>
            </Link>
          </div>
          {/* <i className="userIcon">
            <FaUserCircle />
          </i> */}
          <div className="headerProfileUser">
            <div className="headerProfileDiv" onClick={toggleDropdown}>
              <i
                style={{
                  transform: `rotate(${showDropdown ? "180deg" : "0deg"})`,
                  background: "none",
                  color: "var(--colorPrimary)",
                  cursor: "pointer",
                }}
              >
                <IoIosArrowUp />
              </i>
              <p>{props?.username}</p>
              <i>
                {profileImg ? (
                  <img
                    src={profileImg}
                    height={20}
                    width={20}
                    style={{
                      borderRadius: "50%",
                      border: "2px solid var(--colorPrimary)",
                    }}
                    alt="Profile Image"
                  />
                ) : (
                  <FaUserAlt />
                )}
              </i>

              {showDropdown && (
                <div className="dropdownMenu">
                  <ul>
                    <li onClick={handleEditProfile}>Edit Profile</li>
                    <li onClick={LogOut}>Logout</li>
                  </ul>
                </div>
              )}
            </div>
          </div>

          <i
            className="menuIcon"
            onClick={() => dispatch(setSidebarDisplay("block"))}
          >
            <FiMenu />
          </i>
        </div>
      </div>

      <div className="usernameShow">
        <div className="usernameShowContent">
          <p>
            {props?.username}({props?.name})
          </p>
        </div>
        {props?.status == 0 ? (
          <div className="statusShow"></div>
        ) : (
          <div className="statusNotShow"></div>
        )}
      </div>
    </>
  );
};

export default Header;
