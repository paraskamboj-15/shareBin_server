// import React from "react";
// // import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
// // import "react-circular-progressbar/dist/styles.css";

// const RankProgress = ({ currentBusiness, requiredBusiness, rankName }) => {
//   // Calculate percentage
//   const percentage = Math.min((currentBusiness / requiredBusiness) * 100, 100);

//   return (
//     <div style={{ width: "90px", margin: "auto" }}>
//       <CircularProgressbar
//         value={percentage}
//         // text={`${Math.round(percentage)}% \n ${rankName}`}
//         styles={buildStyles({
//           textColor: "var(--colorPrimary)",
//           pathColor: "var(--colorPrimary)",
//           trailColor: "#d6d6d6",
//         })}
//       />
//       <div
//         style={{
//           position: "relative",
//           top: "-65px",
//           textAlign: "center",
//           fontSize: "14px",
//           color: "var(--colorPrimary)",
//         }}
//       >
//         <div>{Math.round(percentage)}%</div>
//         <div>{rankName}</div>
//       </div>
//       {/* <p style={{ textAlign: "center", marginTop: "10px" }}>
//         Business: {currentBusiness}/{requiredBusiness}
//       </p> */}
//     </div>
//   );
// };

// export default RankProgress;
