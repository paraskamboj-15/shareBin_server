import React, { useEffect, useState } from "react";
import { ApiPaths } from "../../Config/ApiPath";
import Loader from "../../Components/Loader/Loader";
import useAxiosHelper from "../../Common/AxiosHelper";
import { toastFailed, toastInfo, toastSuccess } from "../../Common/Data";
import moment from "moment";
import PopUp from "../../Components/PayNowPopUp/PopUp";
import { useNavigate } from "react-router-dom";
import { FaCrown } from "react-icons/fa";
const SipOrderHistory = () => {
  const [paymentTransaction, setPaymentTransaction] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filteredTransactions, setFilteredTransactions] = useState([]);
  const [investmentAmounts, setInvestmentAmounts] = useState([]);
  const [packageNames, setPackageNames] = useState([]); // Package names state
  const [selectedPackage, setSelectedPackage] = useState(null); // Selected package name
  const [isFilterApplied, setIsFilterApplied] = useState(false);
  const [filteredSipIds, setFilteredSipIds] = useState([]);
  const [selectedSipId, setSelectedSipId] = useState(null);
  const { AxiosGet, AxiosPost } = useAxiosHelper();
  const [companyData, setCompanyData] = useState([]);
  const [activePackage, setActivePackage] = useState(null);
  const [showSIPPopUp, setShowSIPPopUp] = useState(false);
  const [progressBar, setProgressBar] = useState();
  const [order, setOrder] = useState();

  const navigate = useNavigate();
  const [showPopUp, setShowPopUp] = useState({
    visible: false,
    sipId: null,
    amount: null,
    maturityDate: null,
    installmentId: null,
  });
  useEffect(() => {
    CompanyInfo();
  }, []);
  const handleInvoice = (transaction, inst) => {
    navigate("/dashboard/invoice", { state: { transaction, inst } });
  };
  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      console.log(error);
    }
  }
  async function getSip() {
    setLoading(true);
    try {
      const res = await AxiosGet(ApiPaths.getSip);
      console.log(res, "res");
      const transactions = res?.data || [];
      setPaymentTransaction(transactions);
      // Extract unique package names
      const packages = [
        ...new Set(transactions.map((transaction) => transaction.package_type)),
      ];
      setPackageNames(packages);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    getSip();
  }, []);
  const filterByPackage = (packageName) => {
    setSelectedPackage(packageName);
    setActivePackage(packageName);

    const filtered = paymentTransaction.filter(
      (transaction) => transaction.package_type === packageName
    );
    // Extract unique amounts based on selected package
    const amounts = [
      ...new Set(filtered.map((transaction) => transaction.investment_amount)),
    ];
    setInvestmentAmounts(amounts);
    setIsFilterApplied(false);
    setSelectedSipId(null);
    setFilteredTransactions([]);
  };
  const [activeAmount, setActiveAmount] = useState(null);

  const filterByAmount = (amount) => {
    setActiveAmount(amount);

    const filtered = paymentTransaction.filter(
      (transaction) =>
        transaction.package_type === selectedPackage &&
        transaction.investment_amount === amount
    );

    const sipData = filtered.map((transaction) => ({
      sipId: transaction.sip_Id,
      createdAt: new Date(transaction.createdAt),
    }));

    const sortedSipData = sipData.sort((a, b) => b.createdAt - a.createdAt);
    const sortedSipIds = sortedSipData.map((data) => data.sipId);

    setFilteredTransactions(filtered);
    setIsFilterApplied(true);
    setFilteredSipIds(sortedSipIds);
    setSelectedSipId(null);
  };
  const payInstallment = async (
    sip_Id,
    installment_id,
    amount,
    maturityDate
  ) => {
    setLoading(true);
    try {
      const body = {
        sip_Id: parseInt(sip_Id),
        installment_id: parseInt(installment_id),
      };

      const response = await AxiosPost(ApiPaths.payInstallment, body);
      console.log(response, "ffffffff");
      if (response?.success === true) {
        toastSuccess(response?.message);
        navigate("/dashboard");

        const currentDate = new Date();
        const updatedTransactions = filteredTransactions.map((transaction) => {
          if (transaction.sip_Id === sip_Id) {
            return {
              ...transaction,
              installment: transaction.installment.map((inst) => {
                if (inst.installment_id === installment_id) {
                  return {
                    ...inst,
                    status: 1,
                    paid_Date: currentDate,
                  };
                }
                return inst;
              }),
            };
          }
          return transaction;
        });
        setFilteredTransactions(updatedTransactions);
      } else {
        toastFailed("Coming Soon");
      }
    } catch (e) {
      console.error("Error:", e);
      toastFailed(e?.response?.data?.message || "Failed to pay installment.");
    } finally {
      setLoading(false);
    }
  };
  const handleProceedClick = (sipId, amount, maturityDate, installmentId) => {
    setShowPopUp({ visible: true, sipId, amount, maturityDate, installmentId });
  };
  const filterBySipId = (sipId) => {
    setSelectedSipId(sipId);
    const filteredBySipId = paymentTransaction.filter(
      (transaction) => transaction.sip_Id === sipId
    );
    setFilteredTransactions(filteredBySipId);
  };

  async function handleAction(orderId, orderData) {
    try {
      console.log("order data", orderId, orderData);

      setLoading(true);
      const body = {
        order_Id: orderId,
      };
      console.log(body);
      const res = await AxiosPost(ApiPaths.progressPlan, body);
      console.log(res, "..");
      setProgressBar(res?.data);
      setOrder(orderData);
      console.log(order);
      // navigate("/dashboard/progress_bar", {
      //   state: { progressBar: res?.data, order },
      // });
      setShowSIPPopUp(true);
    } catch (e) {
      toastFailed(e?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  }
  return (
    <>
      {loading && <Loader />}
      <section style={{ marginTop: "20px" }}>
        <section className="history">
          <h1 className="textHeading mt-30" style={{ marginBottom: "30px" }}>
            SIP Purchased Details
          </h1>
          {paymentTransaction.length > 0 ? (
            <>
              <div
                className="filter-buttons SipSelectIncomeSelectBox"
                style={{ marginBottom: "20px" }}
              >
                {packageNames.map((packageName, index) => (
                  <button
                    key={index}
                    className={
                      packageName === activePackage ? "btnPrimary" : ""
                    }
                    style={
                      packageName === activePackage
                        ? { width: "fit-content" }
                        : {}
                    }
                    onClick={() => filterByPackage(packageName)}
                  >
                    {packageName}
                  </button>
                ))}
              </div>
              <div
                className="filter-buttons SipSelectIncomeSelectBox"
                style={{ marginBottom: "20px" }}
              >
                {selectedPackage ? (
                  investmentAmounts.length > 0 ? (
                    investmentAmounts.map((amount, index) => (
                      <button
                        key={index}
                        className={amount === activeAmount ? "btnPrimary" : ""}
                        style={
                          amount === activeAmount
                            ? { width: "fit-content" }
                            : {}
                        }
                        onClick={() => filterByAmount(amount)}
                      >
                        {amount} {companyData?.currency}
                      </button>
                    ))
                  ) : (
                    <p>
                      No investment amounts available for the selected plan.
                    </p>
                  )
                ) : (
                  <p>Please select a plan name to view further details.</p>
                )}
              </div>
              {/* New Logic: Display SIP IDs based on the selected amount */}
              {selectedPackage &&
                selectedSipId === null &&
                investmentAmounts.length > 0 && (
                  <div
                    className="filter-buttons SipIdSelectBox"
                    style={{ marginBottom: "20px" }}
                  >
                    {isFilterApplied ? (
                      filteredSipIds.length > 0 ? (
                        filteredSipIds.map((sipId, index) => (
                          <button
                            className="SipIdFilter"
                            key={index}
                            onClick={() => filterBySipId(sipId)}
                          >
                            SIP ID: {sipId}
                          </button>
                        ))
                      ) : (
                        <p>No SIPs found for the selected amount.</p>
                      )
                    ) : (
                      <p>Please select an amount to see your SIPs.</p>
                    )}
                  </div>
                )}
              {/* Show SIP details if a SIP ID is selected */}
              {selectedSipId &&
              isFilterApplied &&
              filteredTransactions.length > 0 ? (
                <>
                  <div className="maturityInfo">
                    <p style={{ color: "var(--textColor)" }}>
                      Showing details for SIP ID: {selectedSipId}
                    </p>
                    {/* <button
                      onClick={() =>
                        handleAction(
                          filteredTransactions[0]?.order_Id,
                          filteredTransactions[0]
                        )
                      }
                      className="btnPrimary m-0"
                      style={{ width: "15%" }}
                    >
                      Info.
                    </button> */}
                  </div>
                  <div className="maturityDateDiv">
                    <span>
                      Maturity Date:{" "}
                      {moment(filteredTransactions[0]?.maturity_date).format(
                        "DD-MM-YYYY"
                      )}
                    </span>
                  </div>
                  <div className="table">
                    <table>
                      <thead>
                        <tr>
                          <th>S.No</th>
                          <th>Installment Amount ({companyData?.currency})</th>
                          <th>Investment Plan</th>
                          <th>Installment Date</th>
                          <th>Paid Date</th>
                          <th>Status</th>
                          <th>Invoice</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredTransactions.map((transaction, i) => {
                          let firstPendingFound = false;
                          return transaction.installment.map((inst, j) => {
                            let statusDisplay;
                            if (inst.status === 1) {
                              statusDisplay = "Paid";
                            } else if (
                              inst.status === 0 &&
                              !firstPendingFound
                            ) {
                              statusDisplay = (
                                <button
                                  className="btnPrimary mb-0"
                                  onClick={() =>
                                    handleProceedClick(
                                      transaction.sip_Id,
                                      inst.installment_amount,
                                      inst.installment_Date,
                                      inst.installment_id
                                    )
                                  }
                                >
                                  Pay
                                </button>
                              );
                              firstPendingFound = true;
                            } else {
                              statusDisplay = "Upcoming...";
                            }

                            // Display only details for the selected SIP ID
                            if (transaction.sip_Id === selectedSipId) {
                              return (
                                <tr key={`${i}-${j}`}>
                                  <td>{j + 1}</td>
                                  <td>{inst.installment_amount}</td>
                                  <td>{transaction.package_type}</td>
                                  <td>
                                    {moment(inst.installment_Date).format(
                                      "DD MMM YY"
                                    )}
                                  </td>
                                  <td>
                                    {inst.paid_Date
                                      ? moment(inst.paid_Date).format(
                                          "DD MMM YY"
                                        )
                                      : "Pending"}
                                  </td>
                                  <td>{statusDisplay}</td>
                                  <td>
                                    {inst.status == 1 ? (
                                      <button
                                        onClick={() =>
                                          handleInvoice(transaction, inst)
                                        }
                                        className="btnPrimary m-0"
                                      >
                                        Invoice
                                      </button>
                                    ) : (
                                      "Inst. Unpaid"
                                    )}
                                  </td>
                                </tr>
                              );
                            } else {
                              return null;
                            }
                          });
                        })}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                !selectedSipId &&
                isFilterApplied && (
                  <p style={{ color: "var(--textColor)" }}>
                    Please select a SIP ID to view further details.
                  </p>
                )
              )}
            </>
          ) : (
            <p style={{ color: "var(--textColor)", marginTop: "20px" }}>
              No orders found.
            </p>
          )}
        </section>
        {showSIPPopUp && (
          <div className="otpSection" style={{ zIndex: "999" }}>
            <div className="otpContainer" style={{ width: "400px" }}>
              <h4>
                <strong>Progress for this transaction </strong>
              </h4>
              <div className="progressBarData">
                <p>
                  <strong>Name:</strong>
                </p>
                <p>{order?.name}</p>
              </div>
              <div className="progressBarData">
                <p>
                  <strong>Username:</strong>
                </p>
                <p>{order?.username}</p>
              </div>
              <div className="progressBarData">
                <p>
                  <strong>Order Date:</strong>
                </p>
                <p>{moment(order?.order_Date).format("DD MMM YY")}</p>
              </div>
              <div className="progressBarData">
                <p>
                  <strong>Maturity Date:</strong>
                </p>
                <p>
                  {moment(order?.order_Date)
                    .add(order?.maturity_Date, "months")
                    .format("DD MMM YY")}
                </p>
              </div>
              <div className="progressBarData">
                <p>
                  <strong>Invested Amount:</strong>
                </p>
                <p>
                  {companyData?.currency}{" "}
                  {parseFloat(progressBar?.amount).toFixed(2)}
                </p>
              </div>
              <div className="progressBarData">
                <p>
                  <strong>Total Income:</strong>
                </p>
                <p>
                  {companyData?.currency}{" "}
                  {/* {parseFloat(progressBar?.totalRoiIncome).toFixed(2)} */}
                </p>
              </div>

              <div className="progress-bar-wrapper">
                <div className="crownProgress">
                  <label htmlFor="progressBar">
                    <strong>Progress:</strong>
                  </label>
                  <i>
                    <FaCrown />
                  </i>
                </div>
                <div className="progress-bar-container">
                  <div
                    className="progressBar"
                    style={{
                      width: `${
                        (progressBar?.totalRoiIncome /
                          progressBar?.totalAmount) *
                        100
                      }%`,
                      marginTop: "0px",
                      background: "var(--colorPrimary)",
                    }}
                  ></div>
                </div>
                <div className="progressAmount">
                  <div></div>
                  <div>
                    <p>
                      {companyData?.currency} {progressBar?.totalAmount}
                    </p>
                  </div>
                </div>
              </div>

              <button
                className="refer-popup-close-btn"
                onClick={() => setShowSIPPopUp(false)}
              >
                Close
              </button>
            </div>
          </div>
        )}
      </section>
      {showPopUp.visible && (
        <PopUp
          sipId={showPopUp.sipId}
          amount={showPopUp.amount}
          maturityDate={showPopUp.maturityDate}
          installmentId={showPopUp.installmentId}
          companyData={companyData}
          onClose={() => setShowPopUp({ visible: false })}
          onConfirm={() => {
            payInstallment(
              showPopUp.sipId,
              showPopUp.installmentId,
              showPopUp.amount,
              showPopUp.maturityDate
            );
            setShowPopUp({ visible: false });
          }}
        />
      )}
    </>
  );
};

export default SipOrderHistory;
