import React, { useEffect, useState } from "react";
import { Row, Col } from "react-bootstrap";
import Loader from "../../Components/Loader/Loader";
import { useDispatch, useSelector } from "react-redux";
import { ApiPaths } from "../../Config/ApiPath";
import { AiOutlineUser } from "react-icons/ai";
import useAxiosHelper from "../../Common/AxiosHelper";
import { setUserPersonalInfo } from "../../Redux/ProfileDataSlice";
import { setIncomeWallet } from "../../Redux/IncomeWallet";
import { BasicInfo, toastFailed, toastSuccess } from "../../Config/BasicInfo";
import ArrayToObject from "../../Common/ArrayToObject";
import ClaimedHistory from "./WithdrawalHistory";
const Withdraw = () => {
  const [loading, setLoading] = useState(false);
  const { AxiosGet, AxiosPost } = useAxiosHelper();
  const [amount, setAmount] = useState();
  const [selectWallet, setSelectWallet] = useState();
  const [selectAccount, setSelectAccount] = useState();
  const [bankDetails, setBankDetails] = useState();
  const [companyData, setCompanyData] = useState([]);
  const incomeData = useSelector((state) => state.incomeData.incomeWallet);
  const [status, setStatus] = useState("0");
  const [change, setChange] = useState();
  const [walletBalance, setWalletBalance] = useState(0);
  const [walletName, setWalletName] = useState("Main Wallet");
  const dispatch = useDispatch();

  useEffect(() => {
    // Find the main wallet balance as default
    const mainWallet = incomeData?.find((x) => x?.slug === "main_wallet");
    if (mainWallet) {
      setSelectWallet(mainWallet.slug);
      setWalletBalance(mainWallet.value);
      setWalletName(mainWallet.name);
    }
  }, [incomeData]);

  const handleWalletChange = (e) => {
    const selectedSlug = e.target.value;
    setSelectWallet(selectedSlug);

    // Find the selected wallet and update balance
    const selectedWallet = incomeData?.find((x) => x?.slug === selectedSlug);
    if (selectedWallet) {
      setWalletBalance(selectedWallet.value);
      setWalletName(selectedWallet.name);
    }
  };

  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      // console.log(JSON.parse(data));
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }

  async function Withdraw() {
    try {
      const body = {
        wallet_name: selectWallet,
        paymentMethod: "bank",
        account: selectAccount,
        amount: amount,
      };
      console.log("body==>", body);
      const response = await AxiosPost(ApiPaths.withdraw, body);
      toastSuccess(response?.message);
      setChange(Date.now());
      FetchWallets();
      setSelectWallet();
      setAmount();
    } catch (e) {
      toastFailed(e?.response?.data?.message);
    }
  }

  async function FetchWallets() {
    try {
      const response = await AxiosGet(ApiPaths.getWallets); // replace with your API
      console.log("wallets", response);
      dispatch(setIncomeWallet(response?.wallets));
    } catch (error) {
      console.error("Error fetching color:", error);
    }
  }

  async function FetchBankDetails() {
    try {
      const response = await AxiosGet(ApiPaths.updateBankDetails); // replace with your API
      console.log("bank details", response);
      setBankDetails(response?.accountNumber);
      setSelectAccount(response?.accountNumber);
    } catch (error) {
      console.error("Error fetching color:", error);
    }
  }

  var x = 0;
  useEffect(() => {
    if (x === 0) {
      FetchWallets();
      FetchBankDetails();
      CompanyInfo();
      x++;
    }
  }, []);

  const handleShowWithdrawHistory = (newStatus) => {
    setStatus((prevStatus) => (prevStatus === newStatus ? "" : newStatus));
  };
  return (
    <>
      {loading ? <Loader /> : null}

      <section className="dashboard">
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div className="planDiv">
            <div className="addfundDiv inputPrimary ">
              <h1>Withdraw</h1>
              <div className="addfundDivFundWallet">
                <p>{walletName}</p>
                <p>
                  {companyData?.currency_sign}
                  {parseFloat(walletBalance).toFixed(2)}
                </p>
              </div>
              <label>Wallet</label>

              <select value={selectWallet} onChange={handleWalletChange}>
                <option value="">--Select Wallet--</option>
                {Array.isArray(incomeData) &&
                  incomeData?.map((x, i) => {
                    return (
                      x?.wallet_type == "wallet" &&
                      (x?.slug == "main_wallet" || x?.slug == "roi_wallet") && (
                        <option value={x?.slug}>{x?.name}</option>
                      )
                    );
                  })}
              </select>

              <label>Account</label>
              <input
                type="number"
                className=""
                placeholder="Enter Amount"
                value={selectAccount}
                onChange={(e) => setSelectAccount(e.target.value)}
              />

              <label>Amount ({companyData?.currency} )</label>
              <input
                type="number"
                className=""
                placeholder="Enter Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />

              <button className="btnPrimary mt-3" onClick={Withdraw}>
                Withdraw
              </button>
            </div>
          </div>
        </div>
        <section>
          <div style={{ padding: "20px" }}>
            {" "}
            <Row>
              <Col lg="2" md="4" xs="6">
                <div
                  className={`tab ${
                    status === "0" ? "btnPrimary" : ""
                  } fundActive`}
                  onClick={() => handleShowWithdrawHistory("0")}
                >
                  Pending
                </div>
              </Col>
              <Col lg="2" md="4" xs="6">
                <div
                  className={`tab ${
                    status === "1" ? "btnPrimary" : ""
                  } fundActive`}
                  onClick={() => handleShowWithdrawHistory("1")}
                >
                  Approved
                </div>
              </Col>
            </Row>
          </div>
          {status && <ClaimedHistory key={change} status={status} />}
        </section>
      </section>
    </>
  );
};

export default Withdraw;
