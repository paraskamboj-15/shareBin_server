import React, { useEffect, useState } from "react";
import "./Plans.css";
import { Row } from "react-bootstrap";
import Loader from "../../Components/Loader/Loader";
import { useDispatch, useSelector } from "react-redux";
import { ApiPaths } from "../../Config/ApiPath";
import { AiOutlineUser } from "react-icons/ai";
import useAxiosHelper from "../../Common/AxiosHelper";
import { setUserPersonalInfo } from "../../Redux/ProfileDataSlice";
import { setIncomeWallet } from "../../Redux/IncomeWallet";
import { BasicInfo, toastFailed, toastSuccess } from "../../Config/BasicInfo";
import ArrayToObject from "../../Common/ArrayToObject";
import OrderHistory from "./GrowthSIPOrder";
import { useNavigate } from "react-router-dom";
import moment from "moment";
// import TermAndConditions from "../../Components/PaymentT&C/TermAndConditions";
import animationData from "./../../Components/animation/celebration.json";
import Lottie from "react-lottie";
import { toastInfo } from "../../Common/Data";

const Plans = () => {
  const dispatch = useDispatch();
  const [typingTimeout, setTypingTimeout] = useState(null);
  const [loading, setLoading] = useState(false);
  const [load, setLoad] = useState(false);
  const [existUserName, setExistUserName] = useState();

  const [amount, setAmount] = useState();
  const [amountError, setAmountError] = useState("");
  const [username, setUsername] = useState("");
  const [fundBalance, setFundBalance] = useState();
  const [selectIncome, setSelectIncome] = useState();
  const [selectPackage, setSelectPackage] = useState([]);
  const [sponsorLoading, setSponsorLoading] = useState(false);
  const { AxiosPost, AxiosGet } = useAxiosHelper();
  const incomeData = useSelector((state) => state.incomeData.incomeWallet);
  const profileData = useSelector(
    (state) => state.profileData.userPersonalInfo
  );
  const [showPopUp, setShowPopUp] = useState(false);
  const [planId, setPlanId] = useState();
  const navigate = useNavigate();
  const [topUpSuccess, setTopUpSuccess] = useState(false);
  const [packageTime, setPackageTime] = useState(""); // New state for packageTime
  const [sponsorName, setSponsorName] = useState("");
  const [companyData, setCompanyData] = useState([]);
  const [monthlyIntrest, setMonthlyIntrest] = useState("");

  useEffect(() => {
    CompanyInfo();
  }, []);
  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      // console.log(JSON.parse(data));
      setCompanyData(JSON.parse(data));
    } catch (error) {
      BasicInfo.isDebug && console.log(error);
    }
  }

  const isUserExist = async () => {
    setLoad(true);

    if (!username) {
      setExistUserName(". . .");
      setLoad(false);
      return;
    }
    try {
      setLoad(true);
      const body = {
        username: username,
      };
      BasicInfo.isDebug && console.log("body", body);
      const res = await AxiosPost(ApiPaths.checkSponsor, body);
      if (res) {
        toastSuccess(res?.message);
        setExistUserName(res.name);
      } else {
        setExistUserName("User not exists");
      }
    } catch (e) {
      toastFailed(e?.response?.data?.message);
      setExistUserName("User not exists");
    } finally {
      setLoad(false);
    }
  };

  useEffect(() => {
    // Clear the timeout when the user is typing
    if (typingTimeout) {
      clearTimeout(typingTimeout);
    }
    // Set a new timeout to call the API after the user stops typing
    setTypingTimeout(
      setTimeout(() => {
        isUserExist();
      }, 500) // 500ms debounce delay
    );

    // Cleanup the timeout when the component is unmounted or when typing continues
    return () => clearTimeout(typingTimeout);
  }, [username]);

  useEffect(() => {
    if (profileData?.username) {
      setUsername(profileData.username);
    }
  }, [profileData]);

  useEffect(() => {
    FetchData();
    fetchIncome();
  }, []);

  useEffect(() => {
    fetchActivationUserName();
  }, [username]);

  async function fetchIncome() {
    try {
      const res = await AxiosGet(ApiPaths.getPackages);
      if (res) {
        const filteredPackages = res?.packages?.filter(
          (packageData) => packageData?.sip_status == "1"
        );

        // Set the filtered packages in state
        setSelectPackage(filteredPackages);
      }
    } catch (e) {
      toastFailed(e?.response?.data?.message);
    }
  }
  const handleChange = (e) => {
    const selectedPackage = selectPackage.find(
      (pkg) => pkg?.package?.name === e.target.value
    );
    console.log("selectedPackage", selectedPackage);

    setSelectIncome(e.target.value);
    setPlanId(selectedPackage?.planId);
    setMonthlyIntrest(selectPackage?.roi_income?.income);
  };
  async function FetchData() {
    try {
      const [res1, res2] = await Promise.all([
        AxiosGet(ApiPaths.getProfile),
        AxiosGet(ApiPaths.getWallets),
      ]);

      if (res1) {
        dispatch(setUserPersonalInfo(res1));
      }

      if (res2?.wallets) {
        dispatch(setIncomeWallet(res2?.wallets));
        const objectWalletData = ArrayToObject(res2?.wallets);
        setFundBalance(objectWalletData?.fund_wallet?.value);
      }
    } catch (error) {
      toastFailed("Error loading data");
    }
  }
  const [isAccepted, setIsAccepted] = useState(false);
  const [showTermAndConditions, setShowTermAndConditions] = useState(false);
  const handleTerms = () => {
    setIsAccepted(!isAccepted);
  };
  const handleTermAndConditionPopUp = () => {
    setShowTermAndConditions(!showTermAndConditions);
  };

  function checkValidation() {
    // Check if income is selected
    if (!selectIncome) {
      toastFailed("Please select Plan");
      return false;
    }
    // Check if amount is greater than 0
    if (amount <= 0) {
      toastFailed("Please enter amount");
      return false;
    }
    // Check if terms and conditions are accepted
    if (!isAccepted) {
      toastFailed("Please accept the terms & conditions");
      return false;
    }
    // Check if the amount is greater than available funds
    if (amount > fundBalance) {
      toastFailed("Insufficient funds");
      return false;
    }

    // If all checks pass, return true
    return true;
  }
  const handleProceedClick = () => {
    const valid = checkValidation();
    if (valid) {
      setShowPopUp(true);
    }
  };

  // const handleProceedClick = () => {
  //   if (!username) {
  //     toastFailed("Please enter a valid User ID");
  //     return;
  //   }

  //   if (!amount || amount <= 0) {
  //     toastFailed("Please enter a valid amount");
  //     return;
  //   }
  //   setShowPopUp(true);
  // };

  const handleTopUpSuccess = (time) => {
    setTopUpSuccess(true);
    setShowPopUp(false);
    setPackageTime(time); // Store the packageTime
  };
  async function fetchActivationUserName() {
    const body = {
      username: username,
    };
    try {
      const res = await AxiosPost(ApiPaths.checkSponsor, body);
      if (res && res.name) {
        setSponsorName(res.name); // Set the sponsor name
      } else {
        BasicInfo.isDebug && console.log("Sponsor name not found");
        setSponsorName(" ");
      }
    } catch (e) {
      BasicInfo.isDebug && console.error("Error fetching sponsor name", e);
    }
  }

  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  return (
    <>
      {loading ? <Loader /> : null}
      {topUpSuccess ? (
        <section className="registerSuccessDetails">
          <div style={{ position: "absolute", transform: "scale(8)" }}>
            <Lottie options={defaultOptions} height={100} width={300} />
          </div>
          <div style={{ zIndex: "999" }}>
            <div id="successIcon">
              <h1>Success</h1>
            </div>
            <div id="successDetails">
              <p className="mb-4">
                Congratulations your Investment has been successfully saved
              </p>
              <div style={{ display: "block" }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Name:</p>
                  <p className="successData">{username}</p>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Investment Plan:</p>
                  <p className="successData">Systematic Amiara Plan</p>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Plan Type:</p>
                  <p className="successData">{selectIncome}</p>
                </div>
                {/* <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Monthly Interest:</p>
                  <p className="successData">{monthlyIntrest} %</p>
                </div> */}
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Invested Amount:</p>
                  <p className="successData">
                    {companyData?.currency} {amount}
                  </p>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Maturity Time:</p>
                  <p className="successData">
                    {moment(packageTime).format("DD-MM-YYYY")}
                  </p>{" "}
                  {/* Updated */}
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <p className="successData">Purchase Time:</p>
                  <p className="successData">
                    {moment().format("DD-MM-YYYY")}
                  </p>{" "}
                  {/* Updated */}
                </div>
              </div>

              <button
                onClick={() => {
                  setTopUpSuccess(false);
                  navigate("/dashboard");
                }}
              >
                Continue
              </button>
            </div>
          </div>
        </section>
      ) : null}
      <section className="dashboard">
        <h1
          className="textHeadingWithMargin mt-0 mt-4"
          style={{ marginBottom: "30px" }}
        >
          Systematic Amiara Plan {selectIncome && `(${selectIncome})`}
        </h1>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div className="planDiv">
            <div className="addfundDiv inputPrimary ">
              <h1>Activation</h1>
              <div className="subscriptionWallets">
                {incomeData?.map(
                  (x) =>
                    x?.name === "Fund Wallet" && (
                      <div className="fundWallet" key={x?.name}>
                        <p>Fund Wallet</p>
                        <h5>
                          {" "}
                          {companyData?.currency} {x?.value}
                        </h5>
                      </div>
                    )
                )}
              </div>
              <div className="d-flex">
                <label htmlFor="Amount">User ID</label>
                <label htmlFor="Amount" style={{ textAlign: "end" }}>
                  <span>{load && username ? "Loading..." : existUserName}</span>
                </label>
                {/* <label htmlFor="Amount" style={{ textAlign: "end" }}><span>{sponsorName || " "}</span></label> */}
              </div>

              <div style={{ position: "relative" }}>
                <div>
                  <i
                    style={{
                      position: "absolute",
                      top: 5,
                      left: 2,
                      color: "var(--colorPrimary)",
                    }}
                  >
                    <AiOutlineUser />
                  </i>
                </div>

                <input
                  type="text"
                  style={{ padding: "8px 20px" }}
                  placeholder="Enter User ID"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toUpperCase())}
                />
                {sponsorLoading ? <i id="sponsorLoading"></i> : null}
              </div>
              <label>Select Plan</label>

              <div>
                <select
                  style={{
                    padding: "8px",
                    color: "var(--textColor)",
                    width: "100%",
                    borderRadius: "5px",
                  }}
                  name=""
                  id=""
                  value={selectIncome}
                  onChange={(e) => handleChange(e)}
                >
                  <option value="">Select Plan</option>
                  {selectPackage?.map((pkg) => (
                    <option key={pkg?.planId} value={pkg?.package?.name}>
                      {pkg?.package?.name}
                    </option>
                  ))}
                </select>
              </div>
              <label htmlFor="Amount">Amount ({companyData?.currency} )</label>
              <input
                type="number"
                className="inputPrimary"
                placeholder="Enter Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <p className="errorMsg">{amountError}</p>
              <div className="mt-1">
                <label className="d-flex">
                  <input
                    className="w-auto mx-1"
                    style={{ marginBottom: "-1px" }}
                    type="checkbox"
                    checked={isAccepted}
                    onChange={handleTerms}
                  />
                  I agree to{" "}
                  <span
                    className="termAndConditions"
                    onClick={handleTermAndConditionPopUp}
                    style={{ cursor: "pointer", color: "var(--colorPrimary)" }}
                  >
                    Terms & Conditions
                  </span>
                </label>
                {showTermAndConditions && (
                  <TermAndConditions onClose={handleTermAndConditionPopUp} />
                )}
              </div>
              <button className="btnPrimary mt-3" onClick={handleProceedClick}>
                Proceed
              </button>
              {showPopUp && (
                <PopUp
                  amount={amount}
                  planId={planId}
                  username={username}
                  fundBalance={fundBalance}
                  selectIncome={selectIncome}
                  interest={monthlyIntrest}
                  onClose={() => setShowPopUp(false)} // Pass a prop to close the pop-up
                  onTopUpSuccess={handleTopUpSuccess} // Pass a callback for top-up success
                  setShowPopUp={() => setShowPopUp(false)}
                />
              )}
            </div>
          </div>
        </div>
        <OrderHistory />
      </section>
    </>
  );
};

export default Plans;

function PopUp({
  username,
  planId,
  amount,
  fundBalance,
  selectIncome, // Package name
  interest,
  onClose,
  onTopUpSuccess,
  packageTime,
  setShowPopUp,
}) {
  const [loading, setLoading] = useState(false);
  const { AxiosPost } = useAxiosHelper();
  const [companyData, setCompanyData] = useState([]);

  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    CompanyInfo();
  }, []);

  async function TopUp() {
    const valid = checkValidation();
    if (valid) {
      try {
        setLoading(true);
        const body = {
          username,
          planId,
          amount,
        };
        console.log("BODYYY===>", body);
        const res = await AxiosPost(ApiPaths.topUp, body);
        const packageTime = res?.date;
        onTopUpSuccess(packageTime); // Pass packageTime to the parent
      } catch (e) {
        toastFailed(e?.response?.data?.message);
      } finally {
        setLoading(false);
      }
    }
  }

  function checkValidation() {
    if (amount > 0) {
      if (amount > fundBalance) {
        toastFailed("Insufficient Funds");
        return false;
      } else {
        return true;
      }
    } else {
      toastFailed("Please Enter Amount");
      return false;
    }
  }

  return (
    <>
      <div className="otpSection" style={{ zIndex: "999" }}>
        <div className="otpContainer" style={{ width: "400px" }}>
          <p>
            Are you sure you want to proceed with the top-up for the following
            details?
          </p>
          <div style={{ marginBottom: "20px", flexDirection: "column" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong>User ID:</strong>
              </p>
              <p>{username}</p>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "14px",
              }}
            >
              <p>
                <strong>Investment Plan:</strong>
              </p>
              <p>Systematic Amiara Plan (Sip)</p>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong>Plan Name:</strong>
              </p>
              <p>{selectIncome}</p>
            </div>
            {/* <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong style={{ whiteSpace: "nowrap" }}>Monthly Interest:</strong>
              </p>
              <p>{interest} %</p>
            </div> */}
            {/* <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong>Maturity Time:</strong>
              </p>
              <p>{moment(packageTime).format("DD-MM-YYYY")}</p>
            </div> */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "0px",
                gap: "0",
              }}
            >
              <p>
                <strong>Amount:</strong>
              </p>
              <p>
                {companyData?.currency} {amount}
              </p>
            </div>
          </div>
          <div>
            <button className="btnSecondary" onClick={onClose}>
              No
            </button>
            <button className="btnPrimary" onClick={TopUp} disabled={loading}>
              {loading ? "Processing..." : "Yes"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function TermAndConditions({ onClose }) {
  return (
    <div className="term-and-conditions__overlay">
      <div className="term-and-conditions__content">
        <div>
          <h1 className="textHeading">Terms & Conditions</h1>
        </div>

        <p>
          1. Introduction These Terms and Conditions govern the Systematic
          Amiara Plan (hereinafter referred to as "the Plan"), offered by Amiara
          (hereinafter referred to as "the Company")]. By enrolling in the Plan,
          the Applicant (hereinafter referred to as "the Investor") agrees to be
          bound by these Terms and Conditions.
          <br />
          2. Plan Options and Details The Plan offers two options: Mid-Term and
          Long-Term. The Investor must select one of these options in the Plan
          Application Form.
          <br /> 2.1 Mid-Term Plan: Minimum Monthly Investment: ₹6,000. Number
          of Installments: 9. Total Tenure: 24 months from the date of the first
          investment. Payment Frequency: Payments are due monthly. Total
          Investment Amount: ₹54,000 (₹6,000 x 9).
          <br /> 2.2 Long-Term Plan: Minimum Monthly Investment: ₹1,000. Number
          of Installments: 18. Total Tenure: 30 months from the date of the
          first investment. Payment Frequency: Payments are due monthly. Total
          Investment Amount: ₹18,000 (₹1,000 x 18).
          <br /> 2.3 General Plan Details (Applicable to both Mid-Term and
          Long-Term): Payment Schedule: Installment payments are due monthly, on
          a date specified in the Plan Application Form or as otherwise agreed
          upon in writing between the Company and the Investor. Maturity: The
          Plan will mature on the specified maturity date, calculated from the
          date of the first successfully processed payment. Maturity Benefit:
          Upon maturity, the Investor will receive 200% of the total investment
          amount. Clarification on "200%": The term "200% of the total
          investment amount" means that the investor will receive back their
          initial investment plus an additional amount equal to their initial
          investment. Example (Mid-Term): If an investor invests ₹6,000 per
          month for 9 months (total ₹54,000), they will receive ₹108,000 at
          maturity. Example (Long-Term): If an investor invests ₹1,000 per month
          for 18 months (total ₹18,000), they will receive ₹36,000 at maturity.
          <br />
          3. Account Closure and Refunds No Withdrawals Before Maturity:
          Withdrawals are not permitted before the maturity date. Account
          Closure Due to Non-Payment: If three consecutive payments are missed,
          the account will be closed. Refund Policy Upon Closure: If the account
          is closed within the first 6 months of the first payment, the Investor
          will receive a refund of the total amount invested less an
          administrative fee of 48%. If the account is closed after 6 months of
          the first payment, the Investor will receive a refund of the total
          amount invested without any returns.
          <br />
          4. Late Payment Fee A late payment fee of 5% per month will be applied
          to any outstanding balances. This fee will be calculated on the amount
          overdue for each missed installment.
          <br />
          5. Auto-Renewal The Plan will not be automatically renewed unless
          explicitly agreed upon in writing by both the Company and the
          Investor.
          <br />
          6. Tax Implications The Investor is solely responsible for any tax
          liabilities arising from the Plan. The Company will deduct taxes at
          source (TDS) as per applicable tax laws.
          <br />
          7. Nomination The Investor may nominate a beneficiary to receive the
          Plan proceeds in the event of their death. The nomination can be
          changed by the Investor during the Plan's tenure by providing written
          notice to the Company.
          <br />
          8. Amendments The Company reserves the right to amend these Terms and
          Conditions at any time. The Investor will be notified of any material
          changes in writing or through other appropriate communication
          channels.
          <br />
          9. Dispute Resolution Any disputes arising out of or in connection
          with this Plan shall be resolved through arbitration in Delhi, India,
          in accordance with the rules of the Indian Council of Arbitration. The
          language of the arbitration shall be English. The arbitral award shall
          be final and binding on both parties. For the purposes of this clause,
          "Delhi" refers to the National Capital Territory of Delhi, India.
          <br />
          10. Limitation of Liability The Company shall not be liable for any
          losses arising from events beyond its reasonable control, including
          but not limited to acts of God, war, terrorism, government
          regulations, or market fluctuations. The Company is responsible for
          exercising reasonable care and diligence in managing the Plan. The
          Company is not responsible for the misuse of funds by agents if the
          Company has taken reasonable steps to supervise and control their
          actions.
          <br />
          11. Governing Law These Terms and Conditions shall be governed by and
          construed in accordance with the laws of India. Any legal action or
          proceeding arising under these Terms and Conditions shall be subject
          to the exclusive jurisdiction of the courts in Delhi, India. For the
          purposes of this clause, "Delhi" refers to the National Capital
          Territory of Delhi, India.
          <br />
          12. Acceptance By signing the Systematic Amiara Plan Application Form
          or making an investment, the Investor acknowledges that they have
          read, understood, and agree to these Terms and Conditions.
          <br />
          <br />
          <h1>
            Definitions for Amiara Systematic Amiara Plan Terms and Conditions
          </h1>
          {/* <li> */}
          <ul>
            Amiara/the Company: Refers to the legal entity offering the
            Systematic Amiara Plan, i.e., the provider of the investment plan.
            Its full legal name and registration details should be included in
            the actual legal document.
          </ul>
          <ul>
            {" "}
            Systematic Amiara Plan/the Plan: Refers to the specific investment
            product offered by Amiara, governed by these Terms and Conditions.
            This plan involves regular periodic investments with a defined
            maturity benefit.
          </ul>
          <ul>
            Investor/Applicant: Refers to the individual or entity investing in
            the Amiara Systematic Amiara Plan and agreeing to these Terms and
            Conditions.
          </ul>
          <ul>
            Plan Application Form: The document (physical or electronic) used by
            the Investor to formally enroll in the Plan, specifying the chosen
            plan option (Mid-Term or Long-Term), payment schedule, and other
            relevant details.
          </ul>
          <ul>
            Investment/Investment Amount: Refers to the monetary contribution
            made by the Investor to the Plan. This can refer to individual
            monthly installments or the total sum of all installments.
          </ul>
          <ul>
            Minimum Monthly Investment: The minimum amount the Investor is
            required to invest each month, as specified for each plan option
            (₹6,000 for Mid-Term, ₹1,000 for Long-Term).
          </ul>
          <ul>
            Total Investment Amount: The total sum of all planned investments
            over the course of the plan tenure. (₹54,000 for Mid-Term, ₹18,000
            for Long-Term).
          </ul>
          <ul>
            Installment: Each individual payment made by the Investor as part of
            their investment in the Plan.
          </ul>
          <ul>
            Payment Frequency: The regularity with which installments are due
            (in this case, monthly).
          </ul>
          <ul>
            Payment Schedule: The agreed-upon date each month on which
            installments are due, as specified in the Plan Application Form or
            otherwise agreed upon in writing.
          </ul>
          <ul>
            Outstanding Balance: The amount of any missed or overdue installment
            payments.
          </ul>
          <ul>
            {" "}
            Late Payment Fee: A charge applied to the Investor for failing to
            make an installment payment by the due date.{" "}
          </ul>
          <ul>
            Tenure: The total duration of the investment period, measured from
            the date of the first successfully processed payment to the maturity
            date.
          </ul>{" "}
          <ul>
            Maturity Date: The date on which the Plan reaches the end of its
            tenure, and the maturity benefit becomes payable to the Investor.
          </ul>
          <ul>
            Maturity Benefit: The total amount payable to the Investor upon
            maturity of the Plan, which is 200% of the total investment amount.
          </ul>
          <ul>
            Annualized Return (APR/IRR): The annual percentage rate or internal
            rate of return, which represents the annualized rate of return on
            the investment. This metric provides a standardized way to compare
            different investment options.{" "}
          </ul>
          <ul>
            Refund: The return of the Investor's invested capital under certain
            conditions, such as early account closure.
          </ul>
          <ul>
            Administrative Fee: A charge deducted from the refund amount if the
            account is closed within the first 6 months. This covers
            administrative costs associated with processing the early closure.
          </ul>
          <ul>
            Auto-Renewal: The automatic extension of the Plan's tenure at
            maturity. This will only occur if explicitly agreed upon in writing
            by both parties.{" "}
          </ul>
          <ul>
            Nominee/Beneficiary: The person or entity designated by the Investor
            to receive the maturity benefit in the event of the Investor's
            death.{" "}
          </ul>
          <ul>
            Tax Implications: The potential tax liabilities arising from the
            investment, which are the sole responsibility of the Investor.{" "}
          </ul>
          <ul>
            Tax Deducted at Source (TDS): The deduction of taxes by the Company
            from the maturity benefit or other payments, as required by
            applicable tax laws.{" "}
          </ul>
          <ul>
            Amendments: Changes or modifications made to these Terms and
            Conditions by the Company.{" "}
          </ul>
          <ul>
            Dispute: Any disagreement, claim, or controversy arising between the
            Company and the Investor related to the Plan or these Terms and
            Conditions.{" "}
          </ul>
          <ul>
            Arbitration: A method of resolving disputes outside of court, where
            a neutral third party (an arbitrator) makes a binding decision.{" "}
          </ul>
          <ul>
            Governing Law: The legal jurisdiction whose laws govern the
            interpretation and enforcement of these Terms and Conditions (in
            this case, the laws of India).
          </ul>
          <ul>
            Jurisdiction: The legal authority of a court or other legal body to
            hear and decide legal cases (in this case, the courts in Delhi,
            India).{" "}
          </ul>
          <ul>
            {" "}
            Force Majeure: (Often included in Limitation of Liability) Refers to
            unforeseeable circumstances that prevent someone from fulfilling a
            contract, such as acts of God, war, or natural disasters.
          </ul>
          {/* </li>{" "} */}
        </p>
        <button className="term-and-conditions__button" onClick={onClose}>
          Close
        </button>
      </div>
    </div>
  );
}
