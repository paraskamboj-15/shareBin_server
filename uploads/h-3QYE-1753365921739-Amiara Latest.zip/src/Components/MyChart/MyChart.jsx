import React, { useEffect, useState } from "react";
import { PieChart } from "react-minimal-pie-chart";
import "./MyChart.css";
import { Data } from "../../Common/Data";
import GetFloatValue from "../../Common/GetFloatValue";

const MyChart = (props) => {
  // console.log("props", props);
  const root = document.documentElement;
  const rootStyles = getComputedStyle(root);
  const rootColor = rootStyles.getPropertyValue("--colorPrimary");

  const totalIncome = parseFloat(props?.totalIncome ?? 0);
  const totalCapping = parseFloat(props?.totalCapping ?? 0);

  const [companyData, setCompanyData] = useState([]);
  useEffect(() => {
    CompanyInfo();
  }, []);
  async function CompanyInfo() {
    try {
      const data = localStorage.getItem("companyData");
      setCompanyData(JSON.parse(data));
    } catch (error) {
      console.log(error);
    }
  }

  // If both values are zero, provide default small non-zero values to avoid issues
  const data = [
    {
      title: "Total Capping",
      value: totalCapping > 0 ? totalCapping : 0,
      color: "grey",
    },
    {
      title: "Total Income",
      value: totalIncome > 0 ? totalIncome : 0,
      color: rootColor,
    },
  ];
  return (
    <div className="capping">
      <div className="cappingGraphDiv">
        <div style={{ height: "120px" }}>
          <PieChart
            animate={true}
            animationDuration={2000}
            data={data}
            lineWidth={30}
            // paddingAngle={2}
            label={({ dataEntry }) => `${Math.round(dataEntry.percentage)}%`}
            labelStyle={{
              fill: "grey",
              fontSize: "8px",
              fontWeight: "bold",
              borderRadius: "50%",
            }}
          />
        </div>
        <div className="cappingAbout">
          <div>
            <span style={{ background: rootColor }}></span>
            <p> Total Capping</p>
          </div>
          <div>
            <span style={{ background: "grey" }}></span>
            <p>Income</p>
          </div>
        </div>
      </div>

      {/* <div className="cappingDetails cappingDetailsDashboard">
        <div>
          <div>
            <h1>
              {companyData?.currency} {growthBonus.toFixed(2)}
            </h1>
            <p>Total Income</p>
          </div>
        </div>
      
        <div>
          <div>
            <h1>
              {companyData?.currency} {totalInvestment.toFixed(2)}
            </h1>
            <p>Total Package</p>
          </div>
        </div>
      </div> */}
    </div>
  );
};

export default MyChart;
