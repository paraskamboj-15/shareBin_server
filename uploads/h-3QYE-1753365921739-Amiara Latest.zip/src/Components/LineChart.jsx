
import * as React from 'react';
import { LineChart } from '@mui/x-charts/LineChart';

export default function BasicLineChart() {
    return (
        <LineChart
            xAxis={[{ data: [1, 2, 3, 4,] }]}
            series={[
                {
                    data: [1, 2, 0, 4],
                    color: "var(--colorPrimary)", // Setting the color of the line

                },
            ]}

            //   width={350}
            height={320}
        />
    );
}



// import * as React from 'react';
// import { LineChart } from '@mui/x-charts/LineChart';

// export default function BasicLineChart() {

//   const incomeData = [5000, 7000, 6000, 8000]; // Income data for last 4 weeks

//   return (
//     <LineChart
//       xAxis={[{
//         data: ['Week 1', 'Week 2', 'Week 3', 'Week 4'], // Labeling the weeks
//       }]}
//       series={[
//         {
//           data: incomeData,
//           color: "var(--colorPrimary)", // Setting the color of the line
//         },
//       ]}
//       height={300}
//     />
//   );
// }
