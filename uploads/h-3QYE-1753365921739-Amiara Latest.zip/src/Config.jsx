export const ApiPaths = {};
