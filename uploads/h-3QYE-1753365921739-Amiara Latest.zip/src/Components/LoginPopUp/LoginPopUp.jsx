import React from "react";
import "./LoginPopUp.css"; // Add styles for the pop-up
import CopyFromtag from "../../Common/CopyFromtag";
import ReferralComponent from "../ReferralComponent";
import { FiCopy } from "react-icons/fi";


const PopUp = ({ title, description, referralLink, onClose }) => {
    async function CopyLink() {
        CopyFromtag("headerLink1");
        onClose();
    }

    return (
        <div className="popup-overlay">
            <div className="popup-container">
                {/* Close button */}
                {/* <button className="popup-close-button" onClick={onClose}>
                    &times;
                </button> */}
                <h2>{title}</h2>
                <p>{description}</p>
                {/* <div className="referral-box d-flex mb-3">
                    <input
                        id="headerLink1"
                        type="text"
                        value={referralLink}
                        readOnly
                        className="referral-input"
                    />
                </div> */}
                <div className="referral-box d-flex mb-3" style={{ position: "relative" }}>
                    <input
                        id="headerLink1"
                        type="text"
                        value={referralLink}
                        readOnly
                        className="referral-input"
                        style={{ paddingRight: "40px" }} // Add space for the icon
                    />
                    <i
                        onClick={() => CopyFromtag("headerLink1")}
                        style={{
                            position: "absolute",
                            right: "10px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            cursor: "pointer",
                            color: "#000", // Optional: Add color to match your design
                        }}
                    >
                        <FiCopy />
                    </i>
                </div>
                <div className="d-flex" style={{gap:"20px"}}>
                    <button className="btnPrimary d-flex justify-content-center" >
                        <ReferralComponent title={"Refer Now"} link={referralLink} />
                    </button>
                    <button className="btnPrimary" onClick={onClose}>
                        Do It Later
                    </button>
                </div>
            </div>
        </div>
    );
};

export default PopUp;
