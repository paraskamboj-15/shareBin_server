import React, { useEffect, useState, useRef } from "react";
import { useLocation } from "react-router-dom";
import useAxiosHelper from "../../Common/AxiosHelper";
import { ApiPaths } from "../../Config/ApiPath";
import moment from "moment/moment";
import { IoSend } from "react-icons/io5";
import Loader from "../../Components/Loader/Loader";

const SOCKET_SERVER_URL = "wss://apis.amiara.net";

export default function Tickets() {
  const [ticketData, setTicketData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [newComment, setNewComment] = useState("");
  const [comments, setComments] = useState([]);
  const { AxiosPost, AxiosGet } = useAxiosHelper();
  // Reference to the comments container
  const commentsContainerRef = useRef(null);
  // Access the query parameters from the URL
  const location = useLocation();
  // Extract ticketId and status from query params
  const queryParams = new URLSearchParams(location.search);
  const ticketId = queryParams.get("ticketId");
  const status = queryParams.get("status");
  const reconnectTimeoutRef = useRef(null);
  const wsRef = useRef(null);

  useEffect(() => {
    console.log(ticketId, "ticketId");
    console.log(status, "status");
    if (ticketId) {
      FetchTickets(ticketId);
    } else {
      setError("Ticket ID is missing");
      setLoading(false);
    }
  }, [ticketId]);

  useEffect(() => {
    if (commentsContainerRef.current) {
      commentsContainerRef.current.scrollTop =
        commentsContainerRef.current.scrollHeight;
    }
  }, [comments]);

  // FetchTickets function to call the API
  const FetchTickets = async (ticketId) => {
    try {
      setLoading(true);
      const res = await AxiosGet(
        `${ApiPaths?.getTickets}?ticketId=${ticketId}`
      );
      console.log("getTickets", res[0]);
      setTicketData(res[0]);
      setComments(res[0]?.comments || []);
    } catch (error) {
      console.log(error);
      setError("Failed to fetch ticket data");
    } finally {
      setLoading(false);
    }
  };

  const initializeWebSocket = (ticketId) => {
    // if (wsRef.current) {
    //   console.log("Closing existing WebSocket connection...");
    //   wsRef.current.close();
    // }
    const ws = new WebSocket(SOCKET_SERVER_URL);

    ws.onopen = () => {
      console.log("WebSocket connected");
      ws.send(JSON.stringify({ type: "subscribe", ticketId: ticketId }));
      console.log("connected already");
    };

    console.log("now message turn");

    ws.onmessage = (event) => {
      console.log("Raw WebSocket message:", event.data);
      try {
        const message = JSON.parse(event.data);
        console.log("Received WebSocket message:", message);

        if (message.commentId) {
          // Case: New user message is received
          console.log("New user comment:", message);
          setComments((prevComments) => {
            const updatedComments = [...prevComments, message];
            console.log("Updated comments:", updatedComments);
            return updatedComments;
          });
        } else if (message.data) {
          // Case: Data object is received (existing messages)
          console.log("Previous comments received:", message.data);
          setComments((prevComments) => [...prevComments, ...message.data]);
        } else {
          console.warn("Unexpected WebSocket message format:", message);
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected. Reconnecting...");
      reconnectWebSocket();
      // setTimeout(() => initializeWebSocket(ticketId), 5000);
    };

    wsRef.current = ws;
  };

  useEffect(() => {
    console.log("Updated comments state:", comments);
  }, [comments]);

  const reconnectWebSocket = () => {
    if (reconnectTimeoutRef.current) return;
    reconnectTimeoutRef.current = setTimeout(() => {
      initializeWebSocket();
      reconnectTimeoutRef.current = null;
    }, 5000);
  };

  useEffect(() => {
    if (ticketId) {
      initializeWebSocket(ticketId);
    }
    return () => {
      if (wsRef.current) wsRef.current.close();
      if (reconnectTimeoutRef.current)
        clearTimeout(reconnectTimeoutRef.current);
    };
  }, [ticketId]);

  const handleSendComment = async () => {
    if (!newComment.trim()) return;

    try {
      const response = await AxiosPost(
        `${ApiPaths?.addComment.replace(":ticketId", ticketId)}`,
        {
          message: newComment,
        }
      );
      console.log("Add Comment Response", response);
      // setComments((prevComments) => [
      //   ...prevComments,
      //   {
      //     message: newComment,
      //     user_type: "user",
      //     timestamp: new Date().toISOString(),
      //   },
      // ]);
      setNewComment("");
    } catch (error) {
      console.log("Error adding comment", error);
      setError("Failed to add comment");
    }
  };

  // Group comments by day
  const groupCommentsByDate = (comments) => {
    return comments.reduce((acc, comment) => {
      const commentDate = moment(comment.timestamp).format("YYYY-MM-DD");
      if (!acc[commentDate]) {
        acc[commentDate] = [];
      }
      acc[commentDate].push(comment);
      return acc;
    }, {});
  };

  // Render loading, error, or ticket data
  if (loading) return <Loader />;
  if (error) return <div>{error}</div>;

  // Grouped comments by date
  const groupedComments = groupCommentsByDate(comments);

  return (
    <div>
      <div className="d-flex justify-content-between">
        <div>
          <h5>Ticket Title: {ticketData?.subject}</h5>
          <span>Ticket Description: {ticketData?.description}</span>
        </div>
        <div
          style={{
            marginTop: "10px",
            fontWeight: "bold",
            color: status == "Closed" ? "red" : "green",
          }}
        >
          {status == "Closed" ? "Closed" : "Active"}
        </div>
      </div>
      {/* Display comments with date grouping */}
      <div
        ref={commentsContainerRef}
        className="comments-container mt-4"
        style={{
          overflowY: "scroll",
          height: "40vh",
          borderRadius: "10px",
          boxShadow: "rgb(0 0 0 / 31%) -5px -5px 15px -1px",
          padding: "10px",
        }}
      >
        {Object.keys(groupedComments).map((date) => (
          <div key={date}>
            <div
              style={{
                textAlign: "center",
                margin: "10px 0",
                fontSize: "12px",
              }}
            >
              {/* Show the formatted date heading */}
              ---------------- {moment(date).format("MMMM D, YYYY")}{" "}
              ----------------
            </div>
            {groupedComments[date].map((comment) => (
              <div
                key={comment.commentId}
                style={{
                  display: "flex",
                  justifyContent:
                    comment.user_type === "admin" ? "flex-start" : "flex-end",
                  marginBottom: "10px",
                }}
              >
                <div
                  style={{
                    maxWidth: "60%",
                    padding: "10px",
                    paddingBottom: "5px",
                    backgroundColor:
                      comment.user_type === "admin" ? "#f0f0f0" : "#d1e7dd",
                    borderRadius: "10px",
                    boxShadow: "0 2px 5px rgba(0, 0, 0, 0.1)",
                  }}
                >
                  <p style={{ margin: "0" }}>{comment.message}</p>
                  <small
                    className="d-flex justify-content-end ps-3"
                    style={{ fontSize: "10px" }}
                  >
                    {moment(comment?.timestamp).format("HH:mm")}
                  </small>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Message input box */}
      {status !== "Closed" && (
        <div
          className="userChatBox"
          style={{
            position: "relative",
            top: "10px",
            width: "100%",
            padding: "10px",
            backgroundColor: "var(--containerColor)",
            zIndex: "9999",
            borderRadius: "10px",
          }}
        >
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Type a message..."
            rows="1"
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "5px",
              border: "1px solid #ddd",
              minHeight: "50px",
              maxHeight: "80px",
              position: "relative",
            }}
          />
          <button
            style={{
              position: "absolute",
              top: "15px",
              right: "10px",
              width: "fit-content",
            }}
            onClick={handleSendComment}
            className="btnPrimary mb-0"
          >
            <IoSend />
          </button>
        </div>
      )}

      {status == "Closed" && (
        <div style={{ marginTop: "20px", color: "red", fontSize: "14px" }}>
          The ticket is closed by the admin. Please raise a new ticket if
          needed.
        </div>
      )}
    </div>
  );
}
