// import React from "react";
// const MyNewsCard = (props) => {
//   return (
//     <>
//       <div className="newsCard">
//         {/* {props.img == null || props?.img?.length == 0 ? (
//           <div className="imgContainer"></div>
//         ) : (
//           <img src={props.img} alt="img.png" />
//         )} */}
//         {/* <p>{props.date}</p> */}
//         <h4>{props.heading}</h4>
//         <h5>{props.description.replace(/<[^>]*>/g, "")}</h5>
//       </div>
//     </>
//   );
// };

// export default MyNewsCard;

import React, { useState } from "react";

const MyNewsCard = (props) => {
  const [showFullDescription, setShowFullDescription] = useState(false);

  const togglePopup = () => {
    setShowFullDescription(!showFullDescription);
  };

  const description = props.description.replace(/<[^>]*>/g, "");

  const styles = {
    newsCard: {
      position: "relative",
      padding: "15px",
      border: "1px solid #ddd",
      borderRadius: "5px",
      marginBottom: "15px",
    },
    description: {
      display: "-webkit-box",
      WebkitBoxOrient: "vertical",
      overflow: "hidden",
      lineHeight: "1.5em",
      maxHeight: "3em", // Limits to two lines
    },
    clamped: {
      display: "-webkit-box",
      WebkitLineClamp: "2",
    },
    full: {
      display: "block",
    },
    viewAllBtn: {
      color: "#000",
      cursor: "pointer",
      display: "flex",
      justifyContent: "end",
    },
    viewAllBtnHover: {
      color: "var(--colorPrimary)",
    },
    popup: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: "rgba(0, 0, 0, 0.8)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      zIndex: 1000,
    },
    popupContent: {
      background: "var(--containerColor)",
      padding: "20px",
      borderRadius: "8px",
      maxWidth: "80%",
      maxHeight: "80%",
      overflowY: "auto",
    },
    closePopup: {
      width: "fit-content",
    },
    closePopupHover: {
      backgroundColor: "#ff1c1c",
    },
  };

  return (
    <>
      <div className="newsCardContainer">
        {/* Notification without image */}
        {!props.img && (
          <div className="newsCard noImage">
            <h4>{props.heading}</h4>
            <div
              style={{
                ...styles.description,
                ...(showFullDescription ? styles.full : styles.clamped),
              }}
            >
              {description}
            </div>
            {!showFullDescription && description.length > 10 && (
              <span
                style={styles.viewAllBtn}
                onClick={togglePopup}
                onMouseEnter={(e) =>
                  (e.target.style.color = styles.viewAllBtnHover.color)
                }
                onMouseLeave={(e) =>
                  (e.target.style.color = styles.viewAllBtn.color)
                }
              >
                Read more...
              </span>
            )}
          </div>
        )}

        {/* Notification with image */}
        {props.img && (
          <div className="newsCard withImage">
            <h4>{props.heading}</h4>
            <img src={props.img} alt="img.png" />
            <div
              style={{
                ...styles.description,
                ...(showFullDescription ? styles.full : styles.clamped),
              }}
            >
              {description}
            </div>
            {!showFullDescription && description.length > 100 && (
              <span
                style={styles.viewAllBtn}
                onClick={togglePopup}
                onMouseEnter={(e) =>
                  (e.target.style.color = styles.viewAllBtnHover.color)
                }
                onMouseLeave={(e) =>
                  (e.target.style.color = styles.viewAllBtn.color)
                }
              >
                Read more...
              </span>
            )}
          </div>
        )}

        {/* Popup */}
        {showFullDescription && (
          <div style={styles.popup}>
            <div style={styles.popupContent}>
              <h4 className="text-center">{props.heading}</h4>
              {props.img && (
                <img src={props.img} alt="img.png" className="popupNotiImg" />
              )}
              <p>{description}</p>
              <button
                style={styles.closePopup}
                className="btnPrimary"
                onClick={togglePopup}
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default MyNewsCard;
