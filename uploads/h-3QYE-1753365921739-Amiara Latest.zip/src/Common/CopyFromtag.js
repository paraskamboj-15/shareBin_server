export default async function CopyFromtag(id) {
  try {
    const textElement = document.getElementById(id);
    if (!textElement) {
      throw new Error(`Element with id "${id}" not found`);
    }
    const text = textElement.innerText;

    if (!navigator.clipboard) {
      console.warn("Clipboard API not supported, using fallback.");
      fallbackCopyText(text);
    } else {
      await navigator.clipboard.writeText(text);
    }

    // Show copied message
    const copiedMsgElement = document.getElementById("CopiedMsg");
    if (copiedMsgElement) {
      copiedMsgElement.style.top = "20px";
      await delay(1000);
      copiedMsgElement.style.top = "-70px";
    }
  } catch (error) {
    console.error("Error copying text: ", error);
  }
}

// Fallback for unsupported Clipboard API
function fallbackCopyText(text) {
  const textArea = document.createElement("textarea");
  textArea.value = text;
  textArea.style.position = "fixed"; // Prevents the textarea from being visible
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    document.execCommand("copy");
    console.log("Fallback: Text copied successfully!");
  } catch (err) {
    console.error("Fallback: Unable to copy", err);
  }
  document.body.removeChild(textArea);
}

// Function to delay execution
const delay = (delayInMs) => {
  return new Promise((resolve) => setTimeout(resolve, delayInMs));
};
