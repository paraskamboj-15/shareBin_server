import React, { useEffect } from "react";
import { Container, Row, Col, Form, Button, Table } from "react-bootstrap";
import { ReactReduxContext, useSelector, useDispatch } from "react-redux";
import moment from "moment";
import "./Invoice.css";
import Logo from "./../../Images/logo.png";
import { MdOutlineFileDownload } from "react-icons/md";
import { setUserPersonalInfo } from "../../Redux/ProfileDataSlice";
import useAxiosHelper from "./../../Common/AxiosHelper";
// import { jsPDF } from "jspdf";
// import html2canvas from "html2canvas";
import { useLocation } from "react-router-dom";
import { toastFailed } from "../../Config/BasicInfo";
import { ApiPaths } from "./../../Config/ApiPath";
import { toWords } from "number-to-words";

const Invoice = () => {
  const { AxiosGet, AxiosPost } = useAxiosHelper();
  const location = useLocation();
  const { transaction, inst } = location.state || {};
  const profileData = useSelector(
    (state) => state.profileData.userPersonalInfo
  );
  const dispatch = useDispatch();
  // console.log("Transaction:", transaction, inst);

  async function fetchProfile() {
    try {
      const res = await AxiosGet(ApiPaths.getProfile);
      // console.log(res, "res profile ");

      if (res) {
        dispatch(setUserPersonalInfo(res));
      }
    } catch (error) {
      toastFailed(error.message);
    }
  }

  var x = 0;

  useEffect(() => {
    if ((x = 0)) fetchProfile();
    x++;
  }, []);

  const amountInWords = (amount) => {
    if (!Number.isFinite(amount)) {
      return "Invalid Amount";
    }

    const rupees = Math.floor(amount); // Integer part (rupees)
    const paisa = Math.round((amount - rupees) * 100); // Fractional part (paisa)

    let result = "";

    // Convert rupees to words
    if (rupees > 0) {
      result += `${toWords(rupees)} Rupees`;
    }

    // Convert paisa to words if there is a fractional part
    if (paisa > 0) {
      result += result
        ? ` and ${toWords(paisa)} Paisa`
        : `${toWords(paisa)} Paisa`;
    }

    return result || "Zero Rupees"; // If the amount is zero
  };

  function calculatePendingInstallments(data) {
    // console.log("pending installments", data);
    const installmentArray = data?.installment || [];
    const pendingInstallments = installmentArray.filter(
      (inst) => inst.status === 0
    ).length;
    return pendingInstallments || "Inst. completed";
  }

  function getUnpaidInstallmentAmount(data) {
    // console.log("unpaid data", data);
    const installmentArray = data?.installment || [];

    const UnpaidInstallment = installmentArray
      .filter(
        (inst) =>
          inst.status === 0 && new Date(inst.installment_Date) > new Date()
      )
      .sort(
        (a, b) => new Date(a.installment_Date) - new Date(b.installment_Date)
      )[0];

    return UnpaidInstallment?.installment_amount || "No next inst.";
  }

  function getUnpaidInstallmentDate(data) {
    // console.log("unpaid date data", data);
    const installmentArray = data?.installment || [];

    const UnpaidInstallment = installmentArray
      .filter(
        (inst) =>
          inst.status === 0 && new Date(inst.installment_Date) > new Date()
      )
      .sort(
        (a, b) => new Date(a.installment_Date) - new Date(b.installment_Date)
      )[0];

    return UnpaidInstallment?.installment_Date;
  }

  // const downloadPDF = async () => {
  //   // Capture the content of the page
  //   const element = document.getElementById("pdf-content"); // Replace with your content ID

  //   // Use html2canvas to convert HTML to canvas
  //   const canvas = await html2canvas(element, { scale: 3 });
  //   const imgData = canvas.toDataURL("image/png");

  //   // Create a new jsPDF instance
  //   const pdf = new jsPDF("portrait", "mm", "a4");

  //   let bottomMargin;
  //   let leftMargin;
  //   let rightMargin;
  //   let topMargin;
  //   if (window.length >= 1024) {
  //     leftMargin = 5;
  //     rightMargin = 5;
  //     topMargin = 5;
  //     bottomMargin = 5;
  //   } else if (window.length >= 800) {
  //     leftMargin = 5;
  //     rightMargin = 5;
  //     topMargin = 5;
  //     bottomMargin = 5;
  //   } else if (window.length >= 600) {
  //     leftMargin = 5;
  //     rightMargin = 5;
  //     topMargin = 5;
  //     bottomMargin = 5;
  //   } else if (window.length >= 400) {
  //     leftMargin = 4;
  //     rightMargin = 4;
  //     topMargin = 3;
  //     bottomMargin = 3;
  //   } else {
  //     leftMargin = 5;
  //     rightMargin = 5;
  //     topMargin = 3;
  //     bottomMargin = 3;
  //   }

  //   // Calculate available width and height for content
  //   const contentWidth = 210 - leftMargin - rightMargin; // 210 mm width of A4 - margins
  //   const contentHeight = 297 - topMargin - bottomMargin; // 297 mm height of A4 - margins

  //   // Add image to PDF with specified margins
  //   pdf.addImage(
  //     imgData,
  //     "PNG",
  //     leftMargin,
  //     topMargin,
  //     contentWidth,
  //     contentHeight
  //   ); // Top and left margins applied
  //   pdf.save(`Invoice.pdf`);
  // };

  return (
    <React.Fragment>
      <Container>
        {/* <div className="bondClose">
          <button className="downloadButton" 
         // onClick={downloadPDF}
          >
            <MdOutlineFileDownload />
          </button>
        </div> */}
        <div id="pdf-content">
          <div className="invoice">
            <div className="invoice-container">
              <div className="headingDiv">
                <img src={Logo} alt="Amiara Logo" className="logoImg" />
              </div>

              <div className="InfoDiv d-flex">
                <div className="branchDiv">
                  <p>
                    <span>Issued From:</span> Shilaj Rd, Opp. Silver Square
                    Complex,
                  </p>
                  <p> Ahmedabad, Gujarat 380059</p>
                  {/* <p>Sheikh Khalifa Bin Zayed St,</p>
                  <p>Al Mankhool</p>
                  <p>Dubai, UAE</p> */}
                  <p>
                    <span>Phone:</span> +91 7762883688 (Office)
                  </p>
                  <p>
                    <span>Website:</span> amaira.org
                  </p>
                </div>
                <div className="invoiceDiv">
                  <p>
                    <span>Invoice Date & Time:</span>{" "}
                  </p>
                  <p>
                    {moment(inst?.paid_Date).format("DD-MM-YYYY   &   HH:mm")}
                  </p>
                </div>
              </div>

              <h3 className="text-center investmentHead">
                INSTALLMENT RECEIPT
              </h3>
              <div className="InstDiv d-flex">
                <div className="userDiv">
                  <p>
                    Received with thanks Rs.{" "}
                    <span>{inst?.installment_amount}</span> through Payment
                    from:
                  </p>
                  <p>
                    {" "}
                    Mr./Ms. <span>{profileData?.name}</span>
                  </p>

                  <p>Towards the following</p>
                </div>
                <div className="userDiv">
                  <p>Applicant Code:</p>
                  <p>
                    <span>{profileData?.username}</span>
                  </p>
                </div>
              </div>

              <table className="invoice-table">
                <thead>
                  <tr>
                    <th>
                      <div className="tableHeadDiv">
                        <p>Invoice No.</p>
                        <p>SIP Id</p>
                      </div>
                    </th>
                    <th>Invt. Plan</th>
                    <th>Inst. Amt.</th>
                    <th>
                      <div className="tableHeadDiv">
                        <p>Paid Amt.</p>
                        <p>Late Fee</p>
                        <p>Total Amt.</p>
                      </div>
                    </th>
                    <th>
                      <div className="tableHeadDiv">
                        <p>Due Date</p>
                        <p>Paid Date</p>
                      </div>
                    </th>
                    <th>Pending Inst.</th>
                    <th>Next Inst.</th>
                    <th>Next Due</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="firstRow">
                    <td>
                      <div className="tableDataDiv">
                        <p>{transaction?.order_Id}</p>
                        <p>{transaction?.sip_Id}</p>
                      </div>
                    </td>
                    <td>{transaction?.package_type}</td>
                    <td>{inst?.installment_amount}</td>
                    <td>
                      <div className="tableDataDiv">
                        <p>{inst?.installment_amount}</p>
                        <p>0.00</p>
                        <p>{inst?.installment_amount + 0.0}</p>
                      </div>
                    </td>
                    <td>
                      <div className="tableDataDiv">
                        <p>
                          {moment(inst?.installment_Date).format(
                            "DD-MM-YYYY   &   HH:mm"
                          )}
                        </p>
                        <p>
                          {moment(inst?.paid_Date).format(
                            "DD-MM-YYYY   &   HH:mm"
                          )}
                        </p>
                      </div>
                    </td>
                    <td>{calculatePendingInstallments(transaction)}</td>
                    <td>{getUnpaidInstallmentAmount(transaction)}</td>
                    <td>
                      {moment(getUnpaidInstallmentDate(transaction)).format(
                        "DD-MM-YYYY   &   HH:mm"
                      )}
                    </td>
                  </tr>
                  <tr className="secondRow">
                    <td colSpan={3}>Grand Total (Rs.)</td>
                    <td>
                      {" "}
                      <div className="secondtableDataDiv">
                        <p>{inst?.installment_amount}</p>
                        <p>0.00</p>
                        <p>{inst?.installment_amount + 0.0}</p>
                      </div>
                    </td>
                    <td colSpan={2}> Next Inst. Grand Total (Rs.)</td>
                    <td>{getUnpaidInstallmentAmount(transaction)}</td>
                    <td></td>
                  </tr>
                  <tr className="thirdRow">
                    <td colSpan={3}>Amount in Words</td>
                    <td colSpan={4}>
                      {amountInWords(inst?.installment_amount + 0.0)
                        .charAt(0)
                        .toUpperCase() +
                        amountInWords(inst?.installment_amount + 0.0).slice(
                          1
                        )}{" "}
                      Only
                    </td>
                    <td></td>
                  </tr>
                </tbody>
              </table>

              <div className="ReceiptDataDiv">
                <div className="userDataDiv">
                  <h5>User Information:</h5>
                  <p>{profileData?.name}</p>
                  <p>{profileData?.username}</p>
                  <p>{profileData?.email}</p>
                  <p>{profileData?.mobile}</p>
                </div>
                <div className="DuplicateDataDiv">
                  <h5>Installments Maturity Date:</h5>
                  <p>
                    {moment(transaction?.maturity_date).format(
                      "DD-MM-YYYY  &  HH:mm"
                    )}
                  </p>
                  <div className="DuplicateDate">
                    <p>Duplicate receipt is generated online on</p>
                    <p>
                      {moment(inst?.paid_Date).format("DD-MM-YYYY   &   HH:mm")}
                    </p>
                  </div>
                </div>
              </div>

              <div className="SignedDiv">
                <p>
                  This receipt has been electronically generated and securely
                  digitally signed for your convenience.
                </p>
              </div>

              {/* <div className="invoiceFooter">
                <div className="SignatureDiv">
                  <p>Signatures</p>
                </div>
                <div className="MetaFDiv">
                  <p>For Amaira</p>
                </div>
              </div> */}
              <footer className="thankDiv">
                <p>
                  Please let us know if you have any questions. We are here to
                  help!
                </p>
                <h4>Thank You for your business!</h4>
              </footer>
            </div>
          </div>
        </div>
      </Container>
    </React.Fragment>
  );
};

export default Invoice;
